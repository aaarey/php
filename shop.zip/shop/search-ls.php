<div class="b-b bg-light lter">
<?php
	include "config/koneksi.php";
	include "config/fungsi_rupiah.php";
	$searchQuery = trim(strtoupper(urldecode($_REQUEST['s'])));
	
	if(($searchQuery[0]!="=")&&($searchQuery[0]!="-"))
	{
		$whereClause="(nama_kategori LIKE '%".$searchQuery."%' OR nama_produk LIKE '%".$searchQuery."%' OR kondisi LIKE '%".$searchQuery."%'
						OR deskripsi LIKE '%".$searchQuery."%')";

		$query="SELECT B.nama_kategori, A.nama_produk, A.kondisi, A.deskripsi,A.id_produk,A.gambar,A.produk_seo,A.stok,A.diskon
						FROM produk A LEFT JOIN 
							kategori B ON A.id_kategori=B.id_kategori
			WHERE $whereClause  
			ORDER BY A.id_produk DESC";

		$result=mysql_query($query);
		$ketemu = mysql_num_rows($result);
		if($ketemu > 0 ){
			echo "<div class='container'><div class='m-t-md'></div>
					<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert'>&times;</a>
							<strong><i class='ion-android-done-all'></i> Success</strong>, terdapat $ketemu  produk dalam pencarian anda
						</div>
				</div>";
		}
		else{
			echo "<div class='container'><div class='m-t-md'></div>
						<div class='alert alert-danger'><a href='#' class='close' data-dismiss='alert'>&times;</a>
							<strong><i class='ion-android-warning'></i> Error!</strong> Pencarian tidak ditemukan
						</div>
					</div>";		
		}
		if(mysql_num_rows($result)>0)
		{
		echo"<div class='container'>
			<div class='m-t-md'></div>";
			
			echo "<div class='col-sm-12'>";
			echo "<div class='row row-sm'>";
			$alt="";
			while($r=mysql_fetch_array($result))
			{
				$content_slide = strip_tags($r['deskripsi']); 
				$content_s = substr($content_slide,0,100); 
				$content_s = substr($content_s,0,strrpos($content_slide," "));		
				
			
				
					echo"<div class='col-md-3 col-sm-4'>
							<div class='item-panel panel b-a'>
								<div class='item m-l-n-xxs m-r-n-xxs'>
									<div class='pos-rlt'>
										<div class='ribbon ribbon-success'>
											<span>Baru</span>
										</div>
										<a href='produk-$r[id_produk]-$r[produk_seo].html'>
										<img src='static/products/foto_produk/$r[gambar]' width='640px' height='150px' class='img-full'></a>
									</div>
								</div>
								<div class='row no-gutter '>
									<div class='m-l-sm m-b-xs m-r-sm m-t-xs font-bold'>
										<a class='text-sm' href='produk-$r[id_produk]-$r[produk_seo].html'>$r[nama_produk] </a>
									</div>
								</div>	
								<div class='row no-gutter item-listing-desc'>
									<div class='m-l-sm m-b-xs m-r-sm m-t-xs'>
										$content_s
									</div>
								</div>
								<div class='row no-gutter item-listing-extra'>
									<div class='m-b-sm m-r-sm m-t-sm pull-right font-bold  text-lg'>
										<a href='produk-$r[id_produk]-$r[produk_seo].html' class='btn btn-success m-t-n-md '><del></del><i alt='beli' class='fa fa-eye'></i> Lihat Detail</a>
				      				</div>		
									
								</div>
								
							</div>
						</div>";	
			}
			echo "</div></div>";
			echo"</div>";
		}

	}
?>
</div>