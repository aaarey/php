				<div class="searchresult" id="liveRequestResults"></div>
				
				
					<script>liveReqInit('livesearch','liveRequestResults','search-ls.php','','mainResult');</script>