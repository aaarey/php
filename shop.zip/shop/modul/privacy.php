<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
</div>
  <div id="content" class="main-content bg-lights">
	  
	  
	    <div class="container">
	  	
	  
        <div class="m-t-md m-b-lg link-info">
	        
	        
	        
		<div class="panel wrapper b-a text-black">
		   <h3 class="m-t-xs">Aturan dan Privasi</h3>
			<p>Kebijakan ini mengatur informasi yang kami kumpulkan tentang Anda dan penggunaan informasi yang kami berikan kepada Anda. Dengan menerima Kebijakan ini dan Perjanjian Pengguna Syarat & Ketentuan, anda menyatakan menyetujui penggunaan kami dan pengungkapan informasi pribadi Anda dengan cara yang ditentukan dalam Kebijakan ini. Anda mengakui hal ini dengan menggunakan website.  </p>
		</div>




        </div>
      </div>	
	    	
	    	


  </div>