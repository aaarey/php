<div id="liveRequestResults"></div>	
	
<div id='mainResult'>	
<div class="container">
				<div class="info-boxes wow fadeInUp">
					<div class="info-boxes-inner">
						<div class="row">
							<div class="col-md-6 col-sm-4 col-lg-4">
								<div class="info-box">
									<div class="row">
										<div class="col-xs-12">
											<h4><img src="static/img/aman.png"></h4>
											<h4 class="info-box-heading green">Jaminan 100% Aman</h4>
										</div>
									</div>
									<h6 class="text">Payment system menjamin keamanan uang Anda dalam bertransaksi.</h6>
								</div>
							</div>
							<div class="hidden-md col-sm-4 col-lg-4">
								<div class="info-box">
									<div class="row">
										<div class="col-xs-12">
											<h4><img src="static/img/dompet.png"></h4>
											<h4 class="info-box-heading green">Kemudahan Berbelanja </h4>
										</div>
									</div>
									<h6 class="text">Menyediakan berbagai metode pembayaran dalam bertransaksi</h6>
								</div>
							</div>
							<div class="col-md-6 col-sm-4 col-lg-4">
								<div class="info-box">
									<div class="row">
										<div class="col-xs-12">
											<h4><img src="static/img/mobil.png"></h4>
											<h4 class="info-box-heading green">Berbagai Jasa Pengiriman</h4>
										</div>
									</div>
									<h6 class="text">Menyediakan berbagai pilihan jasa pengiriman dengan jangkauan nasional </h6>
								</div>
							</div>
						</div>
					</div>
					
				</div>

</div>
			<div class="bg-white ">
				<div class="container ">
					<div class="row">
						<div class="wrapper"></div>
					</div>
					<div class="row m-b-lg">
						<div class="col-sm-4">
							<div>
								<a href="#"><img class="pull-left m-r-md img-rounded" src="static/img/promo.jpg"></a>
							</div>
						</div>
						<div class="col-md-4">
							<div class="item m-r-n-xxs">
								<a href="#"><img src="static/img/a.jpg" class="pull-left m-r-md img-rounded"></a>
							</div>
						</div>
						<div class="col-md-2">
							<div class="item m-r-n-xxs">
								<a href="#"><img src="static/img/e.jpg" class="pull-left m-r-md img-rounded"></a>
							</div>
						</div>						
					</div>
				</div>
			</div>

		<div class="b-b bg-light lter">

			<div class="container">
				<div class="">
					<div class="wrapper"></div>
				</div>
				<div class="row row-sm">
					<?php
			            $kategori=mysql_query("select nama_kategori, kategori.id_kategori, kategori.icon, kategori.label,kategori_seo,
                                  count(produk.id_produk) as jml 
                                  from kategori left join produk 
                                  on produk.id_kategori=kategori.id_kategori 
                                  group by nama_kategori");
						while($r=mysql_fetch_array($kategori)){

						echo"<div class='col-md-3 col-sm-6'>
							<div class=' panel b-a'>
							<div class='clearfix item-listing-title'>
								<a href='#' class='pull-left m-l-sm m-t-sm m-r-sm thumb-md'><img src='static/foto_kategori/$r[icon]' ></a>
								<div class='clear'>
									<div class='m-r-xs text-md font-bold'>
										<a href='kategori-$r[id_kategori]-$r[kategori_seo].html' class='text-grey'><h2 class='text-md font-bold m-t-sm text-ellipsis'>$r[nama_kategori]  </h2></a>
									</div>
									<div class='pull-left text-sm m-t-n-xs row padder w-lg'>
										<a class='text-muted' href='#' title=''><img width='16' class='m-b-xs' height='16' src='static/foto_kategori/$r[icon]'></a>
										<span class='m-l-xs m-b-sm text-muted'><a class='text-muted' href='#' title=''>$r[label]</a></span>
										<br>
										<img width='12' height='12' src='static/img/star-on.png' alt=''/>
										<img width='12' height='12' src='static/img/star-on.png' alt=''/>
										<img width='12' height='12' src='static/img/star-on.png' alt=''/>
										<img width='12' height='12' src='static/img/star-on.png' alt=''/>
									</div>
									<div class='text-sm m-r-sm m-t-n-md pull-right'>
										<div class='m-t-xs'>
											<strong>$r[jml] item</strong>
										</div>
									</div>
								</div>
							</div>
						</div>
						</div>";
						}
					?>					
				</div>
							
			</div>
		</div>
</div>
<script>liveReqInit('livesearch','liveRequestResults','search-ls.php','','mainResult');</script>