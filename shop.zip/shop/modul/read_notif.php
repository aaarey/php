	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>
	<div class="container m-t-md">
	<div class="row"><div class="col-sm-12 link-in">
		<div class="panel b-a">
			<div class="panel-heading b-b b-light">
					<span class="font-bold"><i class="ion-chatbox-working m-r-xs"></i> Notifikasi</span>
			</div>		
			<div class="panel-body link-info">


			<?php
				$edit=mysql_query("SELECT * FROM informasi A INNER JOIN
									admins B ON A.created_userid=B.id_users
									WHERE A.id_informasi='$_GET[id]'");
				$r=mysql_fetch_array($edit);
				mysql_query("UPDATE informasi SET dibaca='Y' WHERE id_informasi='$_GET[id]'");	
				$tgl=tgl_indo($r['tanggal']);
				$photo = "<img src='static/img/fb.jpg' width='60' height='70' style='border-radius: 8px; border: 2px solid #CCCCCC;'>";
			?>    
			    <table border="0" width="100%" class="tr" cellspacing="0">
			    	<tr>
			    		<td width='70' rowspan="4"><?php echo $photo; ?></td>
			    		<td width='60'>Tanggal</td>
			    		<td width='10'>:</td>
			    		<td><?php echo $tgl; ?></td>
			    	</tr>
			    	<tr>
			    		<td>Dari</td>
			    		<td>:</td>
			    		<td><?php echo $r['nama_lengkap']; ?></td>
			    	</tr>					
			    	<tr>
			    		<td>Judul</td>
			    		<td>:</td>
			    		<td><?php echo $r['judul']; ?></td>
			    	</tr>
			    	<tr>
			    		<td>Pesan</td>
			    		<td>:</td>
			    		<td><?php echo $r['pesan']; ?></td>
			    	</tr>
				</table><br>
					<a href='javascript:history.go(-1)'><button type='button' class='btn btn-black'><i class="ion-arrow-left-a"></i> Kembali</button></a>	
				</div>

	</div>
	
	</div></div>
</div>