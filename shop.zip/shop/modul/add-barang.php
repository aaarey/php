	<script language="javascript" src="js/harga.js"></script>
	<script type="text/javascript" src="js/ajaxupload.3.5.js" ></script>
	<link rel="stylesheet" type="text/css" href="css/Ajaxfile-upload.css" />
	<script type="text/javascript" >
		$(function(){
		var btnUpload=$('#me');
		var mestatus=$('#mestatus');
		var files=$('#files');
		new AjaxUpload(btnUpload, {
			action: 'upload_image1.php',
			name: 'uploadfile',
			onSubmit: function(file, ext){
				 if (! (ext && /^(jpg|jpeg)$/.test(ext))){ 
                    // extension is not allowed 
					mestatus.text('Only JPG file are allowed');
					return false;
				}
				mestatus.html('');
			},
			onComplete: function(file, response){
				//On completion clear the status
				mestatus.text('');
				//On completion clear the status
				files.html('');
				//Add uploaded file to list
				if(response!=="error"){
					$('<li></li>').appendTo('#files').html('<img src="static/products/foto_produk/'+response+'" alt="" width="70" height="70" style="border-radius: 10px; margin-left: -3px; margin-top:-80px; border: 3px solid #ccc"/><br />').addClass('success');
					$('<li></li>').appendTo('#adv').html('<input type="hidden" name="filename" value="'+response+'">').addClass('nameupload');
					
				} else{
					$('<li></li>').appendTo('#files').text(file).addClass('error');
				}
			}
		});

		var btnUpload2=$('#me2');
		var mestatus2=$('#mestatus2');
		var files2=$('#files2');
		new AjaxUpload(btnUpload2, {
			action: 'upload_image2.php',
			name: 'uploadfile2',
			onSubmit: function(file, ext){
				 if (! (ext && /^(jpg|jpeg)$/.test(ext))){ 
                    // extension is not allowed 
					mestatus.text('Only JPG file are allowed');
					return false;
				}
				mestatus.html('');
			},
			onComplete: function(file, response){
				//On completion clear the status
				mestatus2.text('');
				//On completion clear the status
				files2.html('');
				//Add uploaded file to list
				if(response!=="error"){
					$('<li></li>').appendTo('#files2').html('<img src="static/products/foto_produk/'+response+'" alt="" width="70" height="70" style="border-radius: 10px; margin-left: -3px; margin-top:-80px; border: 3px solid #ccc"/><br />').addClass('success2');
					$('<li></li>').appendTo('#adv2').html('<input type="hidden" name="filename2" value="'+response+'">').addClass('nameupload2');
					
				} else{
					$('<li></li>').appendTo('#files2').text(file).addClass('error');
				}
			}
		});

		var btnUpload3=$('#me3');
		var mestatus3=$('#mestatus3');
		var files3=$('#files3');
		new AjaxUpload(btnUpload3, {
			action: 'upload_image3.php',
			name: 'uploadfile3',
			onSubmit: function(file, ext){
				 if (! (ext && /^(jpg|jpeg)$/.test(ext))){ 
                    // extension is not allowed 
					mestatus.text('Only JPG file are allowed');
					return false;
				}
				mestatus.html('');
			},
			onComplete: function(file, response){
				//On completion clear the status
				mestatus3.text('');
				//On completion clear the status
				files3.html('');
				//Add uploaded file to list
				if(response!=="error"){
					$('<li></li>').appendTo('#files3').html('<img src="static/products/foto_produk/'+response+'" alt="" width="70" height="70" style="border-radius: 10px; margin-left: -3px; margin-top:-80px; border: 3px solid #ccc"/><br />').addClass('success3');
					$('<li></li>').appendTo('#adv3').html('<input type="hidden" name="filename3" value="'+response+'">').addClass('nameupload3');
					
				} else{
					$('<li></li>').appendTo('#files3').text(file).addClass('error');
				}
			}
		});

		
		});
	</script>
	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>
<body onLoad="document.postform.elements['harga'].focus();">		
<?php
session_start();
$aksi="modul/aksi_barang.php";
switch($_GET[act]){
	default:

	echo"  <div id='content' class='main-content bg-lights'><div class='container'>
			<div class='m-t-md'></div>
				<div class='row'>
					<form method=POST action='$aksi?module=barang&act=input' enctype='multipart/form-data' id='postform' name='postform'>
						<div class='col-sm-8 link-info'>
							<div class='panel panel-default'>
								<div class='panel-heading font-bold'>Jual Barang</div>
								<div class='panel-body'>
									<div class='form-group'>
										<label class='col-lg-2 control-label'>Nama Barang</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' id='name' name='nama_produk' required='true' maxlength='50' placeholder='Nama barang'>
											<span class='help-block'></span>
										</div>
									</div>
									<div class='form-group'>
										<label class='col-lg-2 control-label'>Kategori</label>
										<div class='col-lg-10'>
											<select name='kategori' class='form-control text-sm'>";
											    $tampil=mysql_query("SELECT * FROM kategori ORDER BY nama_kategori");
												while($r=mysql_fetch_array($tampil)){
													echo "<option value=$r[id_kategori]>$r[nama_kategori]</option>";
												}
											echo"</select>
											<span class='help-block'></span>
										</div>
									</div>
									<div class='form-group'>
										<label class='col-lg-2 control-label'>Kondisi</label>
										<div class='col-lg-10'>
											<div class='radio'>
												<label for='account_type_business'>
												<input id='account_type' name='kondisi' value='Baru' type='radio'>Baru</label>
											</div>
											<div class='radio'>
												<label for='account_type_personal'>
												<input id='account_type' name='kondisi' value='Bekas' type='radio' >Bekas</label>
											</div>
										</div>
									</div>";	
									?>
										
									<div class='form-group '>
										<label class='col-lg-2 control-label '>Harga</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' onKeyup='ri();'  name='harga' value='0'>
											<span class='help-block'></span>
										</div>
									</div>
									<?php
									echo"<div class='form-group '>
										<label class='col-lg-2 control-label'>Diskon</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' placeholder='Diskon %' name='diskon' value=''>
											<span class='help-block'></span>
										</div>
									</div>		
									<div class='form-group '>
										<label class='col-lg-2 control-label '>Stok</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' required='true' placeholder='Stok Barang' name='stok' value=''>
											<span class='help-block'></span>
										</div>
									</div>			
									<div class='form-group '>
										<label class='col-lg-2 control-label'>Berat</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' placeholder='Gram' name='berat' value=''>
											<span class='help-block'></span>
										</div>
									</div>									
									<div class='form-group'>
										<label class='col-sm-2 control-label'>Keterangan</label>
										<div class='col-sm-10'>
											<textarea name='deskripsi' style='width: 450px; height: 150px;' class='ckeditor'></textarea>
										</div>
									</div>
									
									
									<div class='form-group'>
										<label class='col-lg-2 control-label m-t-md '>Gambar</label>
											<tr valign='top'>

												<td style='padding-bottom: 5px; padding-top: 5px; padding-right: 5px;'>
													<table>
														<tr>
															<td width='280'>
																<table>
																	<tr>
																		<td height='90'>
																			<div id='me' style='cursor:pointer; height: 70px; width: 75px;'>
																				<button class='button_profile'><img src='css/plus.png' width='50'></button>
																					
																				<div id='adv'>
																					<li class='nameupload'></li>
																				</div>
																				<div id='files'>
																					<li class='success'></li>
																				</div>
																			</div>
																			<span id='mestatus' ></span>
																		</td>
																		<td>
																			<div id='me2' style='cursor:pointer; height: 70px; width: 75px;'>
																				<button class='button_profile'><img src='css/plus.png' width='50'></button>
																					
																				<div id='adv2'>
																					<li class='nameupload2'></li>
																				</div>
																				<div id='files2'>
																					<li class='success2'></li>
																				</div>
																			</div>
																			<span id='mestatus' ></span>
																		</td>	
																		<td>
																			<div id='me3' style='cursor:pointer; height: 70px; width: 75px;'>
																				<button class='button_profile'><img src='css/plus.png' width='50'></button>
																					
																				<div id='adv3'>
																					<li class='nameupload3'></li>
																				</div>
																				<div id='files3'>
																					<li class='success3'></li>
																				</div>
																			</div>
																			<span id='mestatus' ></span>
																		</td>																			
																	</tr>
																</table>
															</td>
															<td align='left'>
																<div class='alert'>
																	&bull; Iklan dengan banyak foto, lebih direspon oleh pembeli.<br>
																	&bull; Iklan dengan foto mampu meningkatkan respon hingga 3x lipat.
																</div>
															</td>
														</tr>
													</table>						
												</td>
											</tr>
									</div>									
									
									
									<div class='form-group'>
										<div class='col-sm-4 col-sm-offset-2 m-t-md'>
											<input type='hidden' name='upload' value='yes'/>
											<button type='submit' id='submit-btn' class='btn btn-black'><i class='ion-checkmark-circled'></i> Simpan</button>
											<a href='javascript:history.go(-1)'><button type='button' class='btn btn-black'><i class='ion-arrow-left-a'></i> Kembali</button></a>											
										</div>
									</div>									
								</div>
							</div>
							
						</div>

							<div class='col-sm-4 '>
							<div class='panel b-a'>
								<div class='panel-heading b-b b-light'>
									<span class='font-bold'><i class='ion-compose m-r-xs'></i> Catatan</span>
								</div>
								<div class='panel-body link-info'>

	        <ul>
	        	<li>Masukan nama produk yang akan kamu jual </li>
	        	<li>Pastikan stok barang tercukupi</li>
	        	<li>Upload gambar bertipe JPG, PNG</li>

	        	
	        </ul>
								</div>
								<div class='panel-footer bg-light lter text-center '>
									<img src='static/img/mandiri.png' height='32' width='32' class='m-r-sm m-t-n m-b-n'>
									<img src='static/img/bni.png' height='32' width='32' class='m-r-sm m-t-n m-b-n'>
									<img src='static/img/bri.png' height='32' width='32' class='m-r-sm m-t-n m-b-n'>
								</div>								
							</div>
						</div>

						
					</form>
				</div>
			</div>
		</div>
		</div>";
		
	
	
	
	
	break;
	

}
?>
</body>