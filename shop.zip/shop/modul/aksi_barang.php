<?php
session_start();
if ($_SESSION['email'] == ''){
	header("Location: sign-in.html?err=log");
}
else{
include "../config/koneksi.php";
include "../config/library.php";
//include "../config/fungsi_thumb.php";
include "../config/fungsi_seo.php";


$module=$_GET['module'];
$act=$_GET[act];

if ($module=='barang' AND $act=='input'){
	$harga=str_replace(".","",$_POST['harga']);
  /*
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 
	*/
	if ($_POST['filename'] != ''){
		$file = "../static/products/foto_produk/".$_POST['filename'];
		$gbr_asli = imagecreatefromjpeg($file);
		$lebar = imagesx($gbr_asli);
		$tinggi = imagesy($gbr_asli);
		
		$tum_lebar = 150;
		$tum_tinggi = 150;
		
		$gbr_thumb = imagecreatetruecolor($tum_lebar, $tum_tinggi);
		imagecopyresampled($gbr_thumb, $gbr_asli, 0, 0, 0, 0, $tum_lebar, $tum_tinggi, $lebar, $tinggi);
		
		imagejpeg($gbr_thumb, "../static/products/foto_produk/thumb/small_".$_POST['filename']);
		
		imagedestroy($gbr_asli);
		imagedestroy($gbr_thumb);
	}
	if ($_POST['filename2'] != ''){
		$file = "../static/products/foto_produk/".$_POST['filename2'];
		$gbr_asli = imagecreatefromjpeg($file);
		$lebar = imagesx($gbr_asli);
		$tinggi = imagesy($gbr_asli);
		
		$tum_lebar = 150;
		$tum_tinggi = 150;
		
		$gbr_thumb = imagecreatetruecolor($tum_lebar, $tum_tinggi);
		imagecopyresampled($gbr_thumb, $gbr_asli, 0, 0, 0, 0, $tum_lebar, $tum_tinggi, $lebar, $tinggi);
		
		imagejpeg($gbr_thumb, "../static/products/foto_produk/thumb/small_".$_POST['filename2']);
		
		imagedestroy($gbr_asli);
		imagedestroy($gbr_thumb);
	}		
	if ($_POST['filename3'] != ''){
		$file = "../static/products/foto_produk/".$_POST['filename3'];
		$gbr_asli = imagecreatefromjpeg($file);
		$lebar = imagesx($gbr_asli);
		$tinggi = imagesy($gbr_asli);
		
		$tum_lebar = 150;
		$tum_tinggi = 150;
		
		$gbr_thumb = imagecreatetruecolor($tum_lebar, $tum_tinggi);
		imagecopyresampled($gbr_thumb, $gbr_asli, 0, 0, 0, 0, $tum_lebar, $tum_tinggi, $lebar, $tinggi);
		
		imagejpeg($gbr_thumb, "../static/products/foto_produk/thumb/small_".$_POST['filename3']);
		
		imagedestroy($gbr_asli);
		imagedestroy($gbr_thumb);
	}		
	$ref_id = $_SESSION['useri'].date('Ymdhis');	
	$produk_seo      = seo_title($_POST['nama_produk']);  
	$gram = $_POST['berat']/1000;

		//UploadImage($nama_file_unik);
			mysql_query("INSERT INTO produk(nama_produk,
											ref_id,
											produk_seo,
											id_kategori,
											id_kustomer,
											berat,
											kondisi,
											harga,
											diskon,
											stok,
											deskripsi,
											tgl_masuk,
											gambar,
											gambar2,
											gambar3) 
									VALUES('$_POST[nama_produk]',
											'$ref_id',
										   '$produk_seo',
										   '$_POST[kategori]',
										   '$_SESSION[useri]',
										   '$gram',
										   '$_POST[kondisi]',
										   '$harga',
										   '$_POST[diskon]',
										   '$_POST[stok]',
										   '$_POST[deskripsi]',
										   '$tgl_sekarang',
										   '$_POST[filename]',
										   '$_POST[filename2]',
										   '$_POST[filename3]')");
		  header('location:../my-produk.html?succ=ok');		


	}
}
?>