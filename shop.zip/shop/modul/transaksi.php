	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>
<?php	

$sql = mysql_query("SELECT * FROM orders A INNER JOIN
					kustomer B ON A.id_kustomer=B.id_kustomer INNER JOIN
					orders_detail C ON C.id_orders=A.id_orders INNER JOIN
					produk D ON D.id_produk=C.id_produk
					WHERE B.id_kustomer='$_SESSION[useri]'  ORDER BY A.id_orders");
$no =1;	
$t=mysql_num_rows($sql);			
if($t=='0'){
    echo "<script>window.alert('Belum ada History Belanja');
        window.location=('index.php')</script>";
}
else{

	echo " <div id='content' class='main-content bg-lights'>
<div class='container'><div class='m-t-md'></div>
				<div class='row'>
					<div class='col-sm-12 link-info'>
						<div class='panel b-a'>
							<div class='panel-heading b-b b-light'>
								<span class='font-bold'><i class='fa fa-exchange m-r-xs'></i> History Belanja</span>
							</div>	
	<table class='table table-striped m-b-none'>
		<thead class='panel-heading b-b b-light'>
			<tr>
				<th>#</th>	
				<th>Transaksi</th>
				<th>Tgl Pemesan</th>
				<th>Pemesanan</th>
				<th>Qty</th>		
				<th>Total</th>
				<th>Status</th>
				<th>Aksi</th>
			</tr></thead><tbody>";
	while($data = mysql_fetch_array($sql)){
		$tanggal=tgl_indo($data[tgl_order]);
		$harga  = format_rupiah($data[harga]);
		$subtotal = ($data[harga]) * $data[jumlah];
		$subtotal_rp = format_rupiah($subtotal);
		$total  = $total + $subtotal;			
		$total_rp  = format_rupiah($total); 
		
		if($data['status_order']=='Dibayar'){
			$warning="fa-stack fa-lg icon-green";
		} 
		elseif($data['status_order']=='Konfirmasi'){
			$warning="fa-stack fa-lg icon-green";
		}
		elseif($data['status_order']=='Dikembalikan'){
			$warning="fa-stack fa-lg icon-green";
		}		
		elseif($data['status_order']=='Pending'){
			$warning="fa-stack fa-lg icon-green";
		}		
	?>
		<tr>
			<td><?php echo $no;?></td>			
			<td><span class='label label-info'><?php echo $data[akun]; ?></span></td>
			<td> <?php echo $tanggal; ?></td>
			<?php
			echo"<td><a href='produk-$data[id_produk]-$data[produk_seo].html' target='_blank'>$data[nama_produk]</a></td>";
			?>
			<td><?php echo $data[jumlah];?> x @<?php echo $harga; ?></td>
			<td>Rp. <?php echo $subtotal_rp; ?></td>
			<td>
			<span title='pending' <?php if ($data['pending'] == '1'){ echo "class='fa-stack fa-lg icon-green'";}
								else { echo "class='fa-stack fa-lg icon-grey'";} ?>><i class="fa fa-circle fa-stack-2x"></i>
				<i class="fa fa-hourglass-half fa-stack-1x fa-inverse"></i></span>

			<span title='dibayar' <?php if ($data['dibayar'] == '1'){ echo "class='fa-stack fa-lg icon-green'";}
								else { echo "class='fa-stack fa-lg icon-grey'";} ?>><i class="fa fa-circle fa-stack-2x"></i>
				<i class="fa fa-money fa-stack-1x fa-inverse"></i></span>

			<span title='dikirim' <?php if ($data['dikirim'] == '1'){ echo "class='fa-stack fa-lg icon-green'";}
								else { echo "class='fa-stack fa-lg icon-grey'";} ?>><i class="fa fa-circle fa-stack-2x"></i>
				<i class="fa fa-truck fa-stack-1x fa-inverse"></i></span>
				
			<span title='diterima' <?php if ($data['diterima'] == '1'){ echo "class='fa-stack fa-lg icon-green'";}
								else { echo "class='fa-stack fa-lg icon-grey'";} ?>><i class="fa fa-circle fa-stack-2x"></i>
				<i class="ion-android-done-all fa-stack-1x fa-inverse"></i></span>		
			</td>			

	<?php
		if($data['status_order']=='Dikirim'){
			echo"<td><span class='label label-success'><i class='ion-checkmark'></i> Transaksi Dikirim  </span>&nbsp;
				<span class='label label-info'><a href='send-transaksi-1-$data[id_orders].html'><font color='white'>Konfirmasi diterima?</font></a></td>";
		}
		elseif($data['status_order']=='Konfirmasi'){
			echo"<td><span class='label label-warning'> Menunggu Verifikasi ..</td>";	
		}
		elseif($data['status_order']=='Dibayar'){
			echo"<td><span class='label label-warning'> Menunggu Verifikasi ..</td>";	
		}	
		elseif($data['status_order']=='Diterima'){
			echo"<td><span class='label label-success'> Barang diterima <i class='ion-checkmark-circled'></i></span> &nbsp;
				</td>";	
		}			
		elseif($data['status_order']=='Pending'){
			echo"<td><a class='text-sm' href='add-transaksi-1-$data[id_orders].html'><i class='fa fa-check-square-o'></i> Konfirmasi</a></td>";			
		}
	?> 	          
	</tr>	
	<?php
		$no++;	
			
	}
	?>
	<?php
		echo"</td><tr/>";	
		
	echo "</table></div></div></div></div></div>";	
}
?>


