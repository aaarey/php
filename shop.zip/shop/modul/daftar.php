<?php
include "config/koneksi.php";
?>
<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
</div>	
<div class="container w-xxl w-auto-xs">
	<div class="m-t-md"></div>
	<div class="m-b-lg">
	<?php
	$full_url = full_url();
	if (strpos($full_url, "log=e_log") == TRUE){
		echo "<div class='alert alert-danger'>
				<a href='#' class='close' data-dismiss='alert'>&times;</a><strong>Username atau password tidak valid</strong></div>";
	}
	?>
	<!--<button onclick="facebookLogin()" class="btn btn-lg btn-facebook btn-block m-b"><i class="fa fa-facebook-square m-r-xs"></i> Sign Up with Facebook</button>-->
	<form name="form" action="action_sign_up.php" class="form-validation" id="frm_sign_in" method="post">
	<?php
		if (strpos($full_url, "?frm=yes") == TRUE){
			echo "<input type='hidden' name='iden' value='1'>";
		}
	?>
        <p class="text-center m-t-lg m-b"><small>Masukan identitas anda</small></p>	
		<div class="list-group list-group-sm">
			<div class="list-group-item">
				<input id="nama" name="username" type="text" placeholder="Username.." class="form-control no-border text-grey" required></div>		
			<div class="list-group-item">
				<input id="username" name="email" type="text" placeholder="Email.." class="form-control no-border text-grey" required></div>
			<div class="list-group-item">
				<input id="password" name="password" type="password" placeholder="Password .." class="form-control no-border text-grey" required></div>

			<div class="list-group-item">
				<input id="nama" name="retype_password" type="password" placeholder="Ulangi Password" class="form-control no-border text-grey" required></div>				
			</div>
			<p class="text-center link-info">
				<small>Dengan menekan Daftar Akun, saya mengkonfirmasi telah menyetujui Syarat dan Ketentuan, serta Kebijakan Privasi marketstore</small>
			</p>		
			<button type="submit" name="add" class="btn btn-lg btn-black btn-block">Daftar</button>			

		<div class="line line-dashed"></div>
		<p class="text-center">
			<small><a href="login.php" class='text-sm'>Sudah memiliki akun? Login disini</a></small>
		</p>
	</form>
	
	</div>

	<div class="text-center">
		<p></p>
	</div>
</div>