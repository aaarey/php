<script>
	function checkAll(bx) {
		var cbs = document.getElementsByTagName('input');
		for(var i=0; i < cbs.length; i++) {
			if(cbs[i].type == 'checkbox') {
				cbs[i].checked = bx.checked;
			}
		}
	}
</script>
<?php
$aksi="modul/aksi-notif.php";
?>
<div class="container">
	<div class="m-t-md"></div>
	<div class="col-sm-12 ">
		<div class="row row-sm">
			<?php
			$full_url = full_url();
			if (strpos($full_url, "?suc=ok") == TRUE){
				echo "<div class='messagesuccess' style='width: auto;'><p><b>Your ads successfully saved and in moderation proccessing.<br>
						Your ads will activate and show in site after pass our review in 24 hours. Good Luck!</b></p></div>";
			}
			if (strpos($full_url, "?suc=delete") == TRUE){
				echo "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert'>&times;</a>
						<strong><i class='ion-android-done-all'></i> Sukses!</strong> chat anda berhasil dihapus
						</div>";		
			}			

			?>

			
			<div id='myTabContent' class='tab-content'>
				<div class='tab-pane active in' id='in'>
					<div class="container m-t-md">
						<div class="row">
						
							<div class="panel b-a ">
							<div class='panel-heading b-b b-light'>
								<span class='font-bold'><i class='ion-chatbox-working'></i> Notifikasi</span>
							</div>	

							<form method='POST' action='#'>    
							<table class="table table-striped m-b-none">
								<thead class="panel-heading b-b b-light">
									<th>#</th>
									<th>Tanggal</th>
									<th>Judul</th>
									<th>Aksi</th>
								</tr>	</thead><tbody>						
							<?php
							$p      = new Paging;
							$batas  = 10;
							$posisi = $p->cariPosisi($batas);	
				
								
								$sql_ads = mysql_query("SELECT * FROM informasi A INNER JOIN 
												admins B ON A.created_userid =B.id_users
												ORDER BY A.id_informasi DESC LIMIT $posisi,$batas");
								$no = $posisi+1;
								while ($r =mysql_fetch_array($sql_ads)){
								   $tgl=tgl_indo($r['tanggal']);
								if($r['dibaca']=='N'){
									echo "<tr>
										<td><b>$no</b></td>
										<td><b>$tgl</b></td>
										<td><b>$r[judul]</b></td>
										<td><a href='read-notif-1-$r[id_informasi].html' class='text-sm'><i class='fa fa-eye' aria-hidden='true'></i></a></td></tr>";
								}
								else{
									echo "<tr>
										<td>$no</b></td>
										<td>$tgl</b></td>
										<td>$r[judul]</b></td>
										<td><a href='read-notif-1-$r[id_informasi].html' class='text-sm'><i class='fa fa-eye' aria-hidden='true'></i></a></td></tr>";
								}			
								$no++;	
								}
								?>
							</tbody></table>
							</div>
	
							</form>
							<?php
							$jmldata = mysql_num_rows(mysql_query("SELECT * FROM as_chat"));
							$jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
							$linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

							echo "<div class='text-right m-b-sm'>
								<ul class='pagination pagination-md'>
									<li><a href='#'>Halaman : $linkHalaman </a></li>
								</ul></div>";								
							?>		
							
						</div>
					</div>
					</div>
				
					
					
					
			</div>
		</div>
		</div>
	</div>
</div>	