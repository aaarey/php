  <div id="content" class="main-content bg-lights">
	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row">
			<div class="col-sm-8">
		  		<div class="text-xs m-t-xs text-muted"> <?php include "breadcumb.php"; ?></div>	 	  
				<h1 class="h2 font-thin m-t-sm m-b-sm">Hubungi E-Lapak</h1>
			</div>
			<div class="col-sm-4"></div>		
			</div>		
		</div>    
	</div>
<div class="container m-t-md">
	<div class="panel wrapper b-a text-md">
		<form class="form-horizontal" action="action_contact.php" method="post">
		    <div class="form-group">
				<label class="col-lg-2 control-label text-sm">Subject</label>
					<div class="col-lg-10">
						<input type="text" id="subjek" name="subjek" required="true" value="" maxlength="50" class="form-control text-sm">
					</div>
	        </div>
		    <div class="form-group">
				<label class="col-lg-2 control-label text-sm">E-mail</label>
					<div class="col-lg-10">
						<input type="text" id="subjek" name="email" value="" required="true" maxlength="50" class="form-control text-sm">
					</div>
	        </div>			
		    <div class="form-group">
	            <label class="col-lg-2 control-label text-sm">Kategori Bantuan</label>
					<div class="col-lg-10">
				    <select class="form-control  text-sm" name="bantuan">
							<option value='Pembayaran' <?php if($r['bantuan']=='Pembayaran'){echo 'selected';} ?>>Pembayaran</option>
							<option value='Pengiriman' <?php if($r['bantuan']=='Pengiriman'){echo 'selected';} ?>>Pengiriman</option>
							<option value='Penjualan' <?php if($r['bantuan']=='Penjualan'){echo 'selected';} ?>>Penjualan</option>
							<option value='Pelanggaran' <?php if($r['bantuan']=='Pelanggaran'){echo 'selected';} ?>>Pelanggaran</option>
							<option value='Promo' <?php if($r['bantuan']=='Promo'){echo 'selected';} ?>>Promo</option>
					</select>	           
					</div>
	        </div>	            
	       	<div class="form-group">
	              <label class="col-lg-2 control-label text-sm">Deskripsi</label>
	              <div class="col-lg-10">
					 <textarea name='deskripsi' style='width: 450px; height: 150px;' class='ckeditor'></textarea>           
	              </div>
	        </div>    

	       	<div class="form-group">
	              <label class="col-lg-2 control-label"></label>
	              <div class="col-lg-10">
					<button type="submit" class="btn btn-black"><i class='ion-android-checkmark-circle'></i> Kirim</button>	              </div>
	        </div>  	            
	            
	            
	            
	</form>
  </div>
	
			
			
			

	
  


	</div>	
	    	
	    	


  </div>
