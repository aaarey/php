<?php
error_reporting(0);
include "../config/koneksi.php";


if(isset($_POST['email_report']))//If a username has been submitted
{
	$email = mysql_real_escape_string($_POST['email_report']);
	if (filter_var($email, FILTER_VALIDATE_EMAIL)){
		echo "1";
	}
	else{
		echo "2";
	}
}
?>