<?php
session_start();
if ($_SESSION['email'] != ''){
include "../config/koneksi.php";
include "../config/library.php";
include "../config/fungsi_thumb.php";
include "../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET['act'];

//Add 
if ($module=='favorit' AND $act=='input'){
	$tanggal = date('Y-m-d H:i:s');	
  mysql_query("INSERT INTO favorit(id_kustomer, id_produk)
				VALUES('$_SESSION[useri]','$_GET[id]')");
				
      header('location:../my-favorit.html?suc=ok');
}
elseif ($module=='favorit' AND $act=='hapus'){
	mysql_query("DELETE FROM favorit WHERE id_favorit='$_GET[id]'");
	header("Location: ../my-favorit.html?suc=delete");
}
}
else{
	header("Location: ../login.html?err=log");
}
?>