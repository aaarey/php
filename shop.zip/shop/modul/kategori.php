	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>	
<div class="container">
	<div class="m-t-md"></div>

		<div class="col-sm-12 ">
			<div class="row row-sm">	
			<?php
			$query = mysql_query("SELECT nama_kategori from kategori where id_kategori='$_GET[id]'");
			$n = mysql_fetch_array($query);
			
			$p      = new Paging3;
			$batas  = 6;
			$posisi = $p->cariPosisi($batas);	
			  
			$sql = mysql_query("SELECT * FROM produk WHERE id_kategori='$_GET[id]' 
						ORDER BY id_produk DESC LIMIT $posisi,$batas");		 
			$jumlah = mysql_num_rows($sql);	
			
			if ($jumlah > 0){	
				while ($r=mysql_fetch_array($sql)){
				$content_slide = strip_tags($r['deskripsi']); 
				$content_s = substr($content_slide,0,100); 
				$content_s = substr($content_s,0,strrpos($content_slide," "));					
				include "disc.php";
					echo"<div class='col-md-3 col-sm-4'>
							<div class='item-panel panel b-a'>
								<div class='item m-l-n-xxs m-r-n-xxs'>
									<div class='pos-rlt'>
										<div class='ribbon ribbon-black'>
											<span>Baru</span>
										</div>
										<a href='produk-$r[id_produk]-$r[produk_seo].html'>
										<img src='static/products/foto_produk/$r[gambar]' width='640px' height='150px' class='img-full'></a>
									</div>
								</div>
								<div class='row no-gutter '>
									<div class='m-l-sm m-b-xs m-r-sm m-t-xs font-bold'>
										<a class='text-sm' href='produk-$r[id_produk]-$r[produk_seo].html'>$r[nama_produk] </a>
									</div>
								</div>	
								<div class='row no-gutter item-listing-desc'>
									<div class='m-l-sm m-b-xs m-r-sm m-t-xs'>
										$content_s
									</div>
								</div>
								<div class='row no-gutter item-listing-extra'>
		      <div class='m-l-sm m-b-sm pull-left'>

			     <a rel='nofollow' href='produk-$r[id_produk]-$r[produk_seo].html' data-toggle='tooltip' data-placement='top' title='Detail' class='btn btn-sm btn-icon btn-default'>
				 <i class='fa fa-desktop'></i></a>
				 
				$tombol
		      </div>

									<div class='m-b-sm m-r-sm m-t-sm pull-right font-bold  text-lg'>
										<a href='#' class='btn btn-black m-t-n-md '><del></del> $divharga</a>
				      				</div>		
									
								</div>
								
							</div>
						</div>";				

				}
				echo"</div>";
				  $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM produk WHERE id_kategori='$_GET[id]'"));
				  $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
				  $linkHalaman = $p->navHalaman($_GET[halkategori], $jmlhalaman);				
				  echo "<div class='text-right m-b-sm'>
						<ul class='pagination pagination-md'>
							<li><a href='#'>Halaman : $linkHalaman </a></li>
						</ul></div>";
			}
			else{
				echo "<div class='alert alert-warning'><a href='#' class='close' data-dismiss='alert'>&times;</a>
												<strong><i class='ion-alert-circled'></i> Not Found, </strong> Belum ada kategori produk disini!
											</div>";
			}
			?>
		

						
			
					
					
					
			</div>

	</div>