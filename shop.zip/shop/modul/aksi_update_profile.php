<?php
error_reporting(0);
session_start();
include "../config/koneksi.php";
include "../config/fungsi_thumb.php";

if ($_SESSION['email'] != ''){

/*	
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 	
*/
	
	
	if ($_POST['password']!=''){
		if ($_POST['filename'] != ''){
			$file = "../static/products/foto_member/".$_POST['filename'];
			$gbr_asli = imagecreatefromjpeg($file);
			$lebar = imagesx($gbr_asli);
			$tinggi = imagesy($gbr_asli);
			
			$tum_lebar = 150;
			$tum_tinggi = 150;
			
			$gbr_thumb = imagecreatetruecolor($tum_lebar, $tum_tinggi);
			imagecopyresampled($gbr_thumb, $gbr_asli, 0, 0, 0, 0, $tum_lebar, $tum_tinggi, $lebar, $tinggi);
			
			imagejpeg($gbr_thumb, "../static/products/foto_member/thumb/small_".$_POST['filename']);
			
			imagedestroy($gbr_asli);
			imagedestroy($gbr_thumb);
		}
		$password = md5($_POST['password']);
		$data_gambar = mysql_query("SELECT photo FROM kustomer WHERE id_kustomer = $_SESSION[useri]'");
		$r    	= mysql_fetch_array($data_gambar);
		@unlink('../static/products/foto_member/'.$r['photo']);
		@unlink('../static/products/foto_member/thumb/'.'small_'.$r['photo']);
		//UploadProfile($nama_file_unik,'../static/products/foto_member/',300,120);	

	
		mysql_query("UPDATE kustomer SET		nama_lengkap = '$_POST[nama_lengkap]',
												alamat = '$_POST[alamat]',
												daerah = '$_POST[daerah]',
												ktp = '$_POST[ktp]',
												kelamin = '$_POST[kelamin]',
												email = '$_POST[email]',
												hp = '$_POST[hp]',
												alamat = '$_POST[alamat]',
												slogan = '$_POST[slogan]',
												rekening = '$_POST[rekening]',
												password = '$password',
												id_kota = '$_POST[kota]',
												photo = '$_POST[filename]'
												WHERE id_kustomer = '$_SESSION[useri]'");			
			
		header("Location: ../profile.html?suc=ok");
	}
	else{
		mysql_query("UPDATE kustomer SET		nama_lengkap = '$_POST[nama_lengkap]',
												alamat = '$_POST[alamat]',
												daerah = '$_POST[daerah]',
												ktp = '$_POST[ktp]',
												kelamin = '$_POST[kelamin]',
												email = '$_POST[email]',
												rekening = '$_POST[rekening]',												
												id_kota = '$_POST[kota]',
												hp = '$_POST[hp]',
												alamat = '$_POST[alamat]',
												slogan = '$_POST[slogan]',
												photo = '$_POST[filename]'
												WHERE id_kustomer = '$_SESSION[useri]'");			
			
		header("Location: ../profile.html?suc=ok");		
	}
	
}	
else{
	header("Location: ../login.html?err=log");
}
?>