	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>
	
	
				<div class='container m-t-md'>
				<div class='row'>
					<div class='col-sm-12 link-info'>
						<div class='panel b-a'>
							<div class='panel-heading b-b b-light'>
								<span class='font-bold'><i class='fa fa-money m-r-xs'></i> Sukses!!</span>
							</div>
							<div class='panel-body link-info'>
										<div class='input-group'>
											<label for='type'>
											Kode Aktivasi telah dikirim email anda, silahkan melakukan aktifasi segera</label>

										</div>
							</div>
						</div>
					</div>
				</div>
			</div>	