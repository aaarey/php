<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
</div>
<?php
session_start();
$aksi="modul/aksi_write_transaksi.php";
switch($_GET[act]){
  default:
  echo"
	<div class='container m-t-md'>
		<div class='row'>";
		
		 
    $edit = mysql_query("SELECT * FROM orders A LEFT JOIN
										kustomer B ON A.id_kustomer=B.id_kustomer LEFT JOIN
										kota C ON B.id_kota=C.id_kota LEFT JOIN
										shop_pengiriman D ON C.id_perusahaan=D.id_perusahaan
										WHERE A.id_orders='$_GET[id]'");
    $r    = mysql_fetch_array($edit);
    $tanggal=tgl_indo($r['tgl_order']);
    
    if ($r['status_order']=='Dibayar'){
        $pilihan_status = array('Dikirim','Dikembalikan');
    }

    $pilihan_order = '';
    foreach ($pilihan_status as $status) {
	   $pilihan_order .= "<option value=$status";
	   if ($status == $r['status_order']) {
		    $pilihan_order .= " selected";
	   }
	   $pilihan_order .= ">$status</option>\r\n";
    }

    echo "
          <form method=POST action='$aksi?module=laporan&act=update' id='postform' name='postform'>
          <input type=hidden name=id value=$r[id_orders]>
			<div class='col-sm-12 link-info'>
				<div class='panel b-a'> 
          <table class='table table-striped m-b-none'>
          <tr><td>No. Transaksi</td>        <td> $r[id_orders]</td></tr>
          <tr><td>ID Transaksi</td>        <td> $r[akun]</td></tr>
          <tr><td>Tgl Order</td> <td>  $tanggal</td></tr>		  
          <tr><td>Alamat Pengirim</td> <td> $r[alamat]</td></tr>
		  <tr><td>Pengiriman</td> <td> $r[nama_perusahaan] - $r[nama_kota] | Lama Pengiriman : $r[lama] Hari</td></tr>";
	?>
	<?php
          echo"<tr><td>Status Sekarang     </td><td><span class='label label-info'>$r[status_order]</span></td></tr>";
          echo"<tr><td>Ubah Status     </td><td><select  class='form-control no border text-grey' name=status_order>$pilihan_order</select> </td></tr>";
          echo"<tr><td>
			<button type='submit' id='submit-btn' class='btn btn-black'><i class='ion-ios-checkmark-outline'></i> Ubah</button>		  
		  </td></tr>
          </table></div></div></form>";		
	?>	
	
	
	
	
	
	
	
	<?php	
	echo"<div class='col-sm-12 link-info'>
				<div class='panel b-a'>  ";
  // tampilkan rincian produk yang di order
  $sql2=mysql_query("SELECT * FROM orders_detail, produk 
                     WHERE orders_detail.id_produk=produk.id_produk 
                     AND orders_detail.id_orders='$_GET[id]'");  
					 
  echo "<table class='table table-striped m-b-none'>
        <tr><th>Nama Produk</th>
		<th>Berat(Kg)</th>
		<th>Jumlah</th>
		<th>Harga Satuan</th>
		<th>Sub Total</th>
		</tr>";
  
  while($s=mysql_fetch_array($sql2)){
     // rumus untuk menghitung subtotal dan total		
   $disc        = ($s[diskon]/100)*$s[harga];
   $hargadisc   = number_format(($s[harga]-$disc),0,",","."); 
   $subtotal    = ($s[harga]-$disc) * $s[jumlah];

    $total       = $total + $subtotal;
    $subtotal_rp = format_rupiah($subtotal);    
    $total_rp    = format_rupiah($total);    
    $harga       = format_rupiah($s[harga]);

   $subtotalberat = $s['berat'] * $s['jumlah']; // total berat per item produk 
   $totalberat  = $totalberat + $subtotalberat; // grand total berat all produk yang dibeli

    echo "<tr><td>$s[nama_produk]</td><td align=center>$s[berat]</td><td align=center>$s[jumlah]</td>
              <td align=right>$harga</td><td align=right>$subtotal_rp</td></tr>";
  }

  $ongkos=mysql_fetch_array(mysql_query("SELECT * FROM kota,kustomer,orders 
          WHERE kustomer.id_kota=kota.id_kota AND orders.id_kustomer=kustomer.id_kustomer AND id_orders='$_GET[id]'"));
  $ongkoskirim1=$ongkos['ongkos_kirim'];
  $ongkoskirim=$ongkoskirim1 * $totalberat;

  $grandtotal    = $total + $ongkoskirim; 

  $ongkoskirim_rp = format_rupiah($ongkoskirim);
  $ongkoskirim1_rp = format_rupiah($ongkoskirim1); 
  $grandtotal_rp  = format_rupiah($grandtotal);    

echo "<tr><td colspan=4 align=right>Total              Rp. : </td><td align=right><b>$total_rp</b></td></tr>
      <tr><td colspan=4 align=right>Ongkos Kirim       Rp. : </td><td align=right><b>$ongkoskirim1_rp</b>/Kg</td></tr>      
      <tr><td colspan=4 align=right>Berat            : </td><td align=right><b>$totalberat</b> Kg</td></tr>      
      <tr><td colspan=4 align=right>Ongkos Kirim : </td><td align=right><b> Rp. $ongkoskirim_rp</b></td></tr>      
      <tr ><td colspan=4 align=right><b>Total Transfer  </b>     : </td>
							<td align=right><b> Rp. $grandtotal_rp</b></td></tr>
      </table> 
		</div>";
		$data=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));
	?>
		<div class='row-fluid margin-top'>
			<div class='span12'>
				<div class='alert alert-success'>
					<h4>Perhatian:</h4>
					<p>1. Silahkan proses pesanan barang anda ke pelanggan</b></p>
					<p>2. Produk akan dibatalkan apabila tidak diproses selama 2 hari </p>
					<p>3. Apabila butuh bantuan kontak E-Lapak.com : <b><i class='ion-android-call'></i> Telp. <?php echo $data['phone']; ?> - <i class='ion-android-mail'></i> E-mail. <?php echo $data['email']; ?></b></p>					
				</div>
			</div>
		</div>	  
		</div>

	

<?php		  
	echo"</div></div>";	  
    break;  

}
?>