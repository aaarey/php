	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>	
<div id="content" class="main-content bg-light">
	<div class="container">
		<div class="m-t-md"></div>
		<div class="row row-sm">
			<div class="col-md-12">
				<div class="row row-sm">
					<div class="col-sm-4">
						<div class="panel b-a ">
							<div>
								<a href="#"><img src="static/img/jual-barang.jpg" class="img-full "></a>
							</div>
							<div class="panel-body ">
								<div class="link-info ">
									<a href="#" rel="category tag">Jual Barang</a>
								</div>
								<h2 class="h4 m-t-xs h-xs ">Kamu bisa menjual barang dengan Harga yang kamu inginkan. <br/>
								Gunakan foto barangmu yang terbaik untuk meningkatkan minat pembeli.</h2>
							</div>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="panel b-a ">
							<div>
								<a href="#"><img src="static/img/sell.jpg" class="img-full "></a>
							</div>
							<div class="panel-body">
								<div class="link-info ">
									<a href="#" rel="category tag">Kelola Transaksi</a>
								</div>
								<h2 class="h4 m-t-xs h-xs">Kamu dapat mengelola dan memantau transaksi secara langsung pada halaman Transaksi. 
								Setiap transaksi memiliki 3 status: Pending, Dibayar dan Selesai.</h2>
							</div>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="panel b-a ">
							<div>
								<a href="#"><img src="static/img/edit.jpg" class="img-full "></a>
							</div>
							<div class="panel-body">
								<div class="link-info ">
									<a href="#" rel="category tag">Kontak kami</a>
								</div>
								<h2 class="h4 m-t-xs h-xs">Kamu dapat melakukan kontak kami pada menu kontak, tanyakan apabila ada transaksi yang tidak sesuai dengan pembelianmu</h2>

							</div>
						</div>
					</div>

				</div>
			</div>

		</div>
	</div>
</div>