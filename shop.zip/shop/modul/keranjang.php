 <?php
 	include "../config/koneksi.php";
?>
	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>
	
<?php 
if ($_SESSION['email'] == ''){
	header("Location: sign-in.html?err=log");
}
else{

 // Tampilkan produk-produk yang telah dimasukkan ke keranjang belanja
	$sid = $_SESSION['email'];
	$sql = mysql_query("SELECT * FROM orders_temp, produk 
			                WHERE id_session='$sid' AND orders_temp.id_produk=produk.id_produk");
  $ketemu=mysql_num_rows($sql);
  if($ketemu < 1){
    echo "<script>window.alert('Keranjang Belanjanya Masih Kosong');
        window.location=('index.php')</script>";
    }
  else{  
  
 	echo"<div class='container m-t-md'>
				<div class='row'>
					<div class='col-sm-12 link-info'>
						<div class='panel b-a'>
							<div class='panel-heading b-b b-light'>
								<span class='font-bold'><i class='fa fa-cart-plus m-r-xs'></i> Keranjang Belanja</span>
							</div>
						<div>
					<form method='post' action='aksi.php?module=keranjang&act=update'>
					<table class='table table-striped m-b-none'>
					<thead class='panel-heading b-b b-light'>
					<tr>
						<th>#</th>
						<th>Image</th>
						<th>Barang</th>
						<th>Qty</th>
						<th>Harga</th>
						<th>Total</th>
						<th>Aksi</th>
					</tr>
					</thead>
					<tbody></tbody>";
  $no=1;
  while($r=mysql_fetch_array($sql)){
    $disc        = ($r[diskon]/100)*$r[harga];
    $hargadisc   = number_format(($r[harga]-$disc),0,",",".");

    $subtotal    = ($r[harga]-$disc) * $r[jumlah];
    $total       = $total + $subtotal;  
    $subtotal_rp = format_rupiah($subtotal);
    $total_rp    = format_rupiah($total);
    $harga       = format_rupiah($r[harga]);		
	
		echo"<tr>
							<td>$no</td>
							<input type=hidden name=id[$no] value=$r[id_orders_temp]>
							<td>
								<div class='item m-l-n-xxs m-r-n-xxs'>
									<a href='#'><img src='static/products/foto_produk/$r[gambar]' width='640px' height='100px' class='img-full'></a>
								</div>
							</td>
							<td >$r[nama_produk]</td>

							<td>
							<select class='form-control no border text-grey' name='jml[$no]' value=$r[jumlah] onChange='this.form.submit()'>";
							for ($j=1;$j <= $r[stok];$j++){
							  if($j == $r[jumlah]){
							   echo "<option selected>$j</option>";
							  }else{
							   echo "<option>$j</option>";
							  }
						  }
					echo "</select></td>
						  <td>Rp. $hargadisc</td>
						  <td>Rp. $subtotal_rp</td>
							<td><a href='aksi.php?module=keranjang&act=hapus&id=$r[id_orders_temp]'>
							<i class='fa fa-trash-o' aria-hidden='true'></i></a></td>
						</tr>						
					</table>
							</div>
						</div>
					</div>


				</div>
					<a href='index.php' class='btn btn-black m-t-md m-b-sm' type='subtmit'><i class='ion-reply'></i> Belanja Lagi</a>
					<a href='simpan-transaksi-member.html' class='btn btn-success m-t-md m-b-sm' type='submit'>
					<i class='ion-ios-checkmark-outline' aria-hidden='true'></i> Bayar Transaksi</a>					
			</div>";	
			$no++; 
		}

  }
}
?>