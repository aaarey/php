<?php
error_reporting(0);
include "../config/koneksi.php";

$ads_report = $_POST['ads_report'];
$detail = nl2br($_POST['detail_report']);
$email_report = $_POST['email_report'];
$alasan = $_POST['alasan'];
$created_date = date('Y-m-d H:i:s');
$subject = "Report to Admin";

$data = mysql_fetch_array(mysql_query("SELECT * FROM produk WHERE id_produk = '$ads_report'"));

$headers = "From: no-reply@elapak.com \r\n";
$headers .= "Reply-To: ". strip_tags($email_report) . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html;charset=utf-8 \r\n";

$msg  = "<html><body>";
$msg .= "<p>-- Thank you for your report about the ads --</p>\r\n";
$msg .= "<h4>Detail</h4><p>	Ref ID : $data[ref_id]<br>Title : $data[title]</p>";
$msg .= "<p>$detail</p>\r\n";
$msg .= "<p><hr><a href='#'>http://www.elapak.com</a> - Best Solution Ecommerce</p>\r\n";
$msg .= "</body></html>";

$save = mysql_query("INSERT INTO report(					id_produk,
																alasan,
																detail,
																email,
																status,
																created_date)
														VALUES(	'$ads_report','$alasan','$detail','$email_report','1','$created_date')");
    echo "<script>window.alert('	Terimakasih telah, kami akan merespon pertanyaan laporan anda ke email');
        window.location=('index.php')</script>";															
if ($save){
	$send = mail($email_report, $subject, $msg, $headers);
	if ($send){
		echo "true";
	}
	else{
		echo "false";
	}
}
else{
	echo "false";
}
?>