	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>
	
<?php
session_start();
$aksi="modul/aksi-favorit.php";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);
$sql=mysql_query("SELECT * FROM favorit A LEFT JOIN
					produk B ON A.id_produk=B.id_produk LEFT JOIN
					kategori C ON B.id_kategori=C.id_kategori
					WHERE A.id_kustomer='$_SESSION[useri]'
					ORDER BY A.id_favorit");
    $no = $posisi+1;
$r=mysql_num_rows($sql);
if($r ==''){
    echo "<script>window.alert('Belum ada produk favorit');
        window.location=('index.php')</script>";
}
else {
	
echo"<div id='content' class='main-content bg-lights'>
<div class='container'><div class='m-t-md'></div>

				<div class='row'>
					<div class='col-sm-12 link-info'>";
									$full_url = full_url();
									if (strpos($full_url, "?suc=ok") == TRUE){
										echo "<div class='alert alert-success'><a href='#' class='close' data-dismiss='alert'>&times;</a>
												<strong><i class='ion-android-done-all'></i> Sukses!</strong> Produk Favorit
											</div>";										
									}
									if (strpos($full_url, "?suc=delete") == TRUE){
										echo "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert'>&times;</a>
												<strong><i class='ion-android-done-all'></i> Sukses!</strong> Barang favorit anda berhasil dihapus
												</div>";		
									}									
						echo"<div class='panel b-a'>
						
							<div class='panel-heading b-b b-light'>
								<span class='font-bold'><i class='ion-android-favorite m-r-xs'></i> Produk Favorit</span>
							</div>	
							
	<table class='table table-striped m-b-none'>
		<thead class='panel-heading b-b b-light'>
			<tr>
				<th>#</th>	
				<th>Kategori</th>	
				<th>Produk</th>
				<th>Harga</th>
				<th>Aksi</th>
			</tr></thead><tbody>";	
			while($data = mysql_fetch_array($sql)){
						$harga  = format_rupiah($data[harga]);
				echo"<tr>
						<td>$no</td>
						<td>$data[nama_kategori]</td>
						<td>$data[nama_produk]</td>
						<td>$harga</td>
						<td><a href='produk-$data[id_produk]-$data[produk_seo].html'><i class='ion-monitor'></i> Detail</a> |
							<a href='$aksi?module=favorit&act=hapus&id=$data[id_favorit]' onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">
								<i class='ion-trash-b'></i> Hapus</a>
						</td>
					</tr>";
			$no++;
			}
		echo "</tbody></table></div></div>";
    $jmldata = mysql_num_rows(mysql_query("SELECT * FROM favorit"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

				  echo "<div class='text-right m-b-sm'>
						<ul class='pagination pagination-md'>
							<li><a href='#'>Halaman : $linkHalaman </a></li>
						</ul></div>";			
		
	echo"</div></div></div>";
				
}
	


?>