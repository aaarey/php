	<script language="javascript" src="js/harga.js"></script>
	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>
<?php
$data_ads = mysql_fetch_array(mysql_query("SELECT * FROM produk A WHERE A.id_produk = '$_GET[id]'"));
$desc = str_replace("\'", "'", $data_ads['deskripsi']);
?>
<?php
	echo"<div class='container'>
			<div class='m-t-md'></div>
				<div class='row'>
					<form method='POST' action='modul/aksi_update_produk.php' enctype='multipart/form-data' id='postform' name='postform'>
						<input type='hidden' name='id' value='$data_ads[id_produk]' />
						<input type='hidden' name='div' value='$_GET[div]' />
						<input type='hidden' name='page' value='$_GET[page]' />	
					
						<div class='col-sm-8 link-info'>
							<div class='panel panel-default'>
								<div class='panel-heading font-bold'>Jual Barang</div>
								<div class='panel-body'>
									<div class='form-group'>
										<label class='col-lg-2 control-label'>Nama Barang</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' id='name' name='nama_produk' maxlength='50' value='$data_ads[nama_produk]'>
											<span class='help-block'></span>
										</div>
									</div>
									<div class='form-group'>
										<label class='col-lg-2 control-label'>Kategori</label>
										<div class='col-lg-10'>
											<select name='kategori' class='form-control text-sm'>";
												$sql = mysql_query("SELECT * FROM kategori WHERE aktif = 'Y' ORDER BY nama_kategori ASC");
												while ($data = mysql_fetch_array($sql)){
													if ($data_ads['id_kategori'] == $data['id_kategori']){
														echo "<option value='$data[id_kategori]' SELECTED>$data[nama_kategori]</option>";
													}
													else{
														echo "<option value='$data[id_kategori]'>$data[nama_kategori]</option>";
													}
												}
											echo"</select>
											<span class='help-block'></span>
										</div>
									</div>
									<div class='form-group'>
										<label class='col-lg-2 control-label'>Kondisi</label>
										<div class='col-lg-10'>
											<div class='radio'>
												<label for='account_type_business'>";
										?>
												<input type="radio" name="kondisi" value="Baru" <?php if($data_ads['kondisi'] == "Baru"){ echo "CHECKED"; } ?>> Baru </label>
											</div>
											<div class='radio'>
												<label for='account_type_personal'>
												<input type="radio" name="kondisi" value="2" <?php if($data_ads['kondisi'] == "Bekas"){ echo "CHECKED"; } ?>> Bekas </label>
											</div>
										</div>
									</div>										
									<div class='form-group '>
										<label class='col-lg-2 control-label '>Harga</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' onKeyup='ri();' value="<?php echo $data_ads['harga']; ?>" name='harga' value=''>
											<span class='help-block'></span>
										</div>
									</div>
									<div class='form-group '>
										<label class='col-lg-2 control-label'>Diskon</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' value="<?php echo $data_ads['diskon']; ?>" name='diskon' value=''>
											<span class='help-block'></span>
										</div>
									</div>		
									<div class='form-group '>
										<label class='col-lg-2 control-label '>Stok</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' value="<?php echo $data_ads['stok']; ?>" name='stok' value=''>
											<span class='help-block'></span>
										</div>
									</div>			
									<div class='form-group '>
										<label class='col-lg-2 control-label'>Berat</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' value="<?php echo $data_ads['berat']; ?>" name='berat' value=''>
											<span class='help-block'></span>
										</div>
									</div>									
									<div class='form-group'>
										<label class='col-sm-2 control-label'>Keterangan</label>
										<div class='col-sm-10 '>
											<textarea name='deskripsi' style='width: 450px; height: 150px;' class='ckeditor'><?php echo $desc; ?></textarea>
										</div>
									</div>
									<div class="form-group">
										<label class="col-lg-2 control-label m-t-md "></label>
										<div class="col-lg-10">
											<?php if ($data_ads['gambar'] != ''){
												echo "<img src='static/products/foto_produk/$data_ads[gambar]' width='70' height='70' style='border-radius: 15px; margin-left: -10px; margin-bottom: -10px; margin-top: -10px; margin-right: -10px;'>";
												echo "<img src='static/products/foto_produk/$data_ads[gambar2]' width='70' height='70' style='border-radius: 15px; margin-left: -10px; margin-bottom: -10px; margin-top: -10px; margin-right: -10px;'>";
												}
												else{
													echo "<img src='images/add.png' width='50'>";
												}
											?>
											<span class="help-block"></span>
										</div>
									</div>	
									<div class="form-group">
										<label class="col-lg-2 control-label m-t-md ">File</label>
										<div class="col-lg-10">
											<input class="form-control m-t-md" type="file" placeholder="Upload" name="fupload" value="">
											<span class="help-block"></span>
										</div>
									</div>									
									<div class='form-group'>
										<div class='col-sm-4 col-sm-offset-2 m-t-md'>
											<input type='hidden' name='upload' value='yes'/>
											<button type='submit' id='submit-btn' class='btn btn-black'><i class="ion-checkmark-circled"></i> Simpan</button>
											<a href='javascript:history.go(-1)'><button type='button' class='btn btn-black'><i class="ion-arrow-left-a"></i> Kembali</button></a>	
										</div>
									</div>									
								</div>
							</div>
							
						</div>

							<div class='col-sm-4 '>
							<div class='panel b-a'>
								<div class='panel-heading b-b b-light'>
									<span class='font-bold'><i class='fa fa-bar-chart m-r-xs'></i> Total Saldo</span>
								</div>
								<div class='panel-body link-info'>
									<p> 1. Banyak Barang <strong>1</strong></p>
									<p> 2. Total Harga <strong>Rp. 150.000</strong></p>
									<p> 3. Sub Total <strong>Rp. 150.000</strong></p>
								</div>
								<div class='panel-footer bg-light lter text-center '>
									<img src='static/img/mandiri.png' height='32' width='32' class='m-r-sm m-t-n m-b-n'>
									<img src='static/img/bni.png' height='32' width='32' class='m-r-sm m-t-n m-b-n'>
									<img src='static/img/bri.png' height='32' width='32' class='m-r-sm m-t-n m-b-n'>
								</div>								
							</div>
						</div>

						
					</form>
				</div>
			</div>
		</div>