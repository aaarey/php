<?php
error_reporting(0);
session_start();
include "../config/koneksi.php";
include "../config/fungsi_thumb.php";
include "../config/fungsi_seo.php";


if ($_SESSION['email'] != ''){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 
  $produk_seo      = seo_title($_POST['nama_produk']);
 	$harga=str_replace(".","",$_POST['harga']); 
	if ($lokasi_file != '' ){
	
		$data_gambar = mysql_query("SELECT gambar FROM produk WHERE id_produk = $_GET[id]'");
		$r    	= mysql_fetch_array($data_gambar);
		@unlink('../static/products/foto_produk/'.$r['gambar']);
		@unlink('../static/products/foto_produk/'.'small_'.$r['gambar']);
		
		UploadImage($nama_file_unik,'../static/products/foto_produk/',300,120);		
		mysql_query("UPDATE produk SET			nama_produk = '$_POST[nama_produk]',
												produk_seo  = '$produk_seo',
												id_kategori = '$_POST[kategori]',
												kondisi = '$_POST[kondisi]',
												harga = '$harga',
												diskon = '$_POST[diskon]',
												stok = '$_POST[stok]',
												berat = '$_POST[berat]',
												deskripsi = '$_POST[deskripsi]',
												gambar = '$nama_file_unik'
												WHERE id_produk = '$_POST[id]'");			
			
		header("Location: ../my-produk.html?suc=ok");	
	}
	else{
		mysql_query("UPDATE produk SET			nama_produk = '$_POST[nama_produk]',
												produk_seo  = '$produk_seo',
												id_kategori = '$_POST[kategori]',
												kondisi = '$_POST[kondisi]',
												harga = '$harga',
												diskon = '$_POST[diskon]',
												stok = '$_POST[stok]',
												berat = '$_POST[berat]',
												deskripsi = '$_POST[deskripsi]'
												WHERE id_produk = '$_POST[id]'");		
			
		header("Location: ../my-produk.html?suc=ok");			
		
	}

}
else{
	header("Location: ../login.html?err=log");
}
?>