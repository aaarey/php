	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>	
<div class="container">
	<div class="m-t-md"></div>
	<div class="row row-sm">
			
		<div class="col-md-12">
			<div class="row row-sm">
			
			<?php
			$dataPerPage = 10;
			
			if(isset($_GET['page'])){
				$noPage = $_GET['page'];
			}
			else 
				$noPage = 1;

			$offset = ($noPage - 1) * $dataPerPage;
			$i = 1;
			if ($_GET['id'] != 0){
				$sql_article = mysql_query("SELECT * FROM news A LEFT JOIN 
															cat_news B ON A.id_cat_news=B.id_cat_news
													WHERE A.aktif = 'Y' AND B.category_id = '$_GET[id]' 
													ORDER BY A.id_news DESC LIMIT $offset,$dataPerPage");
			}
			else{
				$sql_article = mysql_query("SELECT * FROM news A LEFT JOIN 
															cat_news B ON A.id_cat_news=B.id_cat_news
												WHERE A.aktif = 'Y' ORDER BY A.id_news DESC LIMIT $offset,$dataPerPage");
			}
			while ($data_news = mysql_fetch_array($sql_article)){
				$posted = tgl_indo($data_news['post_date']);
				$description = substr($data_news['deskripsi'], 0, 100);
				
				echo "<div class='col-sm-4'><div class='panel b-a'>";
						if ($data_news['image'] != ''){
							echo "<div>
									<a href='read-info-$data_news[id_news]-$data_news[title_seo].html' class='black'>
									<img src='static/images/photo_articles/$data_news[image]' width='640px' height='150px' class='img-full'>
									</a>
								</div>";
						}
						echo "
							<div class='panel-body'>
								<div class='link-info'><a href='read-info-$data_news[id_news]-$data_news[title_seo].html' rel='category tag'>$data_news[cat_name]</a></div>
								<h2 class='h3 m-t-xs h-xs'><a href='read-info-$data_news[id_news]-$data_news[title_seo].html' class='text-grey'>$data_news[title]</a></h2>
								<div class='text-muted m-t-xs'>
									<i class='fa fa-clock-o text-muted'></i><span class='m-r-sm'> Posting: $posted</span>
								</div>
								

						</div>
					</div></div>
					
					";
					
					
				$i++;
			}
			?>	

		
			</div>
			
					<div class="text-right m-b-sm">
						<ul class="pagination pagination-md">
						<?php
						if ($_GET['id'] != 0){
							$jumData	= mysql_num_rows(mysql_query("SELECT * FROM news WHERE aktif = 'Y' AND id_cat_news = '$_GET[id]'"));
						}
						else{
							$jumData	= mysql_num_rows(mysql_query("SELECT * FROM news WHERE aktif= 'Y'"));
						}
						$jumPage = ceil($jumData/$dataPerPage);
						$title = str_replace(" ", "+", $_GET['title']);
		
						if ($noPage > 1)
							$numpage = $noPage-1;
							if ($numpage != ''){
								echo  "<li class='active'><a href='info-$_GET[id]-$numpage-$title.html' class='text-grey'><i class='fa fa-caret-left'></i>
										Prev</a></li>";
							}
							else{
								echo  "<li class='active'><a href='#' class='text-grey'><i class='fa fa-caret-left'></i> Prev</a></li>";
							}
							for($page = 1; $page <= $jumPage; $page++){
								if ((($page >= $noPage - 3) && ($page <= $noPage + 3)) || ($page == 1) || ($page == $jumPage)){
									if (($showPage == 1) && ($page != 2))  
										echo "...";
									if (($showPage != ($jumPage - 1)) && ($page == $jumPage))  
										echo "...";
									if ($page == $noPage) 
										echo " <li><span class='page active'>".$page."</span></li>";
									else 
										echo "<li> <a href='info-$_GET[id]-$page-$title.html' class='text-grey'>".$page."</a> </li>";
									$showPage = $page;
								}
							}
		
						if ($noPage < $jumPage)
							$numPlus = $noPage+1;
							if ($numPlus != ''){ 
								echo "<li><a href='info-$_GET[id]-$numPlus-$title.html' class='text-grey'>Next <i class='fa fa-caret-right'></i</a></li>";
							}
							else{
								echo "<li><a href='#' class='text-grey'>Next <i class='fa fa-caret-right'></i></a></li>";
							}
						?>

						</ul>
					</div>						
		</div>  
			
		
		<?php include "right.php";?>
			
	</div>			
</div>

