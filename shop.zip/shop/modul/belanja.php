<?php
session_start();
if ($_SESSION['useri'] == ''){
	header("Location: sign-in.html?err=log");
}
else{
echo"kosong";
	
}
?>