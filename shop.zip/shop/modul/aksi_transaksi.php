<?php
session_start();
if ($_SESSION['email'] == ''){
	header("Location: sign-in.html?err=log");
}
else{
include "../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

if ($module=='biaya' AND $act=='input'){
	$tanggal = date('Y-m-d H:i:s');	
	$waiting = "Waiting";
  mysql_query("INSERT INTO konfirmasi(id_orders, nama_bank, no_rekening, akun_nama, amount, status, tanggal)
				VALUES('$_POST[id_orders]','$_POST[nama_bank]','$_POST[no_rekening]','$_POST[akun_nama]','$_POST[total]',
				'$waiting','$tanggal')");
      header('location:../engine.php?module='.$module);
}


elseif ($module=='biaya' AND $act=='update'){
		$biaya=str_replace(".","",$_POST['biaya']);
		$tanggal = date('Y-m-d H:i:s');	
	// Update stok barang saat transaksi sukses (Lunas)
	if ($_POST[status_order]=='Dibayar'){ 
    
      // Update untuk mengurangi stok 
      mysql_query("UPDATE produk,orders_detail SET produk.stok=produk.stok-orders_detail.jumlah 
	  WHERE produk.id_produk=orders_detail.id_produk and orders_detail.id_orders='$_POST[id]'");
	  
	  // Update untuk menambahkan produk yang dibeli (best seller = produk yang paling laris)
      mysql_query("UPDATE produk,orders_detail SET produk.dibeli=produk.dibeli+orders_detail.jumlah 
	  WHERE produk.id_produk=orders_detail.id_produk and orders_detail.id_orders='$_POST[id]'");

      // Update status order
      mysql_query("UPDATE orders SET status_order='$_POST[status_order]',
							dibayar = '1'
					where id_orders='$_POST[id]'");

	header('location:../history_transaksi.html');
    }	  
	  elseif($_POST[status_order]=='Dikembalikan'){
	    // Update untuk menambah stok
	    mysql_query("UPDATE produk,orders_detail SET produk.stok=produk.stok+orders_detail.jumlah
		WHERE produk.id_produk=orders_detail.id_produk and orders_detail.id_orders='$_POST[id]'"); 
	    
	    // Update untuk menambahkan produk yang tidak jadi dibeli (tidak jd best seller)
      mysql_query("UPDATE produk,orders_detail SET produk.dibeli=produk.dibeli-orders_detail.jumlah 
	  WHERE produk.id_produk=orders_detail.id_produk and orders_detail.id_orders='$_POST[id]'");

	    // Update status order Batal
      mysql_query("UPDATE orders SET status_order='$_POST[status_order]',
									dikembalikan ='1'
									where id_orders='$_POST[id]'");

  header('location:../history_transaksi.html');
	  }
    else{
      mysql_query("UPDATE orders SET status_order='$_POST[status_order]',
									akun_bank='$_POST[akun_bank]',
									biaya = '$biaya',
									tanggal = '$tanggal',
									konfirmasi = '1'
								where id_orders='$_POST[id]'");
  header('location:../history_transaksi.html');
    }
}
}
?>
