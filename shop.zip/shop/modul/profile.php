	<script language="javascript" src="js/harga.js"></script>
	<script type="text/javascript" src="js/ajaxupload.3.5.js" ></script>
	<link rel="stylesheet" type="text/css" href="css/Ajaxfile-upload.css" />
	<script type="text/javascript" >
		$(function(){
		var btnUpload=$('#me');
		var mestatus=$('#mestatus');
		var files=$('#files');
		new AjaxUpload(btnUpload, {
			action: 'upload_profile.php',
			name: 'uploadfile',
			onSubmit: function(file, ext){
				 if (! (ext && /^(jpg|jpeg)$/.test(ext))){ 
                    // extension is not allowed 
					mestatus.text('Only JPG file are allowed');
					return false;
				}
				mestatus.html('');
			},
			onComplete: function(file, response){
				//On completion clear the status
				mestatus.text('');
				//On completion clear the status
				files.html('');
				//Add uploaded file to list
				if(response!=="error"){
					$('<li></li>').appendTo('#files').html('<img src="static/products/foto_member/'+response+'" alt="" width="70" height="70" style="border-radius: 10px; margin-left: -3px; margin-top:-80px; border: 3px solid #ccc"/><br />').addClass('success');
					$('<li></li>').appendTo('#member').html('<input type="hidden" name="filename" value="'+response+'">').addClass('nameupload');
					
				} else{
					$('<li></li>').appendTo('#files').text(file).addClass('error');
				}
			}
		});
		});
	</script>		
<script language="javascript">
$(document).ready(function() {
	$('#jasa').change(function() { 
		var category = $(this).val();
		$.ajax({
			type: 'GET',
			url: 'config/kota.php',
			data: 'perusahaan=' + category, 
			dataType: 'html',
			beforeSend: function() {
				$('#kota').html('<tr><td colspan=2>Loading ....</td></tr>');	
			},
			success: function(response) {
				$('#kota').html(response);
			}
		});
    });
});
</script>

<?php
if ($_SESSION['email'] != ''){
	
	
$sql=mysql_query("SELECT * FROM kustomer A LEFT JOIN
							kota B ON A.id_kota=B.id_kota LEFT JOIN
							shop_pengiriman C ON B.id_perusahaan=B.id_perusahaan
							WHERE A.id_kustomer = '$_SESSION[useri]'");

$r=mysql_fetch_array($sql);
$login = date('Y-m-d H:i:s');
	if ($r['kelamin'] == 'L'){
		$checka = 'checked';
	}
	elseif($r['kelamin'] == 'P'){
		$checkb = 'checked';
	}
	else{
		$checka = '';
		$checkb = '';
	}
?>	
		<div id="content" class="main-content bg-light">
			<div class="bg-black text-white b-b " style="background:url(static/img/1.jpg) center center; background-size:cover;background-color: #263845;">
				<div class="bg-gd-dk">
					<div class="container h-md pos-rlt">
						<div class="h-md">
							<div class=" wrapper align-bottom">
								<div>
								
								<?php
								if($r['photo'] != '' ){
									echo"<img class='pull-left thumb-xl avatar m-r-md' src='static/products/foto_member/$r[photo]'>";
								}
								else {
									echo"<img class='pull-left thumb-xl avatar m-r-md' src='static/img/fb.jpg'>";
								}
								?>
								</div>
								<div class="pull-left">
									<div class="align-bottom m-b-xs w-xxl">
										<span class="h1 text-shadow-sm" itemprop="name"><?php echo $r['nama_lengkap']; ?></span>
											<span class="h4 text-info-lter font-bold text-shadow-sm m-l-xs "><?php echo $r['email']; ?></span>
										<p></p>
									</div>
								</div>
							</div>
							<div class="wrapper align-bottom " style="right: 0px;"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="container m-t-md">
				<div class="row">
					<div class="col-sm-3 link-info">
						<div class="panel panel-default">
							<div class="panel-heading b-b b-light">
								<span class="font-bold"><i class="ion-person m-r-xs"></i>Tentang saya</span>
							</div>
						
							<div class="panel-body"><?php echo $r['slogan']; ?></div>
						</div>


					</div>
			
					
					<div class="col-sm-9">
							<!--<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert'>&times;</a>
								<strong><i class='ion-android-warning'></i> Update profile anda segera!</strong> agar transaksi menjadi lancar
							</div>-->
							
						<ul class='nav nav-tabs'>
							<li class='active'><a href='#view' data-toggle='tab' class='text-sm'>Detail Profile</a></li>
							<li><a href='#edit' data-toggle='tab' class='text-sm'>Update Profile</a></li>			  					
						</ul>
							
						<div>
					

							<!--<div class="panel-heading b-b b-light">
								<span class="font-bold"><i class="ion-edit m-r-xs"></i> Update Profile</span>
							</div>-->

							
							
							<div id='myTabContent' class='tab-content'>
							
							
							<div class='tab-pane active in' id='view'>
								<div class="container m-t-md">
									<div class="row">
										<div class="col-sm-9 link-info">
											<div class="row">
												<div class="col-lg-12">
												<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert'>&times;</a>
													<strong><i class='ion-android-warning'></i> Apabila profile masih kosong!</strong> segera update profile anda agar transaksi menjadi lancar
												</div>
													<div class="panel panel-default">
														<div class="panel-heading font-bold ">
															<h3 class="h4 font-bold">Detail Profile</h3>           
														</div>
														<div class="wrapper">
	            <div class="form-group">
	              <label class="col-lg-2 control-label">Avatar</label>
	              <div class="col-lg-10">
	                 <img class="m-b-sm" src="static/products/foto_member/<?php echo $r['photo']; ?>" width="200" height="200" />

           
	              </div>
	            </div>														
															<div class="row">
																<div class="col-sm-6">Nama Lengkap:</div>
																<div class="col-sm-6"><?php echo $r['nama_lengkap']; ?></div>
															</div>			
															<div class="row">
																<div class="col-sm-6">Username:</div>
																<div class="col-sm-6"><?php echo $r['username']; ?></div>
															</div>			
															<div class="row">
																<div class="col-sm-6">Email:</div>
																<div class="col-sm-6"><?php echo $r['email']; ?></div>
															</div>															
															<div class="row">
																<div class="col-sm-6">Rekening:</div>
																<div class="col-sm-6"><?php echo $r['rekening']; ?></div>
															</div>
															<div class="row">
																<div class="col-sm-6">Kota:</div>
																<div class="col-sm-6"><?php echo $r['daerah']; ?></div>
															</div>						
															<div class="row">
																<div class="col-sm-6">Telp</div>
																<div class="col-sm-6"><?php echo $r['hp']; ?></div>
															</div>
															<div class="row">
																<div class="col-sm-6">Jasa Pengiriman:</div>
																<div class="col-sm-6"><?php echo $r['nama_perusahaan']; ?> </div> 
															</div>						
															<div class="row">
																<div class="col-sm-6">Kota Pengiriman:</div>
																<div class="col-sm-6"><?php echo $r['nama_kota']; ?></div>
															</div>															
															<div class="row">
																<div class="col-sm-6">Update :</div>
																<div class="col-sm-6"><?php echo $login; ?></div>
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>								
							
							<div class='tab-pane fade' id='edit'>
							<div class="panel-body link-info">
								<form class="form-horizontal" action="modul/aksi_update_profile.php" method="post" enctype='multipart/form-data' onSubmit=\"return validasiinput(this)\">
									<fieldset class="horizontal-form">
									<?php
									$full_url = full_url();
									if (strpos($full_url, "?suc=ok") == TRUE){
										echo "<div class='alert alert-success'><a href='#' class='close' data-dismiss='alert'>&times;</a>
												<strong><i class='ion-android-done-all'></i> Sukses!</strong> Profile berhasil diupdate
											</div>";
									}
									?>									
								<div class="form-group">
								  <label class="col-lg-2 control-label">Nama Lengkap</label>
								  <div class="col-lg-10">
									<input name="nama_lengkap" required="true" type="text" value="<?php echo $r['nama_lengkap']; ?>" class="form-control text-grey">
									<span class="help-block m-b-none"></span>
								  </div>
								</div>
								<div class="form-group">
								  <label class="col-lg-2 control-label">ID KTP</label>
								  <div class="col-lg-10">
									<input name="ktp" required="true" type="text" value="<?php echo $r['ktp']; ?>" class="form-control text-grey">
									<span class="help-block m-b-none"></span>
								  </div>
								</div>	
							
								<div class="form-group">
									<label class="col-lg-2 control-label">Jenis Kelamin</label>
									<div class="col-lg-10">
										<div class="radio">
											<label for="account_type_business">
											<input id="account_type" type="radio" name="kelamin" value="L" <?php echo $checka; ?>>Laki-laki
										</div>
										<div class="radio">
											<label for="account_type_personal">
											<input id="account_type" type="radio" name="kelamin" value="P" <?php echo $checkb; ?>>Perempuan
										</div>
									</div>
								</div>	
								<div class="form-group">
								  <label class="col-lg-2 control-label">No. Rekening</label>
								  <div class="col-lg-10">
									<input name="rekening" required="true" type="text" value="<?php echo $r['rekening']; ?>" class="form-control text-grey">
									<span class="help-block m-b-none"></span>
								  </div>
								</div>								
								<div class="form-group">
								  <label class="col-lg-2 control-label">Email</label>
								  <div class="col-lg-10">
									<input name="email" required="true" type="text" value="<?php echo $r['email']; ?>" class="form-control text-grey">
									<span class="help-block m-b-none"></span>
								  </div>
								</div>
								<div class="form-group">
								  <label class="col-lg-2 control-label">Password</label>
								  <div class="col-lg-10">
									<input name="password" type="password" class="form-control text-grey">
									<span class="help-block m-b-none"></span>
								  </div>
								</div>
								<div class="form-group">
								  <label class="col-lg-2 control-label">Phone</label>
								  <div class="col-lg-10">
									<input name="hp" required="true" type="text" value="<?php echo $r['hp']; ?>" class="form-control text-grey">
									<span class="help-block m-b-none"></span>
								  </div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label">Alamat</label>
									<div class="col-sm-10">
											<textarea name="alamat" style='width: 450px; height: 150px;' class='ckeditor'><?php echo $r['alamat']; ?></textarea>
									</div>
								</div>									
								<div class="form-group">
								  <label class="col-lg-2 control-label">Kota</label>
								  <div class="col-lg-10">
									<input name="daerah" required="true" type="text" value="<?php echo $r['daerah']; ?>" class="form-control text-grey">
									<span class="help-block m-b-none"></span>
								  </div>
								</div>								
								<div class="form-group">
								  <label class="col-lg-2 control-label">Jasa Pengiriman</label>
								  <div class="col-lg-4">
									<select class="form-control" name='jasa' id='jasa'>
									<option value='0' selected>- Pilih Jasa Pengiriman -</option>
									<?php
									$tampil=mysql_query("SELECT * FROM shop_pengiriman ORDER BY nama_perusahaan");
										while($r=mysql_fetch_array($tampil)){
										echo "<option value='$r[id_perusahaan]'>$r[nama_perusahaan]</option>";
										}
										echo "</select>";
									?>
									<span class="help-block m-b-none"></span>
								  </div>
									<div class="col-lg-6">
									<span id='kota'>
										<select class="form-control" name='kota' id='kota'>
										<option value='0' selected>Tentukan Jenis Jasa Pengiriman Dahulu</option>
										</select>
									</span>									
									</div>								  
								</div>

								<div class="form-group">
								  <label class="col-lg-2 control-label">Slogan</label>
								  <div class="col-lg-10">
									<input name="slogan" required="true" type="text" value="<?php echo $r['slogan']; ?>" class="form-control text-grey">
									<span class="help-block m-b-none"></span>
								  </div>
								</div>		

								<div class='form-group'>
										<label class='col-lg-2 control-label m-t-md '>Gambar</label>
											<tr valign='top'>

												<td style='padding-bottom: 5px; padding-top: 5px; padding-right: 5px;'>
													<table>
														<tr>
															<td width='280'>
																<table>
																	<tr>
																		<td height='90'>
																			<div id='me' style='cursor:pointer; height: 70px; width: 75px;'>
																				<button class='button_profile'><img src='css/edit.png' width='50'></button>
																					
																				<div id='member'>
																					<li class='nameupload'></li>
																				</div>
																				<div id='files'>
																					<li class='success'></li>
																				</div>
																			</div>
																			<span id='mestatus' ></span>
																		</td>
																</table>
															</td>
															<td align='left'>
																<div class='alert'>
																	&bull; Updae data diri anda, untuk memastikan transaksi berjalan lancar.
																</div>
															</td>
														</tr>
													</table>						
												</td>
											</tr>
								</div>								
									<div class="form-group">
										<div class="col-sm-4 col-sm-offset-2 m-t-md">
											<input type="hidden" name="upload" value="yes"/>
											<button type="submit" id="submit-btn" class="btn btn-black"><i class='ion-ios-checkmark-outline'></i> Simpan</button>
										</div>

									</div>									
									</fieldset>
								</form>
							</div>
							
						
							
							
							
							</div>
							</div>
							
							
						</div>
					</div>
				</div>
			</div>
			<!--<div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel">Send message</h4>
						</div>
						<div class="modal-body">
							<form action="#" class="form-horizontal" method="post">
								<div class="form-group">
									<label class="col-lg-2 control-label">From</label>
									<div class="col-lg-10">
										<input type="email" value="az_j2me@yahoo.com" name="from" id="from" disabled class="form-control"></div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label">Message</label>
									<div class="col-lg-10">
										<textarea name="message" id="message" class="form-control"></textarea>
									</div>
								</div>
								<div class="alert alert-warning">
									 Spam is not tolerated, all messages are recorded. Your email address is visible to the recipient.
								</div>
							</div>
							<div class="modal-footer">
								<input type="hidden" name="send_email" value="yes"/>
								<button type="submit" name="send_email" value="yes" class="btn btn-info subscribe-mail ">Send</button>
							</form>
						</div>
					</div>
				</div>
			</div>-->
		</div>	
<?php } 
else{
	header("Location: sign-in.html?err=log");
}

?>