	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>	
  <div id="content" class="main-content bg-lights">
	  
	  
<div class="container">
<div class="m-t-md">	
<div class="panel wrapper b-a text-sm">
	<div class="accordion-heading">
     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
        <h3 class="font-bold m-t-xs text-grey"> 1. Support Antar Bank </h3></a>
	</div>
	
	<div id="collapseOne" class="accordion-body collapse in">
        <div class="accordion-inner">
		<i class='fa fa-check'></i> Anda dapat melakukan pembayaran ke Bukalapak melalui BukaDompet, Mandiri ClickPay, BCA KlikPay, CIMB Clicks, Rekening ponsel CIMB Niaga, Kartu berlogo VISA/MasterCard, Indomaret, Mandiri E-cash, atau Transfer lewat bank maupun lewat ATM. <br/>
	

        </div>
    </div>
</div> 
<!--<div class="panel wrapper b-a text-sm">
	<div class="accordion-heading">
     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseDua">
        <h3 class="font-bold m-t-xs text-grey">2. Gunakan Fitur Favoritkan Agar Kamu Lebih Mudah dalam Mencari Barang </h3></a>
	</div>
	
	<div id="collapseDua" class="accordion-body collapse in">
        <div class="accordion-inner">
		<i class='fa fa-check'></i> ada banyak pelapak yang menjual barang yang sama. Kamu yang akan membeli barang, kadang merasa bingung dalam memilih pelapak. Pertimbanganmu saat itu mungkin adalah masalah lokasi, harga, feedback atau pertimbangan lainnya, sesuai kriteriamu pada pelapak tersebut.		

        </div>
    </div>
</div> -->

</div> 
</div>
</div> 

