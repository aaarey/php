	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>
<?php
$id = mysql_fetch_array(mysql_query("SELECT id_orders FROM orders WHERE dibayar = 1 "));
$ids=$id['id_orders'];
$id_orders=mysql_insert_id();

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);	
	

	echo " <div id='content' class='main-content bg-lights'>
<div class='container '><div class='m-t-md'></div>
				<div class='row'>	
					<div class='col-sm-12'>
						<ul class='nav nav-tabs'>
							<li class='active'><a href='#beli' data-toggle='tab' class='text-sm'>Report Pembelian</a></li>
							<li><a href='#jual' data-toggle='tab' class='text-sm'>Report Penjualan</a></li>			  					
						</ul>";						
		echo"
		<div id='myTabContent' class='tab-content'>	
		<div class='tab-pane active in' id='beli'>		
		<div class='panel b-a'>			
				<div class='panel-heading b-b b-light'>
					<span class='font-bold'><i class='ion-shuffle m-r-xs'></i>Pembelian</span>
				</div>	
				<table class='table table-striped m-b-none'>
					<thead class='panel-heading b-b b-light'>
					<tr>
						<th>#</th>	
						<th>ID</th>
						<th>Transaksi</th>
						<th>Nama Produk</th>
						<th>Tanggal</th>						
						<th>Qty</th>			
						<th>Total</th>
						<th>Pengiriman</th>
						</tr></thead><tbody>";	
			
	
	$sql=mysql_query("SELECT * FROM orders A INNER JOIN
					kustomer B ON A.id_kustomer=B.id_kustomer INNER JOIN
					orders_detail C ON C.id_orders=A.id_orders INNER JOIN
					produk D ON D.id_produk=C.id_produk LEFT JOIN
					kota E ON B.id_kota=E.id_kota LEFT JOIN
					shop_pengiriman F ON E.id_perusahaan=F.id_perusahaan
					WHERE B.id_kustomer='$_SESSION[useri]'  ORDER BY A.id_orders");
	$t=mysql_num_rows($sql);
	if($t == 0){
	echo"<tr><td>Tidak ada Transaksi</td></tr>";
	}
	else{				
    $no = $posisi+1;		
	while($r = mysql_fetch_array($sql)){
	$harga  = format_rupiah($r[harga]);		
	$tanggal=tgl_indo($r['tgl_masuk']);
    $disc        = ($r['diskon']/100)*$r['harga'];
    $hargadisc   = number_format(($r['harga']-$disc),0,",",".");

    $subtotal    = ($r['harga']-$disc) * $r['jumlah'];
    $total       = $total + $subtotal;  
    $subtotal_rp = format_rupiah($subtotal);
    $total_rp    = format_rupiah($total);
    $harga       = format_rupiah($r['harga']);				
			echo "<tr><td>$no</td>
				  <td>$r[id_orders]</td>
				  <td><span class='label label-success'>$r[akun]</span></td>
				  <td><a href='produk-$r[id_produk]-$r[produk_seo].html' class='text-grey'>$r[nama_produk]</a></td>
				  <td>$tanggal</td>				  
				  <td>$r[jumlah]</td>			  
				  <td>Rp. $subtotal_rp</td>	 
				  <td>$r[nama_perusahaan] | $r[lama] Hari</td>
				  </tr>";
		$no++;
	}
	}
				  
				  
	echo "</table>
	</div></div>
	<div class='tab-pane fade' id='jual'>
		<div class='panel b-a'>			
				<div class='panel-heading b-b b-light'>
					<span class='font-bold'><i class='ion-shuffle m-r-xs'></i>Penjualan</span>
				</div>
				<table class='table table-striped m-b-none'>
					<thead class='panel-heading b-b b-light'>
					<tr>
						<th>#</th>	
						<th>ID Produk</th>
						<th>Transaksi</th>
						<th>Nama Produk</th>
						<th>Tanggal</th>							
						<th>Qty</th>
						<th>Info</th>
						<th>Aksi</th>
						</tr></thead><tbody>";					

		/*
		$sql=mysql_query("SELECT * FROM produk A LEFT JOIN
						kustomer B ON A.id_kustomer=B.id_kustomer LEFT JOIN
						kategori C ON A.id_kategori=C.id_kategori LEFT JOIN
						orders_detail D ON A.id_produk=D.id_produk LEFT JOIN
						orders E ON D.id_orders=D.id_orders
						WHERE A.id_kustomer = '$_SESSION[useri]'");		
		
		$sql=mysql_query("SELECT * FROM produk A LEFT JOIN
						kustomer B ON A.id_kustomer=B.id_kustomer LEFT JOIN
						kategori C ON A.id_kategori=C.id_kategori LEFT JOIN
						orders E ON E.id_kustomer=A.id_kustomer
						WHERE A.id_kustomer = '$_SESSION[useri]'");	
		*/	
		$t=mysql_fetch_array(mysql_query("select * from produk"));
		
		$sql=mysql_query("SELECT * FROM produk A LEFT JOIN
						kustomer B ON A.id_kustomer=B.id_kustomer LEFT JOIN
						kategori C ON A.id_kategori=C.id_kategori LEFT JOIN
						orders_detail E ON A.id_produk=E.id_produk LEFT JOIN
						orders F ON F.id_orders=E.id_orders
						WHERE  A.id_kustomer='$_SESSION[useri]'
						ORDER BY A.nama_produk");	
						
    $no = $posisi+1;		
	while($r = mysql_fetch_array($sql)){
		$harga  = format_rupiah($r[harga]);	
	$dibeli = $r['jumlah'] + $r['stok'];
	$terjual = $r['dibeli']-1;
	$tanggal=tgl_indo($r['tgl_masuk']);
    $disc        = ($r['diskon']/100)*$r['harga'];
    $hargadisc   = number_format(($r['harga']-$disc),0,",",".");
	
    $subtotal    = ($r['harga']-$disc) * $r['jumlah'];
    $total       = $total + $subtotal;  
    $subtotal_rp = format_rupiah($subtotal);
    $total_rp    = format_rupiah($total);
    $harga       = format_rupiah($r['harga']);				
			echo "<tr><td>$no</td>
				  <td>$r[id_produk]</td>	
				  <td><span class='label label-success'>$r[akun]</span></td>
				  <td>$r[nama_produk]</td>
				  <td>$tanggal</td>				  	  
				  <td>$r[jumlah]</td>";
?>					
			<td>

			<span title='pending' <?php if ($r['pending'] == '1'){ echo "class='fa-stack fa-lg icon-green'";}
								else { echo "class='fa-stack fa-lg icon-grey'";} ?>><i class="fa fa-circle fa-stack-2x"></i>
				<i class="fa fa-hourglass-half fa-stack-1x fa-inverse"></i></span>
			
			<span title='dibayar' <?php if ($r['dibayar'] == '1'){ echo "class='fa-stack fa-lg icon-green'";}
								else { echo "class='fa-stack fa-lg icon-grey'";} ?>><i class="fa fa-circle fa-stack-2x"></i>
				<i class="fa fa-money fa-stack-1x fa-inverse"></i></span>

			<span title='dikirim' <?php if ($r['dikirim'] == '1'){ echo "class='fa-stack fa-lg icon-green'";}
								else { echo "class='fa-stack fa-lg icon-grey'";} ?>><i class="fa fa-circle fa-stack-2x"></i>
				<i class="fa fa-truck fa-stack-1x fa-inverse"></i></span>
				
			<span title='diterima' <?php if ($r['diterima'] == '1'){ echo "class='fa-stack fa-lg icon-green'";}
								else { echo "class='fa-stack fa-lg icon-grey'";} ?>><i class="fa fa-circle fa-stack-2x"></i>
				<i class="ion-android-done-all fa-stack-1x fa-inverse"></i></span>

			</td>

<?php	
		if($r['status_order']=='Dibayar'){
			echo"<td><span class='label label-info'>
				<a class='icon-trues' href='write-transaksi-1-$r[id_orders].html'><i class='ion-shuffle'></i> Proses Sekarang</a></span></td>";
		}
		elseif($r['status_order']=='Pending'){
			echo"<td><span class='label label-warning'><i class='ion-alert-circled'></i> Transaksi Pending</td>";
		}		
		elseif($r['status_order']=='Dikirim'){
			echo"<td><span class='label label-success'>Transaksi Dikirim</td>";
		}
		elseif($r['status_order']=='Diterima'){
			echo"<td><span class='label label-success'>Transaksi Selesai</td>";
		}		
		echo"</tr>";
		$no++;
	}
				  
				  
	echo "</table>
		</div>
	</div>

	
	</div>
	

	</div>
	</div>";	
    $jmldata = mysql_num_rows(mysql_query("SELECT * FROM orders"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

				  echo "<div class='text-right m-b-sm'>
						<ul class='pagination pagination-md'>
							<li><a href='#'>Halaman : $linkHalaman </a></li>
						</ul></div></div>";	
	
		
	
?>