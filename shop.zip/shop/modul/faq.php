	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>	
  <div id="content" class="main-content bg-lights">
	  
	  
<div class="container">
<div class="m-t-md">	
<div class="panel wrapper b-a text-sm">
	<div class="accordion-heading">
     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
        <h3 class="font-bold m-t-xs text-grey"> 1. Apakah Lapakku menjual barang? </h3></a>
	</div>
	
	<div id="collapseOne" class="accordion-body collapse in">
        <div class="accordion-inner">
		<i class='fa fa-check'></i> Lapakku adalah aplikasi jual beli online yang menghubungkan jutaan pembeli dan pelapak di seluruh Indonesia. <br/>
		<i class='fa fa-check'></i> Lapakku tidak menjual/menyediakan barang/produk, melainkan hanya sebagai perantara.

        </div>
    </div>
</div> 
<div class="panel wrapper b-a text-sm">
	<div class="accordion-heading">
     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseDua">
        <h3 class="font-bold m-t-xs text-grey">2. Apakah bertransaksi di Lapakku benar-benar aman? </h3></a>
	</div>
	
	<div id="collapseDua" class="accordion-body collapse in">
        <div class="accordion-inner">
		<i class='fa fa-check'></i> Setiap transaksi di Bukalapak dijamin aman dari penipuan karena pembeli tidak langsung mengirim dana ke pelapak, melainkan ke elapak. Jadi apabila barang yang dipesan tidak dikirim, maka dana pembeli akan dikembalikan 100%.<br/>
		

        </div>
    </div>
</div> 
<div class="panel wrapper b-a text-sm">
	<div class="accordion-heading">
     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTiga">
        <h3 class="font-bold m-t-xs text-grey">3. Apakah ada syarat khusus untuk membuat akun di Lapakku? </h3></a>
	</div>
	
	<div id="collapseTiga" class="accordion-body collapse in">
        <div class="accordion-inner">
		<i class='fa fa-check'></i> Pastikan kamu membuat akun di Lapakku dengan email dan nomor handphone yang aktif untuk mempermudah transaksi. Gampang kan? Makanya buruan daftar di Elapak !		

        </div>
    </div>
</div> 
<div class="panel wrapper b-a text-sm">
	<div class="accordion-heading">
     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseEmpat">
        <h3 class="font-bold m-t-xs text-grey">4. Jika mendaftar ke Lapakku, apakah status akun menjadi pembeli atau pelapak? </h3></a>
	</div>
	
	<div id="collapseEmpat" class="accordion-body collapse in">
        <div class="accordion-inner">
		<i class='fa fa-check'></i> Dengan sekali mendaftar akun di Elapak, kamu secara otomatis bisa mendapat kesempatan menjadi pembeli maupun pelapak. Kamu bisa melakukan pembelian sekaligus dapat menjual barang. Ayo daftar di Elapak sekarang !

		

        </div>
    </div>
</div>
<div class="panel wrapper b-a text-sm">
	<div class="accordion-heading">
     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseLima">
        <h3 class="font-bold m-t-xs text-grey">5. Bagaimana cara berbelanja di Lapakku? </h3></a>
	</div>
	
	<div id="collapseLima" class="accordion-body collapse in">
        <div class="accordion-inner">
		<i class='fa fa-check'></i> Berbelanja di Lapakku sangat mudah, Beli dengan akun. Menggunakan akun yang telah didaftarkan di Lapakku.

		

        </div>
    </div>
</div>
</div> 
</div>
</div> 

