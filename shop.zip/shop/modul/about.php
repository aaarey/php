<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
</div>	
<div id="content" class="main-content bg-light">
	  
	  
	<div class="" style="background-image: url('static/img/header.jpg');height: 400px;">  
	
	  <div class="container">   
        <div class="row">
          <div class="col-md-10 col-md-offset-1 text-center">
            <div class="m-t-xxl m-b-xxl padder-v">
              <h1 class="font-thin l-h-1x m-t-xxl text-white padder-v animated fadeInDown">
                Tentang Lapakku</h1>
              <h3 class="text-white m-t-xl l-h-1x animated fadeInDown">Selamat datang di Lapakku website jual beli online</h3>
            </div>
        
          </div>
        </div>
	  </div> 
    </div>

    <div class="bg-light">
      <div class="container">
        <div class="row m-t-xl m-b-xxl">
          <div class="col-sm-4">
	          <img src="static/img/logo.png" class="w-full">
          </div>
          <div class="col-sm-8 text-lg">
            <h3 class="text-dark font-bold m-b-lg">Apa itu Lapakku?</h3>
	Lapakku Fokus pada jual beli online untuk para penjual dan pembeli <br><br>
 
           </div>
        </div>
      </div>
    </div>

    
    <div class="bg-light">
      <div class="container">
        <div class="row m-t-xl m-b-xxl">
          <div class="col-sm-8 text-lg link-info" data-ride="animated" data-animation="fadeInLeft" data-delay="900">
            <h3 class="text-dark font-bold m-b-lg">Anda mempunyai pertanyaan?</h3>
            <p>Silahkan kontak kami di menu <a href="contact-us.html">support</a>. 
			Kami akan mencoba menjawab pertanyaan anda dengan cepat dan akurat </p>
            
            
                
            
          </div>
          <div class="col-sm-4 text-center m-t-md" data-ride="animated" data-animation="fadeInRight" data-delay="1200">
		  	<span class="text-3x text-muted"><span class="text-2x"><i class="ion-ios-search-strong text-2x"></i></span></span>
          </div>
        </div>
      </div>
    </div>    
    
    


  	
	    	
	    	


  </div>