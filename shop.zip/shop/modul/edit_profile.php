<script src="js/jquery.validate.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="js/ajaxupload.3.5.js"></script>
<link rel="stylesheet" type="text/css" href="css/Ajaxfile-upload.css" />
<script type="text/javascript" src="js/jquery-1.4.1.min.js"></script>

<script>
	var htmlobjek;
	function validateEmail(email) { 
		var re = /\S+@\S+\.\S+/
		return re.test(email);
	}
	
	function Count(){
		var karakter,maksimum;  
		maksimum = 500
		karakter = maksimum-(document.frm_profile.biografi.value.length);  
		if (karakter < 0) {
			alert("Max. characters:  " + maksimum + "");  
			document.frm_profile.biografi.value = document.frm_profile.biografi.value.substring(0,maksimum);  
			karakter = maksimum-(document.frm_profile.biografi.value.length);  
			document.frm_profile.counter.value = karakter;  
		} 
		else {
			document.frm_profile.counter.value =  maksimum-(document.frm_profile.biografi.value.length);
		}
	} 

	jQuery(document).ready(function(){
		$("#province").change(function(){
			var province = $("#province").val();
			$.ajax({
				url: "get_city.php",
				data: "province="+province,
				cache: false,
				success: function(msg){
					$("#city").html(msg);
				}
			});
		});
		
		$('#frm_profile').validate({
			rules:{
				email: true,
				nama_lengkap: true,
				hp: true,
				alamat: true,
				address: true
			},
			messages:{
				email:{
					required: "This is a required field."
				},
				nama_lengkap:{
					required: "This is a required field."
				},
				hp:{
					required: "This is a required field."
				},
				alamat:{
					required: "This is a required field."
				},
				address:{
					required: "This is a required field."
				}
			}
		});
		
		$("#username").change(function()
		{ //if theres a change in the username textbox
			var username = $("#username").val();//Get the value in the username textbox
			$("#availability_username").html('<img src="image/loader.gif" align="absmiddle">&nbsp;Checking availability...');
			//Add a loading image in the span id="availability_status"
			$.ajax({  //Make the Ajax Request
				type: "POST",
				url: "modul/check_username.php",  //file name
				data: "username="+ username,  //data
				success: function(server_response){
					$("#availability_username").ajaxComplete(function(event, request){
						if(server_response == '0')//if ajax_check_username.php return value "0"
						{
							$("#availability_username").html('<div class="available"> Username is Available </div>  ');
							document.getElementById("button_profile").disabled = false;
							//add this image to the span with id "availability_status"
						}
						else  if(server_response == '1')//if it returns "1"
						{
							$("#availability_username").html('<div class="error">Username is already used</div>');
							document.getElementById("button_profile").disabled = true; 
						}
						else  if(server_response == '2')//if it returns "1"
						{
							$("#availability_username").html('<div class="error">Username can only contain letters and numbers</div>');
							document.getElementById("button_profile").disabled = true; 
						}
					});
				}
			});
		});
		
		var btnUpload=$('#me');
		var mestatus=$('#mestatus');
		var files=$('#files');
		new AjaxUpload(btnUpload, {
			action: 'modul/upload_profile.php',
			name: 'uploadfile',
			onSubmit: function(file, ext){
				 if (! (ext && /^(jpg|jpeg)$/.test(ext))){ 
                    // extension is not allowed 
					mestatus.text('Only JPG file are allowed');
					return false;
				}
				mestatus.html('<img src="image/loader.gif" height="16" width="16">');
			},
			onComplete: function(file, response){
				//On completion clear the status
				mestatus.text('');
				//On completion clear the status
				files.html('');
				//Add uploaded file to list
				if(response!=="error"){
					$('<li></li>').appendTo('#files').html('<img src="static/images/photo_member/'+response+'" alt="" width="100" style="border-radius: 10px; border: 3px solid #ccc"/><br />').addClass('success');
					$('<li></li>').appendTo('#member').html('<input type="hidden" name="filename" value="'+response+'">').addClass('nameupload');
					
				} else{
					$('<li></li>').appendTo('#files').text(file).addClass('error');
				}
			}
		});
	});
</script>
<?php
$data_profile = mysql_fetch_array(mysql_query("SELECT * FROM kustomer WHERE id_kustomer='$_SESSION[useri]'"));
?>
<div class='main-column-wrapper'>
	<div class='main-column-left2'>
		<div class='blog-style-2'>
			<p style="font-size:18px; font-weight: bold;">Edit Profile</p>
			<form method="POST" id="frm_profile" name="frm_profile" action="modul/aksi_update_profile.php">
			<table width="100%">
				<tr valign="top">
					<td style="padding-bottom: 5px; padding-top: 5px; padding-left: 5px;" width="130"><b>Upload Photo</b></td>
					<td style="padding-bottom: 5px; padding-top: 5px; padding-right: 5px;">
						<div id="me" style="cursor:pointer; height: 40px; width: 72px;">
							<label>
								<button class="button_profile">Browse</button>
							</label>
						</div>
						<span id="mestatus" ></span>
						<div id="member">
							<li class="nameupload"></li>
						</div>
						<div id="files">
							<li class="success">
								<?php 
								if ($data_profile['photo'] != ''){
									echo "<img src='image/photo_member/thumb/small_$data_profile[photo]' width='100' style='border: 3px solid #ccc; border-radius: 10px;'>";
								} 
								?>
			              </li>
			            </div>
					</td>
				</tr>

				<tr>
					<td style="padding-bottom: 5px; padding-top: 5px; padding-left: 5px;"><b>Email</b></td>
					<td style="padding-bottom: 5px; padding-top: 5px; padding-right: 5px;">
						<input type="text" id="email" placeholder="Your Email" value="<?php echo $data_profile['email']; ?>" name="email" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 20px; width: 266px; margin-right: 10px; padding: 5px;" DISABLED>
					</td>
				</tr>
				<tr>
					<td style="padding-bottom: 5px; padding-top: 5px; padding-left: 5px;"><b>Nama Lengkap</b></td>
					<td style="padding-bottom: 5px; padding-top: 5px; padding-right: 5px;">
						<input type="text" id="nama_lengkap" class="required" placeholder="First Name" value="<?php echo $data_profile['nama_lengkap']; ?>" name="nama_lengkap" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 20px; width: 266px; margin-right: 10px; padding: 5px;">
					</td>
				</tr>
				<tr>
					<td style="padding-bottom: 5px; padding-top: 5px; padding-left: 5px;"><b>Telephone</b></td>
					<td style="padding-bottom: 5px; padding-top: 5px; padding-right: 5px;">
						<input type="text" id="hp" placeholder="Phone or Cellphone" value="<?php echo $data_profile['hp']; ?>" name="hp" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 20px; width: 266px; margin-right: 10px; padding: 5px;">
					</td>
				</tr>

				<tr valign="top">
					<td style="padding-bottom: 5px; padding-top: 5px; padding-left: 5px;"><b>Address</b></td>
					<td style="padding-bottom: 5px; padding-top: 5px; padding-right: 5px;">
						<textarea rows="3" id="alamat" class="required" placeholder="Address" name="alamat" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; width: 266px; margin-right: 10px; padding: 5px;"><?php echo $data_profile['alamat']; ?></textarea>
					</td>
				</tr>


				<tr valign="top">
					<td style="padding-bottom: 5px; padding-top: 5px; padding-left: 5px;"></td>
					<td style="padding-bottom: 5px; padding-top: 5px; padding-right: 5px;">
						<input type="submit" class="button" value="SAVE" id="button_profile">
					</td>
				</tr>
			</table>
			</form>
			<p>&nbsp;</p>
		</div>
	</div>
</div>