			<div class='main-column-wrapper'>
				<div class='main-column-left2'>
					<div class='blog-style-2'>
						<div class='post-title2'>
							<b>Congratulation!</b>
						</div>
						<p style='height: 300px;'>Account ativated!<br>
						Your account have been activated. For login please click <a href='sign-in.html'>here</a></p>
					</div>
				</div>
			</div>