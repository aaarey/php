
<?php
$aksi="modul/aksi-favorit.php";

mysql_query("UPDATE produk SET hits=hits+1 WHERE id_produk = '$_GET[id]'");
$detail=mysql_query("select B.photo,A.nama_produk,A.gambar,A.gambar2,A.gambar3,A.harga,A.stok,A.deskripsi,
					B.email,B.nama_lengkap,B.username,B.email,B.id_kustomer,A.ref_id,A.hits,A.tgl_masuk,A.kondisi,
					C.nama_kategori,B.created_date,A.id_produk 
					from produk A LEFT JOIN 
					kustomer B ON A.id_kustomer=B.id_kustomer LEFT JOIN
					kategori C ON A.id_kategori=C.id_kategori
				WHERE A.id_produk = '$_GET[id]' ORDER BY A.id_produk");		

$no=1;						
$r = mysql_fetch_array($detail);	
$ago = time_since(strtotime($r['tgl_masuk']));
$tgl=tgl_indo($r['tgl_masuk']);	
$member_user = $r['username'];
include "disc.php";	
?>

<div class="bg-light lter b-b wrapper">
	<div class="container m-b-xs">
		<div itemscope itemtype="#">
				<div class="row">
					<div class="col-sm-8">
							<div>
								<img itemprop="image" class="pull-left thumb-lg m-r-md img-rounded" src="static/products/foto_produk/<?php echo $r['gambar']; ?>" width='640px' height='50px'>
							</div>
							<div>
								<h1 class="h2" itemprop="name"><?php echo $r['nama_produk']; ?></h1>
								<i class='ion-pricetag'></i> Kondisi :<span class="label label-success"><?php echo $r['kondisi'];?></span> |
								<span itemprop="description" class="text-sm">ID Produk : <?php echo $r['ref_id']; ?> | </span>
								
							<?php
							$t=mysql_fetch_array(mysql_query("SELECT count(id_produk) as total FROM favorit
												WHERE id_produk='$_GET[id]' ORDER BY id_favorit"));
								echo"<span temprop='description' class='text-sm'><i class='ion-heart'></i> Difavoritkan : $t[total] </span>";							
							?>
							</div>
							
							
					</div>
					<div class="col-sm-4">
							<div class="col-sm-5 text-md">
								<div class="row text-sm">
									<i class="fa fa-calendar m-r-xs"></i> Tgl Iklan
								</div>
								<div class="row text-sm">
									<i class="fa fa-folder m-r-xs"></i> Kategori 
								</div>
								<div class="row text-sm">
									<i class="fa fa-eye m-r-xs"></i> Dilihat
								</div>								
							</div>
							<div class="col-sm-6 text-md">
								<div class="row text-sm">: <?php echo $tgl; ?> - <?php echo $ago; ?></div>
								<div class="row text-sm">
									<a href="#" class='text-sm'>: <?php echo $r['nama_kategori']; ?></a> / <a href="#" class='text-sm'>
									<?php echo $r['nama_produk']; ?></a>
								</div>		
								<div class="row text-sm">: <?php echo $r['hits']; ?></div>									
							</div>

						
					</div> <div class="col-sm-4 "></div>    
				</div>
				<div class="no-gutter">
				<ul class='nav nav-tabs'>
					<li class='active'><a href='#produk' data-toggle='tab' class='text-sm'>Detail Produk</a></li>		  					
				</ul>
				</div>					
		</div>
	</div>
</div>
<div id='myTabContent' class='tab-content'>
		<div class='tab-pane active in' id='produk'>
			<div class="container m-t-md">
				<div>
					<div class="col-sm-8 link-info">

						<div class="panel b-a">
							<div class="item m-l-n-xxs m-r-n-xxs">
								<img src="static/products/foto_produk/<?php echo $r['gambar']; ?>" width='640px' height='450px' class="img-full">
							</div>
						</div>
						<div class="row m-t-md">
							<div class="col-lg-12">
								<div class="panel panel-default">
									<div class="panel-heading font-bold ">
										<h3 class="h4 font-bold">Screenshots</h3>
									</div>
									<div class="">
										<div class="panel-body row row-sm clear ">
											<div class="col-xs-2 ">
												<div class="item b-a bg-light m-t-sm m-b-sm lter">
													<div class="screenshot-box ">
														<a rel="nofollow" class="lightbox" href="static/products/foto_produk/<?php echo $r['gambar']; ?>" rel="screenshots">
														<img class="screenshot-thumb" src="static/products/foto_produk/<?php echo $r['gambar']; ?>"></a>
													</div>
												</div>
											</div>
											<div class="col-xs-2 ">
												<div class="item b-a bg-light m-t-sm m-b-sm lter">
													<div class="screenshot-box ">
														<a rel="nofollow" class="lightbox" href="static/products/foto_produk/<?php echo $r['gambar2']; ?>" rel="screenshots">
														<img class="screenshot-thumb" src="static/products/foto_produk/<?php echo $r['gambar2']; ?>"></a>
													</div>
												</div>
											</div>		

											
										</div>
									</div>
								</div>
							</div>
						</div>						

						<a href="#" id="display-screenshots" onclick="$('.extra-screenshot').fadeToggle();$('#hide-screenshots').removeClass('hidden');$('#display-screenshots').addClass('hidden');return false;" class="btn btn-block btn-default btn-lg m-b-md">Lihat gambar lain</a>
						<a href="#" id="hide-screenshots" onclick="$('.extra-screenshot').fadeToggle();$('#hide-screenshots').addClass('hidden');$('#display-screenshots').removeClass('hidden');return false;" class="btn btn-block btn-default m-b-md btn-lg hidden">Sembunyikan</a>		
						<div class="row">
							<div class="col-lg-12">
								<div class="panel panel-default">
									<div class="panel-heading font-bold ">
										<h3 class="h4 font-bold">Detail</h3>           
									</div>
									<div class="panel-body item-description text-sm">
										<p> <?php echo $r['deskripsi']; ?> </p>
											</div>
								</div>
							</div>
						</div>						
					</div>
					
					<div class="col-sm-4 link-info">
						<div class="panel text-md b-a ">
							<div class="panel-body">
								<div class="clear">
									<form action="#" id="purchase-form" method="post" name="purchase-form">
										<div class="pull-right text-right font-bold">
											<span  class="m-l-xs price">
											<span class="h1 price_in_rupiah text-right-xs text-grey "><?php echo $divharga; ?></span><br></span>
										</div>
									</div>
									<div class="clear m-t-md m-b-md text-grey">
										<i class="fa fa-check-circle text-success fa-fw"></i> 100% Jaminan Uang Kembali<br>
										<i class="fa fa-check-circle text-success fa-fw"></i> Sistem Pembayaran Bebas Penipuan<br>
									</div>
										<?php
										if ($_SESSION['useri'] != $r['id_kustomer'] AND $_SESSION['useri'] != ''){								
										?>									
										<?php echo $button; ?>
										<a class='btn btn-info btn-md btn-block' href="javascript:void(0)" onclick="javascript:chatWith('<?php echo $member_user; ?>')"><i class='ion-chatbox-working'></i> Kirim Pesan</a>
										<?php
										$sql=mysql_query("SELECT * FROM favorit WHERE id_kustomer='$_SESSION[useri]' AND id_produk='$_GET[id]'
															ORDER BY id_favorit");
										$ketemu=mysql_num_rows($sql);
										
											if($ketemu != ''){
												echo"<a class='btn btn-black btn-md btn-block  font-bold' href='#' onClick=\"return confirm('Produk sudah ditambahkan di menu favorit')\">
													<i class='ion-android-favorite'></i> DiFavoritkan</a>";	
											}
											else{							
												echo"<a class='btn btn-default btn-md btn-block  font-bold' href='$aksi?module=favorit&act=input&id=$r[id_produk]'>
													<i class='ion-android-favorite-outline'></i> Favoritkan</a>";										
											}
										?>
										<?php } ?>
								</form>
							</div>
						</div>		
						<div class="panel b-a">
							<div class="panel-heading h-xs bg-black lter no-border wrapper-lg"></div>
							<div class="text-center m-b clearfix">
								<div class="thumb-lg avatar m-t-n-xxl">
								<?php if ($r['photo'] !=''){ ?>
									<img src='static/products/foto_member/<?php echo $r['photo']; ?>' class="b b-3x b-white"/>
								<?php } 
								else{
									echo"<img src='static/img/fb.jpg' class='b b-3x b-white'/>";
								}
								?>	
								</div>
								<div class="h3 font-thin"><?php echo $r['nama_lengkap']; ?></div>
								<div class="text-muted"><?php echo $r['email']; ?></div>
								<div class="text-muted">Tergabung: <?php echo $ago; ?></div>							
								<div class="m-t-md">
									<a href="profile-<?php echo $r['id_kustomer']; ?>-1-1-1-<?php echo $r['username']; ?>.html" class="btn btn-black">Lihat profile</a>
								</div>
							</div>
						</div>
						
						<div class="panel panel-default">
							<div class="panel-heading font-bold">Information</div>
							<table class="table table-striped m-b-none">
							<tbody>
							<tr>
								<td class="col-xs-5">Kategori</td>
								<td class="col-xs-7">
									<a href="#" title=""><?php echo $r['nama_kategori']; ?> </a> / <a href="#" ><?php echo $r['nama_produk']; ?></a>
								</td>
							</tr>
							<tr>
								<td>Stok Barang</td>
								<td><?php echo $r['stok']; ?></td>
							</tr>
							<tr>
								<td>Kondisi</td>
								<td><?php echo $r['kondisi']; ?></td>
							</tr>
							<tr>
								<td>Tags</td>
								<td>
									<a href="#"><span class="m-b-xs "><?php echo $r['nama_kategori']; ?></span></a>,
									<a href="#"><span class="m-b-xs "><?php echo $r['nama_produk']; ?></span></a>

								</td>
							</tr>
							</tbody>
							</table>
						</div>
						
					</div>
				</div>
			</div>	
		</div>
		

		<div class='tab-pane fade' id='review'>
			<div class="container m-t-md">
				<div class="row">
					<div class="col-sm-8 link-info">
						<div class="row">
							<div class="col-lg-12">
								<div class="panel panel-default">
									<div class="panel-heading font-bold ">
										<h3 class="h4 font-bold">Detail</h3>           
									</div>
									<div class="panel-body item-description text-sm">
										<p>Layar: Monitor layar lebar 13,3 inci (diagonal) dengan lampu latar glossy LED dengan dukungan untuk jutaan warna Resolusi yang didukung: 1280 x 800 (asli), 1152 x 720, 1024 x 640, dan 800 x 500 piksel pada rasio aspek 16:10; 1024 x 768, 800 x 600, dan 640 x 480 piksel pada rasio aspek 4:3; 1024 x 768, 800 x 600, dan 640 x 480 piksel pada rasio aspek direnggangkan 4:3; 720 x 480 piksel pada rasio aspek 3:2; 720 x 480 piksel pada rasio aspek direnggangkan 3:2	            
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	
		
</div>