	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>	
  <div id="content" class="main-content bg-lights">
	  
	  
<div class="container">
<div class="m-t-md">	
<div class="panel wrapper b-a text-sm">
	<div class="accordion-heading">
     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
        <h3 class="font-bold m-t-xs text-grey"> 1. Cari Barang Impian Anda </h3></a>
	</div>
	
	<div id="collapseOne" class="accordion-body collapse in">
        <div class="accordion-inner">
		<i class='fa fa-check'></i> Anda dapat mencari produk impian anda dalam kategori anda dengan mudah dan pastinya harga bersaing <br/>	

        </div>
    </div>
</div> 


</div> 
</div>
</div> 

