<?php
session_start();
if ($_SESSION['email'] != ''){
include "../config/koneksi.php";
include "../config/library.php";
include "../config/fungsi_thumb.php";
include "../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET[act];

// Hapus 
if ($module=='other-pro' AND $act=='hapus'){
  
  mysql_query("DELETE FROM as_chat WHERE chat_id='$_GET[id]'");
  header("Location: ../my-pesan.html?suc=delete");
}

}
else{
	header("Location: ../login.html?err=log");
}
?>