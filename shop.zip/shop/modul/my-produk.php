	<div class="b-b bg-light lter">
		<div class="container m-b-sm p-t-sm ">
			<div class="row row-sm">
			<div class="col-xs-12 m-t-sm text-muted text-sm">
				<?php include "breadcumb.php"; ?>
			</div>	 
			</div>
		</div>
	</div>
<?php

session_start();
$aksi="modul/aksi-produk.php";
switch($_GET[act]){
	default:
    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);	
$sql=mysql_query("SELECT * FROM produk A LEFT JOIN
						kustomer B ON A.id_kustomer=B.id_kustomer LEFT JOIN
						kategori C ON A.id_kategori=C.id_kategori
						WHERE B.id_kustomer = '$_SESSION[useri]'");
    $no = $posisi+1;	
$t=mysql_num_rows($sql);			
if($t=='0'){
    echo "<script>window.alert('Produk barang masih kosong');
        window.location=('index.php')</script>";
}
else{

	echo " <div id='content' class='main-content bg-lights'>
<div class='container'><div class='m-t-md'></div>
				<div class='row'>
					<div class='col-sm-12 link-info'>";
		$full_url = full_url();
		if (strpos($full_url, "?suc=ok") == TRUE){
			echo "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert'>&times;</a>
					<strong><i class='ion-android-done-all'></i> Sukses!</strong> Barang anda berhasil diupdate
					</div>";
		}
			$full_url = full_url();
									if (strpos($full_url, "?succ=ok") == TRUE){
										echo "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert'>&times;</a>
												<strong><i class='ion-android-done-all'></i> Sukses!</strong> Produk berhasil ditambahkan
											</div>";
									}			
		if (strpos($full_url, "?suc=delete") == TRUE){
			echo "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert'>&times;</a>
					<strong><i class='ion-android-done-all'></i> Sukses!</strong> Barang anda berhasil dihapus
					</div>";		
		}
		if (strpos($full_url, "?suc=canok") == TRUE){
			echo "<div class='messagesuccess' style='width: auto;'><p><b>Iklan Anda berhasil dibatalkan dan dihilangkan dalam daftar.</b></p></div>";
		}						
		echo"<div class='panel b-a'>
							<div class='panel-heading b-b b-light'>
								<span class='font-bold'><i class='ion-bag m-r-xs'></i> My Lapak</span>
							</div>	
	<table class='table table-striped m-b-none'>
		<thead class='panel-heading b-b b-light'>
			<tr>
				<th>#</th>	
				<th>Kategori</th>					
				<th>Barang</th>
				<th>Harga</th>
				<th>Stok</th>		
				<th>Tanggal</th>
				<th>Aksi</th>
			</tr></thead><tbody>";	
		
	while($r = mysql_fetch_array($sql)){
				$tanggal=tgl_indo($r['tgl_masuk']);
				$harga     = format_rupiah($r['harga']);
		echo "<tr><td>$no</td>
				  <td>$r[nama_kategori]</td>
				  <td>$r[nama_produk]</td>
				  <td>Rp.$harga </td>
				  <td>$r[stok]</td>
				  <td>$tanggal</td>
				  <td><a class='text-sm' href='edit-produk-1-1-$r[id_produk].html'><i class='ion-compose'></i> Update</a> |
						<a class='text-sm' href='produk-$r[id_produk]-$r[produk_seo].html'><i class='ion-monitor'></i> Review</a> |
						<a class='text-sm' href='edit-produk-1-1-$r[id_produk].html'>
						<a href='$aksi?module=produk&act=hapus&id=$r[id_produk]' onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">
								<i class='ion-trash-b'></i> Hapus</a>
					</td></tr>";
		$no++;
	}
				  
				  
	echo "</table>
	
	</div></div></div>";	
    $jmldata = mysql_num_rows(mysql_query("SELECT * FROM produk"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

				  echo "<div class='text-right m-b-sm'>
						<ul class='pagination pagination-md'>
							<li><a href='#'>Halaman : $linkHalaman </a></li>
						</ul></div></div>";	
	}
	
	
break;	

/*
  case "editproduk":
  
	$edit = mysql_query("SELECT * FROM produk WHERE id_produk='$_GET[id]'");
    $r    = mysql_fetch_array($edit);
  
	echo"<div class='container'>
			<div class='m-t-md'></div>
				<div class='row'>
					<form method=POST action='$aksi?module=produk&act=update' enctype='multipart/form-data'>
					    <input type=hidden name=id value=$r[id_produk]>
						<div class='col-sm-8 link-info'>
							<div class='panel panel-default'>
								<div class='panel-heading font-bold'>Jual Barang</div>
								<div class='panel-body'>
									<div class='form-group'>
										<label class='col-lg-2 control-label'>Nama Barang</label>
										<div class='col-lg-10'>
											<input class='form-control text-sm' type='text' id='name' name='nama_produk' maxlength='50' value='$r[nama_produk]'>
											<span class='help-block'></span>
										</div>
									</div>
									<div class='form-group'>
										<label class='col-lg-2 control-label'>Kategori</label>
										<div class='col-lg-10'>
											<select name='kategori' class='form-control text-sm'>";
											  $tampil=mysql_query("SELECT * FROM kategori ORDER BY nama_kategori");
											  if ($r[id_kategori]==0){
												echo "<option value=0 selected>- Pilih Kategori -</option>";
											  }   

											  while($w=mysql_fetch_array($tampil)){
												if ($r[id_kategori]==$w[id_kategori]){
												  echo "<option value=$w[id_kategori] selected>$w[nama_kategori]</option>";
												}
												else{
												  echo "<option value=$w[id_kategori]>$w[nama_kategori]</option>";
												}
											  }
											echo"</select>
											<span class='help-block'>Pilih kategori iklan.</span>
										</div>
									</div>
									<div class='form-group m-t-xl'>
										<label class='col-lg-2 control-label m-t-md '>Harga</label>
										<div class='col-lg-10'>
											<input class='form-control m-t-md text-sm' type='text'  value='$r[harga]' name='harga'>
											<span class='help-block'></span>
										</div>
									</div>
									<div class='form-group m-t-xl'>
										<label class='col-lg-2 control-label m-t-md '>Diskon</label>
										<div class='col-lg-10'>
											<input class='form-control m-t-md text-sm' type='text' value='$r[diskon]' name='diskon'>
											<span class='help-block'></span>
										</div>
									</div>		
									<div class='form-group m-t-xl'>
										<label class='col-lg-2 control-label m-t-md '>Stok</label>
										<div class='col-lg-10'>
											<input class='form-control m-t-md text-sm' type='text' value='$r[stok]' name='stok'>
											<span class='help-block'></span>
										</div>
									</div>			
									<div class='form-group m-t-xl'>
										<label class='col-lg-2 control-label m-t-md '>Berat</label>
										<div class='col-lg-10'>
											<input class='form-control m-t-md text-sm' type='text' value='$r[berat]' name='berat'>
											<span class='help-block'></span>
										</div>
									</div>									
									<div class='form-group'>
										<label class='col-sm-2 control-label'>Keterangan</label>
										<div class='col-sm-10'>
											<textarea name='deskripsi' style='width: 450px; height: 150px;' class='ckeditor'>$r[deskripsi]</textarea>
										</div>
									</div>
									<div class='form-group'>
										<label class='col-lg-2 control-label m-t-md '>Gambar</label>
										<img src='../static/products/foto_produk/small_$r[gambar]'>
										<div class='col-lg-10'>
											<input class='form-control m-t-md' type='file' placeholder='Harga satuan' name='fupload' value=''>
											<span class='help-block'></span>
										</div>
									</div>
									<div class='form-group'>
										<div class='col-sm-4 col-sm-offset-2 m-t-md'>
											<input type='hidden' name='upload' value='yes'/>
											<button type='submit' id='submit-btn' class='btn btn-info'>Simpan</button>
										</div>
									</div>									
								</div>
							</div>
							
						</div>

							<div class='col-sm-4 '>
							<div class='panel b-a'>
								<div class='panel-heading b-b b-light'>
									<span class='font-bold'><i class='fa fa-bar-chart m-r-xs'></i> Total Saldo</span>
								</div>
								<div class='panel-body link-info'>
									<p> 1. Banyak Barang <strong>1</strong></p>
									<p> 2. Total Harga <strong>Rp. 150.000</strong></p>
									<p> 3. Sub Total <strong>Rp. 150.000</strong></p>
								</div>
								<div class='panel-footer bg-light lter text-center '>
									<img src='static/img/mandiri.png' height='32' width='32' class='m-r-sm m-t-n m-b-n'>
									<img src='static/img/bni.png' height='32' width='32' class='m-r-sm m-t-n m-b-n'>
									<img src='static/img/bri.png' height='32' width='32' class='m-r-sm m-t-n m-b-n'>
								</div>								
							</div>
						</div>

						
					</form>
				</div>
			</div>
		</div>";  
  
  break;
*/
}	
?>