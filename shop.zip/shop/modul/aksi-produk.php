<?php
session_start();
if ($_SESSION['email'] != ''){
include "../config/koneksi.php";
include "../config/library.php";
include "../config/fungsi_thumb.php";
include "../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET[act];

// Hapus produk
if ($module=='produk' AND $act=='hapus'){
  $data=mysql_fetch_array(mysql_query("SELECT gambar FROM produk WHERE id_produk='$_GET[id]'"));
  if ($data['gambar']!=''){
     mysql_query("DELETE FROM produk WHERE id_produk='$_GET[id]'");
     unlink("../static/products/foto_produk/$_GET[namafile]");   
     unlink("../static/products/foto_produk/small_$_GET[namafile]");   
	 unlink("../static/products/foto_produk/medium_$_GET[namafile]"); 
	 unlink("../static/products/foto_produk/big_$_GET[namafile]");
  }
  else{
     mysql_query("DELETE FROM produk WHERE id_produk='$_GET[id]'");
  }
  header("Location: ../my-produk.html?suc=delete");	
  
  mysql_query("DELETE FROM produk WHERE id_produk='$_GET[id]'");
  header("Location: ../my-produk.html?suc=delete");
}

}
else{
	header("Location: ../login.html?err=log");
}
?>