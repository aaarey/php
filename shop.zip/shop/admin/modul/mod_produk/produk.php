<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_produk/aksi_produk.php";
switch($_GET[act]){
  // Tampil Produk
  default:
    echo "<h2>Produk</h2>
          <input type=button value='Tambah' onclick=\"window.location.href='?module=produk&act=tambahproduk';\">
          <table>
          <tr>
		<th>#</th>
		  <th>Member</th>
		  <th>produk</th>
		  <th>kategori</th>
		  <th>berat(gr)</th>
		  <th>harga</th>
		  <th>stok</th>
		  <th>tgl. masuk</th>
		  <th>aksi</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($koneksi,"SELECT * FROM produk A LEFT JOIN
							kategori B ON A.id_kategori=B.id_kategori LEFT JOIN
							kustomer C ON A.id_kustomer=C.id_kustomer 
							ORDER BY id_produk DESC LIMIT $posisi,$batas");
  
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
      $tanggal=tgl_indo($r[tgl_masuk]);
      $harga=format_rupiah($r[harga]);
      echo "<tr>
				<td>$no</td>
                <td>$r[nama_lengkap]</td>	  
                <td>$r[nama_produk]</td>
				<td>$r[nama_kategori]</td>
                <td align=center>$r[berat]</td>
                <td>$harga</td>
                <td align=center>$r[stok]</td>
                <td>$tanggal</td>
		            <td><a href=?module=produk&act=editproduk&id=$r[id_produk]>Edit</a> | 
		                <a href='$aksi?module=produk&act=hapus&id=$r[id_produk]&namafile=$r[gambar]' onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM produk"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
 
    break;
  
  case "tambahproduk":
    echo "<h2>Tambah Produk</h2>
          <form method=POST action='$aksi?module=produk&act=input' enctype='multipart/form-data'>
         <table cellpadding='8' width='100%'>
          <tr><td width=100>Nama Produk</td>     <td> : <input type=text name='nama_produk' size=60 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td>Kategori</td>  <td> : 
          <select name='kategori' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'>
            <option value=0 selected>- Pilih Kategori -</option>";
            $tampil=mysqli_query($koneksi,"SELECT * FROM kategori ORDER BY nama_kategori");
            while($r=mysqli_fetch_array($tampil)){
              echo "<option value=$r[id_kategori]>$r[nama_kategori]</option>";
            }
    echo "</select></td></tr>
          <tr><td>Kondisi</td>     <td> : <input type=radio name='kondisi' value='Baru'> Baru
										  <input type=radio name='kondisi' value='Bekas'> Bekas
			</td></tr>	
          <tr><td>Berat</td>     <td> : <input type=text name='berat' size=3 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'> gr</td></tr>
          <tr><td>Harga</td>     <td> : <input type=text name='harga' size=10 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td>Diskon</td>     <td> : <input type=text name='diskon' size=2 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'> %</td></tr>
          <tr><td>Stok</td>     <td> : <input type=text name='stok' size=3 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>	  
          <tr><td>Deskripsi</td>  <td> <textarea name='deskripsi' class='ckeditor' style='width: 580px; height: 350px;'></textarea></td></tr>
          <tr><td>Gambar</td>      <td> : <input type=file name='fupload' size=40> 
                                          <br>Tipe gambar harus JPG/JPEG dan ukuran lebar maks: 400 px</td></tr>
          <tr><td colspan=2><input type=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;
    
  case "editproduk":
    $edit = mysqli_query($koneksi,"SELECT * FROM produk A LEFT JOIN
					kustomer B ON A.id_kustomer=B.id_kustomer 
					WHERE A.id_produk='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);
	if ($r['kondisi'] == 'Baru'){
		$checka = 'checked';
	}
	elseif($r['kondisi'] == 'Bekas'){
		$checkb = 'checked';
	}
	else{
		$checka = '';
		$checkb = '';
	}
    echo "<h2>Edit Produk</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=produk&act=update>
          <input type=hidden name=id value=$r[id_produk]>
         <table cellpadding='8' width='100%'>
          <tr><td width=80>ID Produk</td>     <td> : <input type=text name='ref_id' size=60 value='$r[ref_id]' disabled style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>	
          <tr><td width=80>Member Produk</td>     <td> : <input type=text name='nama_lengkap' size=60 value='$r[nama_lengkap]' disabled style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>		  
          <tr><td width=80>Nama Produk</td>     <td> : <input type=text name='nama_produk' size=60 value='$r[nama_produk]' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td>Kategori</td>  <td> : <select style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;' name='kategori'>";
 
          $tampil=mysqli_query($koneksi,"SELECT * FROM kategori ORDER BY nama_kategori");
          if ($r[id_kategori]==0){
            echo "<option value=0 selected>- Pilih Kategori -</option>";
          }   

          while($w=mysqli_fetch_array($tampil)){
            if ($r[id_kategori]==$w[id_kategori]){
              echo "<option value=$w[id_kategori] selected>$w[nama_kategori]</option>";
            }
            else{
              echo "<option value=$w[id_kategori]>$w[nama_kategori]</option>";
            }
          }
    echo "</select></td></tr>
          <tr><td>Berat</td>     <td> : <input type=text name='berat' value=$r[berat] size=3 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td>Harga</td>     <td> : <input type=text name='harga' value=$r[harga] size=10 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td>Diskon</td>     <td> : <input type=text name='diskon' value=$r[diskon] size=2 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td>Stok</td>     <td> : <input type=text name='stok' value=$r[stok] size=3 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;' ></td></tr>
          <tr><td>Kondisi</td>     <td> : <input type='radio' name='kondisi' value='Baru' $checka>Baru
										<input type='radio' name='kondisi' value='Bekas' $checkb>Bekas</td></tr>				  
          <tr><td>Deskripsi</td>   <td> <textarea name='deskripsi' class='ckeditor'>$r[deskripsi]</textarea></td></tr>
          <tr><td>Gambar</td>       <td> :  
          <img src='../static/products/foto_produk/thumb/small_$r[gambar]'></td></tr>
          <tr><td>Update</td>    <td> : <input type=file name='fupload' size=30> *)</td></tr>
          <tr><td colspan=2>*) Apabila gambar tidak diubah, dikosongkan saja.</td></tr>
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
}
?>
