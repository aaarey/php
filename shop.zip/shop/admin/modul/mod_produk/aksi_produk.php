<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";
include "../../../config/fungsi_seo.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus produk
/*
if ($module=='produk' AND $act=='hapus'){
  $data=mysql_fetch_array(mysql_query("SELECT gambar FROM produk WHERE id_produk='$_GET[id]'"));
  if ($data['gambar']!=''){
     mysql_query("DELETE FROM produk WHERE id_produk='$_GET[id]'");
     unlink("../../../static/products/foto_produk/$_GET[namafile]");   
     unlink("../../../static/products/foto_produk/small_$_GET[namafile]");   
	 unlink("../../../static/products/foto_produk/medium_$_GET[namafile]"); 
	 unlink("../../../static/products/foto_produk/big_$_GET[namafile]");
  }
  else{
     mysql_query("DELETE FROM produk WHERE id_produk='$_GET[id]'");
  }
  header('location:../../media.php?module='.$module);

  mysql_query("DELETE FROM produk WHERE id_produk='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}
*/

if ($module == 'produk' AND $act == 'hapus'){
	$data = mysqli_fetch_array(mysqli_query($koneksi,"SELECT gambar, gambar2, gambar3 FROM produk WHERE id_produk = '$_GET[id]'"));
	if ($data['gambar'] != '' || $data['gambar2'] != '' || $data['gambar3'] != ''){
			mysqli_query($koneksi,"DELETE FROM produk WHERE id_produk = '$_GET[id]'");
			unlink("../../../static/products/foto_produk/$_GET[filename]");
			unlink("../../../static/products/foto_produk/$_GET[filename2]");
			unlink("../../../static/products/foto_produk/$_GET[filename3]");					
	}
	else{
			mysqli_query($koneksi,"DELETE FROM produk WHERE id_produk = '$_GET[id]'");
	}
		
	header('Location: ../../media.php?module='.$module);
}

// Input produk
elseif ($module=='produk' AND $act=='input'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  $produk_seo      = seo_title($_POST[nama_produk]);

  
   $mime = array(
   'image/png' => '.png',
   'image/x-png' => '.png',
   'image/jpeg' => '.jpg',
   'image/pjpeg' => '.jpg');
   
   $ekstensi = substr($nama_file_unik, strrpos($nama_file_unik, '.')); 

  // Apabila ada gambar yang diupload
  if (!empty($lokasi_file)){
    if (!array_keys($mime, $ekstensi)){
      echo "<script>window.alert('Upload Gagal, Pastikan File yang di Upload bertipe JPG/GIF/PNG.');
      window.location=('../../media.php?module=produk')</script>";
    }
    else{
    UploadFiles($nama_file_unik);

    mysqli_query($koneksi,"INSERT INTO produk(nama_produk,
                                    produk_seo,
                                    id_kategori,
                                    berat,
                                    harga,
									kondisi,
                                    diskon,
                                    stok,
                                    deskripsi,
                                    tgl_masuk,
                                    gambar) 
                            VALUES('$_POST[nama_produk]',
                                   '$produk_seo',
                                   '$_POST[kategori]',
                                   '$_POST[berat]',
                                   '$_POST[harga]',
								   '$_POST[kondisi]',
                                   '$_POST[diskon]',
                                   '$_POST[stok]',
                                   '$_POST[deskripsi]',
                                   '$tgl_sekarang',
                                   '$nama_file_unik')");
  header('location:../../media.php?module='.$module);
  }
  }
  else{
    mysqli_query($koneksi,"INSERT INTO produk(nama_produk,
                                    produk_seo,
                                    id_kategori,
                                    berat,
                                    harga,
									kondisi,
                                    diskon,
                                    stok,
                                    deskripsi,								
                                    tgl_posting) 
                            VALUES('$_POST[nama_produk]',
                                   '$produk_seo',
                                   '$_POST[kategori]',
                                   '$_POST[berat]',                                 
                                   '$_POST[harga]',
								   '$_POST[kondisi]',
                                   '$_POST[diskon]',
                                   '$_POST[stok]',
                                   '$_POST[deskripsi]',								   
                                   '$tgl_sekarang')");
  header('location:../../media.php?module='.$module);
  }
}

// Update produk
elseif ($module=='produk' AND $act=='update'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  $produk_seo      = seo_title($_POST[nama_produk]);

  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($koneksi,"UPDATE produk SET nama_produk = '$_POST[nama_produk]',
                                   produk_seo  = '$produk_seo', 
                                   id_kategori = '$_POST[kategori]',
                                   berat       = '$_POST[berat]',
                                   harga       = '$_POST[harga]',
								   kondisi	   = '$_POST[kondisi]',
                                   diskon      = '$_POST[diskon]',
                                   stok        = '$_POST[stok]',
                                   deskripsi   = '$_POST[deskripsi]'
                             WHERE id_produk   = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
  }
  else{
    if ($tipe_file != "image/jpeg" AND $tipe_file != "image/pjpeg"){
    echo "<script>window.alert('Upload Gagal, Pastikan File yang di Upload bertipe *.JPG');
        window.location=('../../media.php?module=produk)</script>";
    }
    else{
    UploadImage($nama_file_unik);
    mysqli_query($koneksi,"UPDATE produk SET nama_produk = '$_POST[nama_produk]',
                                   produk_seo  = '$produk_seo', 
                                   id_kategori = '$_POST[kategori]',
                                   berat       = '$_POST[berat]',
                                   harga       = '$_POST[harga]',
                                   diskon      = '$_POST[diskon]',
								   kondisi	   = '$_POST[kondisi]',
                                   stok        = '$_POST[stok]',
                                   deskripsi   = '$_POST[deskripsi]',								   
                                   gambar      = '$nama_file_unik'   
                             WHERE id_produk   = '$_POST[id]'");
    header('location:../../media.php?module='.$module);
    }
  }
}
}
?>
