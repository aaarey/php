<?php
$aksi="modul/mod_favorit/aksi_favorit.php";
switch($_GET[act]){
  // Tampil 
  default:
    echo "<h2>Favorit</h2>

          <table>
          <tr><th>no</th>
		  <th>Produk</th>
		  <th>Member</th>
		  <th>aksi</th></tr>"; 
		$sql=mysqli_query($koneksi,"SELECT * FROM favorit A LEFT JOIN
					produk B ON A.id_produk=B.id_produk LEFT JOIN
					kategori C ON B.id_kategori=C.id_kategori LEFT JOIN
					kustomer D ON A.id_kustomer=D.id_kustomer
					ORDER BY A.id_favorit");
    $no=1;
    while ($r=mysqli_fetch_array($sql)){
       echo "<tr><td>$no</td>
             <td>$r[nama_produk]</td>
			 <td>$r[nama_lengkap]</td>
             <td><a href=$aksi?module=favorit&act=hapus&id=$r[id_favorit]>Hapus</a>
             </td></tr>";
      $no++;
    }
    echo "</table>";
    break;

}
?>