<?php
error_reporting(0);
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
	echo "<link href='style.css' rel='stylesheet' type='text/css'>
	<center>Untuk akses modul, Anda harus login terlebih dahulu<br>
	<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";
include "../../../config/fungsi_seo.php";

	$module	= $_GET['module'];
	$act	= $_GET['act'];

	// Delete
	if ($module == 'member' AND $act == 'change'){
		mysqli_query($koneksi,"UPDATE kustomer SET status = 'Y' WHERE id_kustomer = '$_POST[id]'");
		header('Location: ../../media.php?module='.$module);
	}
}
?>