<?php
session_start();
if (empty(  $_SESSION['namauser'] ) AND empty( $_SESSION['passuser'])){
	echo "
				<section id='error-number'>
					<img src='img/lock.png'>
					<h1>MODUL TIDAK DAPAT DIAKSES</h1>
					<p><span class style=\"font-size:14px; color:#ccc;\">Untuk akses modul, Anda harus login terlebih dahulu</p></span><br/>
				</section>
";
}
else{
include "../../../config/koneksi.php";
$aksi="modul/mod_member/aksi_member.php";
switch($_GET[act]){
  // Tampil 
  default:
    echo "<h2>Member</h2>

          <table>
          <tr><th>no</th>
		  <th>Username</th>
		  <th>Email</th>
		  <th>Status</th>
		  <th>Alamat</th>
		  <th>Login </th>
		  <th align='tengah'>Aksi</th></tr>"; 
		$sql=mysqli_query($koneksi,"SELECT * FROM kustomer
					ORDER BY id_kustomer");
    $no=1;
    while ($r=mysqli_fetch_array($sql)){
										if ($r['status'] == 'Y'){
											$status = "Aktif";
										}
										else{
											$status = "Tidak Aktif";
										}
		$last = date('Y-m-d H:i:s');
       echo "<tr><td>$no</td>
             <td>$r[username]</td>
			 <td>$r[email]</td>
			 <td>$status</td>
			 <td>$r[daerah]</td>
			 <td>$last</td>
             <td>
				<a href='?module=member&act=viewmember&id=$r[id_kustomer]'>Edit</a> |";
?>
					
	
								
<?php								
			echo"<a href=$aksi?module=member&act=hapus&id=$r[id_kustomer] onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a>
             </td></tr>";
      $no++;
    }
    echo "</table>";
    break;
	
	case "viewmember":
	$r = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM kustomer A LEFT JOIN 
															kota B ON A.id_kota=B.id_kota
															WHERE A.id_kustomer = '$_GET[id]'"));	
	if ($r['status'] == 'Y'){
		$status = "Aktif";
	}
	else{
		$status = "Tidak Aktif";
	}	

	echo "<h2>Edit Member</h2>
	<table>
		<tr>
			<td>Status</td>
			<td>$status</td>
		</tr>	
		<tr>
			<td>Username</td>
			<td>$r[username]</td>
		</tr>	
		<tr>
			<td>Nama Lengkap</td>
			<td>$r[nama_lengkap]</td>
		</tr>
		<tr>
			<td>Kota</td>
			<td>$r[nama_kota]</td>
		</tr>
		<tr>
			<td>Email</td>
			<td>$r[email]</td>
		</tr>
		<tr>
			<td>Hp</td>
			<td>$r[hp]</td>
		</tr>		
		";
?>
					<?php if ($r['status'] == 'Y'){ ?>
								<form method="POST" action="modul/mod_member/not_active.php?module=member&act=change">
									<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" />
									<input type='submit' name='submit' class='button' value='Non Aktifkan'>
								</form>
								<?php } else{ ?>
								<form method="POST" action="modul/mod_member/active.php?module=member&act=change">
									<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" />
									<input type='submit' name='submit' class='button' value='Aktifkan'>
								</form>
					<?php } ?>	
					<input type='button' value='Kembali' onclick='self.history.back()'>
<?php					
	echo"</table>";
break;
}
}
?>