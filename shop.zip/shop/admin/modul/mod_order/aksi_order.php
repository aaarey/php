<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

if ($module=='order' AND $act=='update'){
   // Update stok barang saat transaksi sukses (Lunas)
   if ($_POST[status_order]=='Dibayar'){ 
    
      // Update untuk mengurangi stok 
      mysqli_query($koneksi,"UPDATE produk,orders_detail SET produk.stok=produk.stok-orders_detail.jumlah 
	  WHERE produk.id_produk=orders_detail.id_produk and orders_detail.id_orders='$_POST[id]'");
	  
	  // Update untuk menambahkan produk yang dibeli (best seller = produk yang paling laris)
      mysqli_query($koneksi,"UPDATE produk,orders_detail SET produk.dibeli=produk.dibeli+orders_detail.jumlah 
	  WHERE produk.id_produk=orders_detail.id_produk and orders_detail.id_orders='$_POST[id]'");

      // Update status order
      mysqli_query($koneksi,"UPDATE orders SET status_order='$_POST[status_order]' where id_orders='$_POST[id]'");

      // Update status order
      mysqli_query($koneksi,"UPDATE orders SET status_order='$_POST[status_order]',dibayar = '1'
						where id_orders='$_POST[id]'");

      header('location:../../media.php?module='.$module);
    }	  
	  elseif($_POST[status_order]=='Dikembalikan'){
	    // Update untuk menambah stok
	    mysqli_query($koneksi,"UPDATE produk,orders_detail SET produk.stok=produk.stok+orders_detail.jumlah
		WHERE produk.id_produk=orders_detail.id_produk and orders_detail.id_orders='$_POST[id]'"); 
	    
	    // Update untuk menambahkan produk yang tidak jadi dibeli (tidak jd best seller)
      mysqli_query($koneksi,"UPDATE produk,orders_detail SET produk.dibeli=produk.dibeli-orders_detail.jumlah 
	  WHERE produk.id_produk=orders_detail.id_produk and orders_detail.id_orders='$_POST[id]'");

	    // Update status order Batal
      mysqli_query($koneksi,"UPDATE orders SET status_order='$_POST[status_order]' where id_orders='$_POST[id]'");

	    header('location:../../media.php?module='.$module);
	  }
    else{
      mysqli_query($koneksi,"UPDATE orders SET status_order='$_POST[status_order]', dibayar = '1'
					where id_orders='$_POST[id]'");
      header('location:../../media.php?module='.$module);
    }
}
}
?>
