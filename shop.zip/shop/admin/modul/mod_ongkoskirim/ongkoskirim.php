<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";
$aksi="modul/mod_ongkoskirim/aksi_ongkoskirim.php";
switch($_GET[act]){
  // Tampil Ongkos Kirim
  default:
    echo "<h2>Ongkos Kirim</h2>
          <input type=button value='Tambah Ongkos Kirim' 
          onclick=\"window.location.href='?module=ongkoskirim&act=tambahongkoskirim';\">
          <table>
          <tr><th>no</th><th>Pengiriman</th><th>nama kota</th><th>ongkos kirim</th>
			<th>Lama</th><th>aksi</th></tr>"; 
	$p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);	  
   
   $tampil=mysqli_query($koneksi,"SELECT * FROM kota, shop_pengiriman WHERE kota.id_perusahaan=shop_pengiriman.id_perusahaan 
   ORDER BY id_kota DESC LIMIT $posisi,$batas");
	$no=$posisi+1;
    while ($r=mysqli_fetch_array($tampil)){
       $ongkos = format_rupiah($r[ongkos_kirim]);
       echo "<tr><td>$no</td>
			 <td>$r[nama_perusahaan]</td>
             <td>$r[nama_kota]</td>
             <td align=right>$ongkos</td>
			 <td>$r[lama] hari</td>
             <td><a href=?module=ongkoskirim&act=editongkoskirim&id=$r[id_kota]>Edit</a> | 
	               <a href=$aksi?module=ongkoskirim&act=hapus&id=$r[id_kota] onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a>
             </td></tr>";
      $no++;
    }
    echo "</table>";
    $jmldata=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM kota"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    echo "<div id=paging>$linkHalaman</div><br>";    	
    break;
  
  // Form Tambah Ongkos Kirim
  case "tambahongkoskirim":
    echo "<h2>Tambah Ongkos Kirim</h2>
          <form method=POST action='$aksi?module=ongkoskirim&act=input'>
         <table cellpadding='8' width='100%'>
			<tr><td>Jasa Pengiriman</td>  <td> 
			<select name='perusahaan' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'>
            <option value='' selected>- Pilih Jasa Pengiriman -</option>";
            $tampil=mysqli_query($koneksi,"SELECT * FROM shop_pengiriman ORDER BY nama_perusahaan");
            while($r=mysqli_fetch_array($tampil)){
                echo "<option value=$r[id_perusahaan]>$r[nama_perusahaan]</option>";
            }		  
          echo"
          <tr><td>Nama Kota</td><td>  <input type=text name='nama_kota' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>		  
          <tr><td>Alamat Tujuan</td><td> <input type=text name='kota_tujuan' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>		  
		  <tr><td>Ongkos Kirim/Kg</td><td> <input type=text name='ongkos_kirim' size=7 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 200px; margin-right: 10px; padding: 5px;'></td></tr>
		  <tr><td>Lama Pengiriman</td><td> <input type=text name='lama' size=7 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 200px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td colspan=2><input type=submit name=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;
  
  // Form Edit Ongkos Kirim
  case "editongkoskirim":
    $edit=mysqli_query($koneksi,"SELECT * FROM kota A LEFT JOIN
								shop_pengiriman B ON A.id_perusahaan=B.id_perusahaan
								WHERE A.id_kota='$_GET[id]'");
    $r=mysqli_fetch_array($edit);

    echo "<h2>Edit Ongkos Kirim</h2>
          <form method=POST action=$aksi?module=ongkoskirim&act=update>
          <input type=hidden name=id value='$r[id_kota]'>
         <table cellpadding='8' width='100%'>
    							<tr>
    								<td>Pengiriman</td>";
									?>
    								<td><select name='perusahaan' style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;">
    										<option value="">Pilih Pengiriman</option>
    										<?php
    										$sql_cat = mysqli_query($koneksi,"SELECT * FROM shop_pengiriman ORDER BY nama_perusahaan");
											while ($data_cat = mysqli_fetch_array($sql_cat)){
												if ($data_cat['id_perusahaan'] == $r['id_perusahaan']){
													echo "<option value=$data_cat[id_perusahaan] SELECTED>$data_cat[nama_perusahaan]</option>";
												}
												else{
													echo "<option value=$data_cat[id_perusahaan]>$data_cat[nama_perusahaan]</option>";
												}
											}
											?>
    									</select>
    								</td>
    							</tr>		  
		  <?php
          echo"
		  <tr><td>Nama Kota</td><td>  <input type=text name='nama_kota' value='$r[nama_kota]' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>		  
		  <tr><td>Alamat Tujuan</td><td>  <input type=text name='kota_tujuan' value='$r[kota_tujuan]' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>			  
          <tr><td>Ongkos Kirim/Kg</td><td>  <input type=text name='ongkos_kirim' value='$r[ongkos_kirim]' size=7 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 200px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td>Lama Pengirim</td><td>  <input type=text name='lama' value='$r[lama]' size=7 style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 200px; margin-right: 10px; padding: 5px;'></td></tr>		  
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    break;  
}
}
?>
