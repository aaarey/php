<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus Ongkos Kirim
if ($module=='ongkoskirim' AND $act=='hapus'){
  mysqli_query($koneksi,"DELETE FROM kota WHERE id_kota='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input Ongkos Kirim
elseif ($module=='ongkoskirim' AND $act=='input'){
  mysqli_query($koneksi,"INSERT INTO kota(id_perusahaan,nama_kota,ongkos_kirim,lama,kota_tujuan) 
				VALUES('$_POST[perusahaan]','$_POST[nama_kota]','$_POST[ongkos_kirim]','$_POST[lama]','$_POST[kota_tujuan]')");
  header('location:../../media.php?module='.$module);
}

// Update Ongkos Kirim
elseif ($module=='ongkoskirim' AND $act=='update'){
  mysqli_query($koneksi,"UPDATE kota SET id_perusahaan = '$_POST[perusahaan]', 
								nama_kota = '$_POST[nama_kota]', 
								ongkos_kirim='$_POST[ongkos_kirim]', 
								kota_tujuan = '$_POST[kota_tujuan]',
								lama='$_POST[lama]'
  WHERE id_kota = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
}
}
?>
