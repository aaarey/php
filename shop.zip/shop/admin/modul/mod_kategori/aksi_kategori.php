<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";
include "../../../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus kategori
if ($module=='kategori' AND $act=='hapus'){
  $data=mysqli_fetch_array(mysqli_query($koneksi,"SELECT icon FROM kategori WHERE id_kategori='$_GET[id]'"));
  if ($data['icon']!=''){
     mysqli_query($koneksi,"DELETE FROM kategori WHERE id_kategori='$_GET[id]'");
     unlink("../../../static/foto_kategori/$_GET[namafile]");   
  }
  else{
    mysqli_query($koneksi,"DELETE FROM kategori WHERE id_kategori='$_GET[id]'");
  }
  header('location:../../media.php?module='.$module);
}

// Input kategori
elseif ($module=='kategori' AND $act=='input'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];
  $tipe_file   = $_FILES['fupload']['type'];
	$created_date = date('Y-m-d H:i:s');
	$date = date('Y-m-d');
	$kategori_seo      = seo_title($_POST['nama_kategori']);
  // Apabila ada icon yang diupload
  if (!empty($lokasi_file)){
    if ($tipe_file != "image/jpeg" AND $tipe_file != "image/pjpeg"){
    echo "<script>window.alert('Upload Gagal, Pastikan File yang di Upload bertipe *.JPG');
        window.location=('../../media.php?module=kategori)</script>";
    }
    else{
    UploadKategori($nama_file);
    mysqli_query($koneksi,"INSERT INTO kategori(nama_kategori,
                                    kategori_seo,
                                    aktif,
									label,
                                    icon,
									created_date,
									created_userid) 
                            VALUES('$_POST[nama_kategori]',
                                   '$kategori_seo',
                                   '$_POST[aktif]',
								   '$_POST[label]',
                                   '$nama_file',
								   '$created_date',
								   '$_SESSION[userid]')");
  header('location:../../media.php?module='.$module);
  }
  }
  else{
    mysqli_query($koneksi,"INSERT INTO kategori(nama_kategori,
                                    kategori_seo,
                                    aktif,
									label,
									created_date,
									created_userid) 
                            VALUES('$_POST[nama_kategori]',
                                   '$kategori_seo',
                                   '$_POST[aktif]',
								   '$_POST[label]',
								   '$created_date',
								   '$_SESSION[userid]')");
  header('location:../../media.php?module='.$module);
  }
}

// Update kategori
elseif ($module=='kategori' AND $act=='update'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];
  $tipe_file   = $_FILES['fupload']['type'];
	$kategori_seo      = seo_title($_POST['nama_kategori']);
  // Apabila icon tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($koneksi,"UPDATE kategori SET nama_kategori     = '$_POST[nama_kategori]',
									kategori_seo		= '$kategori_seo',
									aktif				= '$_POST[aktif]',
									label				= '$_POST[label]'
                             WHERE id_kategori = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
  }
  else{
    if ($tipe_file != "image/jpeg" AND $tipe_file != "image/pjpeg"){
    echo "<script>window.alert('Upload Gagal, Pastikan File yang di Upload bertipe *.JPG');
        window.location=('../../media.php?module=kategori)</script>";
    }
    else{
    UploadKategori($nama_file);
    mysqli_query($koneksi,"UPDATE kategori SET nama_kategori     = '$_POST[nama_kategori]',
									kategori_seo		= '$kategori_seo',
									aktif				= '$_POST[aktif]',
									label				= '$_POST[label]'
									icon   				= '$nama_file'   
                             WHERE id_kategori = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
  }
  }
}
}
?>
