<?php
session_start();
$uploaddir = '../../../static/foto_kategori/';
$file = $uploaddir .date('Ymdhis')."_".basename($_FILES['uploadfile']['name']); 
$file_name = date('Ymdhis')."_".$_FILES['uploadfile']['name']; 

if (move_uploaded_file($_FILES['uploadfile']['tmp_name'], $file)) {
	echo "$file_name"; 
} 
else {
	echo "error";
}
?>