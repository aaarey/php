<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_kategori/aksi_kategori.php";
switch($_GET[act]){
  // Tampil kategori
  default:
    echo "<h2>kategori</h2>
          <input type=button value='Tambah Kategori' onclick=location.href='?module=kategori&act=tambahkategori'>
          <table>
          <tr><th>no</th><th>kategori</th><th>label</th><th>aktif</th><th>aksi</th></tr>";
    $tampil=mysqli_query($koneksi,"SELECT * FROM kategori ORDER BY id_kategori DESC");
    $no=1;
    while ($r=mysqli_fetch_array($tampil)){
      echo "<tr><td>$no</td>
                <td>$r[nama_kategori]</td>
                <td>$r[label]</td>
                <td>$r[aktif]</td>
                <td><a href=?module=kategori&act=editkategori&id=$r[id_kategori]>Edit</a> | 
	                  <a href='$aksi?module=kategori&act=hapus&id=$r[id_kategori]&namafile=$r[icon]'>Hapus</a>
		        </tr>";
    $no++;
    }
    echo "</table>";
    break;
  
  case "tambahkategori":
    echo "<h2>Tambah kategori</h2>
          <form method=POST action='$aksi?module=kategori&act=input' enctype='multipart/form-data'>
          <table>
          <tr><td>Nama Kategori</td><td>  : <input type=text name='nama_kategori' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td>Label</td><td>   : <input type=text name='label' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>
          <tr><td>Aktif</td>      <td> : <input type=radio name='aktif' value='Y' checked>Y 
                                         <input type=radio name='aktif' value='N'>N  </td></tr>		  
          <tr><td>Gambar</td><td> : <input type=file name='fupload' size=40></td></tr>
		  
          <tr><td colspan=2><input type=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form><br><br><br>";
     break;
    
  case "editkategori":
    $edit = mysqli_query($koneksi,"SELECT * FROM kategori WHERE id_kategori='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit kategori</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=kategori&act=update>
          <input type=hidden name=id value=$r[id_kategori]>
          <table>
          <tr><td>Nama Kategori</td><td>     : <input type=text name='nama_kategori' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;' value='$r[nama_kategori]'></td></tr>
          <tr><td>Label</td><td>      : <input type=text name='label' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;' value='$r[label]'></td></tr>";
			if ($r['aktif']=='Y'){
			  echo "<tr><td>Aktif</td> <td> : <input type=radio name='aktif' value='Y' checked>Y  
											  <input type=radio name='aktif' value='N'> N</td></tr>";
			}
			else{
			  echo "<tr><td>Aktif</td> <td> : <input type=radio name='aktif' value='Y'>Y  
											  <input type=radio name='aktif' value='N' checked>N</td></tr>";
			}		  
          echo"<tr><td>Gambar</td><td>    : <img src='../static/foto_kategori/$r[icon]'></td></tr>
          <tr><td>Ganti Gbr</td><td> : <input type=file name='fupload' size=30> *)</td></tr>
          <tr><td colspan=2>*) Apabila gambar tidak diubah, dikosongkan saja.</td></tr>
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    break;  
}
}
?>
