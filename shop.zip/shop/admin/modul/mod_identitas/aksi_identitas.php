<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
	echo "<link href='style.css' rel='stylesheet' type='text/css'>
			<center>Untuk akses module, Anda harus login terlebih dahulu.<br>";
	echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";
include "../../../config/fungsi_seo.php";

$module	= $_GET['module'];
$act	= $_GET['act'];

// Update identitas
if ($module == 'identitas' AND $act == 'update'){
	$modified_date = date('Y-m-d H:i:s');
	
	mysqli_query($koneksi,"UPDATE identitas SET 				nama_website = '$_POST[nama_website]',
													url = '$_POST[url]',
													meta_deskripsi = '$_POST[meta_deskripsi]',
													meta_keyword = '$_POST[meta_keyword]',
													email = '$_POST[email]',
													rekening = '$_POST[rekening]',
													phone  = '$_POST[phone]',
													facebook = '$_POST[facebook]',
													twitter = '$_POST[twitter]',
													google = '$_POST[google]',
													modified_date = '$modified_date'
													WHERE id_identitas = '$_POST[id]'");
	}
	
	header('Location: ../../media.php?module='.$module);
}
?>