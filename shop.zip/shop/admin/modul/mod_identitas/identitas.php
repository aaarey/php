<?php
$aksi="modul/mod_identitas/aksi_identitas.php";

switch($_GET[act]){
	// Tampil identitas
	default:
	$sql = mysqli_query($koneksi,"SELECT * FROM identitas LIMIT 1");
	$r	 = mysqli_fetch_array($sql);
	?>


						<h2>Profil Admin</h2>
						<form method=POST enctype='multipart/form-data' action="<?php echo $aksi; ?>?module=identitas&act=update">
						<input type=hidden name=id value="<?php echo $r['id_identitas']; ?>">
						<table cellpadding="8" width="100%">
							<tr>
								<td width='130'>Nama Website</td>
								<td><input type=text name='nama_website' size='50' placeholder="Nama Website Anda" value="<?php echo $r['nama_website']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;"></td>
							</tr>
							<tr>
								<td>URL</td>
								<td><input type=text name='url' size='50' placeholder="URL Anda" value="<?php echo $r['url']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;"></td>
							</tr>
							<tr>
								<td>Facebook Fan Page</td>
								<td><input type=text name='facebook' size='50' placeholder="Facebook Fan Page Anda" value="<?php echo $r['facebook']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;">
								* Tanpa URL
								</td>
								
							</tr>
							<tr>
								<td>Twitter Fan Page</td>
								<td><input type=text name='twitter' size='50' placeholder="Facebook Fan Page Anda" value="<?php echo $r['twitter']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;">
								* Tanpa URL
								</td>
							</tr>	
							<tr>
								<td>Google Fan Page</td>
								<td><input type=text name='google' size='50' placeholder="Facebook Fan Page Anda" value="<?php echo $r['google']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;">
								* Tanpa URL
								</td>
							</tr>							
							<tr>
								<td>Meta Description</td>
								<td><input type=text name='meta_deskripsi' size='50' placeholder="Meta Description" value="<?php echo $r['meta_deskripsi']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 350px; margin-right: 10px; padding: 5px;"></td>
							</tr>
							<tr>
								<td>Meta Keyword</td>
								<td><input type=text name='meta_keyword' size='50' placeholder="Meta Keyword" value="<?php echo $r['meta_keyword']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 350px; margin-right: 10px; padding: 5px;"></td>
							</tr>
							<tr>
								<td>Email</td>
								<td><input type=text name='email' size='50' placeholder="Email Anda" value="<?php echo $r['email']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;"></td>
							</tr>
							<tr>
								<td>Rekening</td>
								<td><input type=text name='rekening' size='50' placeholder="Rekening Anda" value="<?php echo $r['rekening']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;"></td>
							</tr>		
							<tr>
								<td>Telp</td>
								<td><input type=text name='phone' size='50' placeholder="Telp Anda" value="<?php echo $r['phone']; ?>" style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;"></td>
							</tr>								
						</table>

						
         <tr><td colspan=2><input type=submit value=Update>
                           <input type=button value=Batal onclick=self.history.back()></td></tr>
					</form>

	<?php
	break;
}
?>