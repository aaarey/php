<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";

$module	= $_GET['module'];
$act=$_GET[act];

if ($module=='info' AND $act=='hapus'){
  mysqli_query($koneksi,"DELETE FROM informasi WHERE id_informasi='$_GET[id]'");
		header('Location: ../../media.php?module='.$module);
}

elseif ($module=='info' AND $act=='input'){
  mysqli_query($koneksi,"INSERT INTO informasi(judul, pesan, tanggal, created_userid) VALUES('$_POST[judul]','$_POST[pesan]','$tgl_sekarang','$_SESSION[useri]')");
		header('Location: ../../media.php?module='.$module);
}

elseif ($module=='info' AND $act=='update'){
	mysqli_query($koneksi,"UPDATE informasi SET judul = '$_POST[judul]', pesan='$_POST[pesan]', dibaca='$_POST[dibaca]',
				created_userid = '$_SESSION[useri]'
				WHERE id_informasi= '$_POST[id]'");
		header('Location: ../../media.php?module='.$module);

}
?>