<script language="javascript">
	function validasiinput(form){
		if (form.judul.value == ""){
			alert("Anda belum mengisikan Judul");
			form.judul.focus();
			return (false);
		}
	}
</script>


<?php
$aksi="modul/mod_info/aksi_info.php";
switch($_GET[act]){

  default:
	if($_SESSION['leveluser']=='admin'){
    echo "<h2>Informasi</h2>
          <input type=button value='Tambah Notifikasi' 
          onclick=\"window.location.href='?module=info&act=tambahinfo';\">";
	}
	echo"
			<table>
                <thead><tr>
				<th>#</th>	
				<th>Judul </th>		
				<th>Pengumuman </th>						
				<th></th><tbody>
		  </tr>"; 
		  
    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);		  
		  
    $tampil=mysqli_query($koneksi,"SELECT * FROM informasi ORDER BY id_informasi DESC LIMIT $posisi,$batas");
    $no = $posisi+1;
    while ($r=mysqli_fetch_array($tampil)){
	if($r[dibaca]=='N'){
	?>
       <tr><td><b><?php echo $no; ?> </b></td>
             <td><b><?php echo $r[judul]; ?></b></td>	 			 
             <td><b><?php echo $r[pesan]; ?></b></td>			  
			<?php if($_SESSION['leveluser']=='admin'){
			 echo"<td><a href='?module=info&act=editinfo&id=$r[id_informasi]'><i class='icon-pencil'></i> Edit</a> |
				<a href='$aksi?module=info&act=hapus&id=$r[id_informasi]'  onClick='return confirm('Apakah Anda benar-benar mau menghapusnya $r[judul]?');'>
								<i class='icon-remove'></i> Hapus</a>
             </td></tr>";
			}
			else{
			 echo"<td><a href='?module=info&act=lihatinfo&id=$r[id_informasi]'><i class='icon-play-circle big'></i></a></td></tr>";			
			}
			?>
	<?php
	}
	else{
		echo"
       <tr><td> $no</td>
             <td>$r[judul]</td>	 			 
             <td>$r[pesan]</td>";
			?> <?php if($_SESSION['leveluser']=='admin'){
			echo"<td><a href='?module=info&act=editinfo&id=$r[id_informasi]'><i class='icon-pencil'></i> Edit</a> |
				<a href='$aksi?module=info&act=hapus&id=$r[id_informasi]'  onClick='return confirm('Apakah Anda benar-benar mau menghapusnya $r[judul]?');'>
								<i class='icon-remove'></i> Hapus</a>
             </td></tr>";
			}
			else{
			echo"<td><a href='?module=info&act=lihatinfo&id=$r[id_informasi]'><i class='icon-pencil'></i> Edit</a></td></tr>";	
			 } ?>
			<?php
	}
	
		$no++;
}
	
	
    echo "</tbody></table>";
	
    $jmldata = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM informasi"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";	
	
    break;
  
  case "tambahinfo":
    echo "<h2>Tambah Notifikasi</h2>
          <form method=POST action='$aksi?module=info&act=input' onSubmit=\"return validasiinput(this)\">
          <table>
			<tr><td>Judul</td><td> : <input type=text name='judul' size=60></td></tr>
			<tr><td>Pesan</td><td> : <textarea name='pesan' style='width: 420px; height: 150px;'></textarea></td></tr>			
			<tr><td colspan=2><input type=submit name=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;

  case "editinfo":
    $edit=mysqli_query($koneksi,"SELECT * FROM informasi WHERE id_informasi='$_GET[id]'");
    $r=mysqli_fetch_array($edit);
	if ($r['dibaca'] == 'N'){
		$checka = 'checked';
	}	
	elseif ($r['dibaca'] == 'Y'){
		$checkb = 'checked';
	}
	else{
		$checka = '';
		$checkb = '';
	}	
	mysqli_query($koneksi,"UPDATE informasi SET dibaca='Y' WHERE id_informasi='$_GET[id]'");		
    echo "<h2>Edit Notifikasi</h2>
          <form method=POST action=$aksi?module=info&act=update>
          <input type=hidden name=id value='$r[id_informasi]'>
		  <table>
			<tr><td>Judul</td><td> : <input type=text name='judul' value='$r[judul]' size=60></td></tr>
			<tr><td>Pesan</td><td> 
			<textarea name='pesan' style='width: 420px; height: 150px;'>$r[pesan]</textarea>	</td></tr>		
			<tr><td>Ket</td><td> 
			<input type=radio name='dibaca' value='N' $checka>Tidak Dibaca
			<input type=radio name='dibaca' value='Y' $checkb>Dibaca</td></tr>				
			<tr><td colspan=2><input type=submit name=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </form></table>";
    break;  

  case "lihatinfo":
    $edit=mysqli_query($koneksi,"SELECT * FROM informasi WHERE id_informasi='$_GET[id]'");
    $r=mysqli_fetch_array($edit);
	mysqli_query($koneksi,"UPDATE informasi SET dibaca='Y' WHERE id_informasi='$_GET[id]'");		
    echo "<div class='well'>
			<table class='table'>
				<tr> 
					<td>Judul</td>
					<td>$r[judul]</td>
				</tr>
				<tr> 
					<td>Pesan</td>
					<td>$r[pesan]</td>
				</tr>
				</table></div>";
    break;  	
}
?>
