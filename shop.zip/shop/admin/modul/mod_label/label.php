<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_label/aksi_label.php";
switch($_GET[act]){
  // Tampil 
  default:
    echo "<h2>Label Menu Footer</h2>
          <input type=button value='Tambah' 
          onclick=\"window.location.href='?module=label&act=tambahlabel';\">
          <table>
          <tr><th>no</th>
		  <th>Title</th>
		  <th>Menu</th>
		  <th>Aksi</th>
		  </tr>"; 
	$p      = new Paging;
    $batas  = 15;
    $posisi = $p->cariPosisi($batas);	  
   
   $tampil=mysqli_query($koneksi,"SELECT title,ket FROM label ORDER BY id_label DESC LIMIT $posisi,$batas");
	$no=$posisi+1;
    while ($r=mysqli_fetch_array($tampil)){	
	if($r['ket'] == 'Penggunaan'){$ket = 'Aturan Penggunaan';}
	elseif($r['ket'] == 'Privasi'){$ket = 'Kebijakan Privasi';}
	elseif($r['ket'] == 'Pembayaran'){$ket = 'Pembayaran';}
	elseif($r['ket'] == 'Pembelian'){$ket = 'Pembelian';}
	elseif($r['ket'] == 'Berbelanja'){$ket = 'Tips Berbelanja';}
	elseif($r['ket'] == 'Berjualan'){$ket = 'Cara Berjualan';}	
	else{$ket = 'FAQ';}
       echo "<tr><td>$no</td>
			 <td>$r[title]</td>
             <td>$ket</td>
             <td>
	               <a href=$aksi?module=label&act=hapus&id=$r[id_label] onClick=\"return confirm('Apakah Anda benar-benar mau menghapusnya?')\">Hapus</a>
             </td></tr>";
      $no++;
    }
    echo "</table>";
    $jmldata=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM label"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    echo "<div id=paging>$linkHalaman</div><br>";    	
    break;
  
  // Form Tambah Ongkos Kirim
  case "tambahlabel":
    echo "<h2>Tambah </h2>
          <form method=POST action='$aksi?module=label&act=input'>
         <table cellpadding='8' width='100%'>
			<tr><td>Keterangan Menu</td>  <td> : 
			<select name='ket' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'>
				<option value=0 selected>- Pilih Keterangan -</option>
				<option value='Penggunaan' name='ket'>Aturan Penggunaan</option>
				<option value='Privasi' name='ket'>Kebijakan Privasi</option>
				<option value='Pembayaran' name='ket'>Pembayaran</option>
				<option value='Pembelian' name='ket'>Pembelian</option>
				<option value='Berbelanja' name='ket'>Tips Berbelanja</option>
				<option value='Berjualan' name='ket'>Cara Berjualan</option>
				<option value='FAQ' name='ket'>FAQ</option>				
			</select>
          <tr><td>Title</td><td> : <input type=text name='title' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>		  	  
          <tr><td>Deskripsi</td>  <td> <textarea name='deskripsi' class='ckeditor' style='width: 580px; height: 350px;'></textarea></td></tr>
          <tr><td colspan=2><input type=submit name=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;
  
  // Form Edit Ongkos Kirim
  case "editlabel":
    $edit=mysqli_query($koneksi,"SELECT * FROM label
								WHERE id_label='$_GET[id]'");
    $r=mysqli_fetch_array($edit);

    echo "<h2>Edit</h2>
          <form method=POST action=$aksi?module=label&act=update>
          <input type=hidden name=id value='$r[id_label]'>
         <table cellpadding='8' width='100%'>
    							<tr>
    								<td>Pengiriman</td>";
									?>
    								<td><select name='ket' style="background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;">
    										<option value="0">Pilih Pengiriman</option>
											<option value="Penggunaan" <?php if($r['ket']=="Penggunaan"){echo "selected";} ?>>Aturan Penggunaan</option>
											<option value="Privasi" <?php if($r['ket']=="Privasi"){echo "selected";} ?>>Kebijakan Privasi</option>
											<option value="Pembayaran" <?php if($r['ket']=="Pembayaran"){echo "selected";} ?>>Pembayaran</option>
											<option value="Pembelian" <?php if($r['ket']=="Pembelian"){echo "selected";} ?>>Pembelian</option>
											<option value="Berbelanja" <?php if($r['ket']=="Berbelanja"){echo "selected";} ?>>Tips Berbelanja</option>
											<option value="Berjualan" <?php if($r['ket']=="Berjualan"){echo "selected";} ?>>Cara Berjualan</option>	
											<option value="FAQ" <?php if($r['ket']=="FAQ"){echo "selected";} ?>>FAQ</option>												
    									</select>
    								</td>
    							</tr>		  
		  <?php
          echo"
		  <tr><td>Title</td><td>  <input type=text name='title' value='$r[title]' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 25px; width: 266px; margin-right: 10px; padding: 5px;'></td></tr>		  
          <tr><td>Deskripsi</td>   <td> <textarea name='deskripsi' class='ckeditor'>$r[deskripsi]</textarea></td></tr>		  	  
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    break;  
}
}
?>
