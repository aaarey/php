<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus 
if ($module=='label' AND $act=='hapus'){
  mysqli_query($koneksi,"DELETE FROM label WHERE id_label='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input
elseif ($module=='label' AND $act=='input'){
  mysqli_query($koneksi,"INSERT INTO label(title,deskripsi,ket) 
				VALUES('$_POST[title]','$_POST[deskripsi]','$_POST[ket]')");
  header('location:../../media.php?module='.$module);
}

// Update 
elseif ($module=='label' AND $act=='update'){
  mysqli_query($koneksi,"UPDATE label SET title = '$_POST[title]', 
								deskripsi = '$_POST[deskripsi]', 
								ket='$_POST[ket]'
  WHERE id_label = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
}
}
?>
