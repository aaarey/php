<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_iklan/aksi_iklan.php";
switch($_GET[act]){
  // Tampil Iklan
  default:
    echo "<h2>Iklan</h2>
          <input type=button value='Tambah Iklan' onclick=location.href='?module=iklan&act=tambahiklan'>
          <table>
          <tr><th>no</th><th>judul</th><th>url</th><th>aktif</th><th>aksi</th></tr>";
    $tampil=mysqli_query($koneksi,"SELECT * FROM iklan ORDER BY id_iklan DESC");
    $no=1;
    while ($r=mysqli_fetch_array($tampil)){
      $tgl=tgl_indo($r[tanggal]);
      echo "<tr><td>$no</td>
                <td>$r[judul]</td>
                <td><a href=$r[url] target=_blank>$r[url]</a></td>
                <td>$r[aktif]</td>
                <td><a href=?module=iklan&act=editiklan&id=$r[id_iklan]>Edit</a> | 
	                  <a href='$aksi?module=iklan&act=hapus&id=$r[id_iklan]&namafile=$r[gambar]'>Hapus</a>
		        </tr>";
    $no++;
    }
    echo "</table>";
    break;
  
  case "tambahiklan":
    echo "<h2>Tambah Iklan</h2>
          <form method=POST action='$aksi?module=iklan&act=input' enctype='multipart/form-data'>
          <table>
          <tr><td>Judul</td><td>  : <input type=text name='judul' size=30></td></tr>
          <tr><td>Url</td><td>   : <input type=text name='url' size=50 value='http://'></td></tr>
          <tr><td>Aktif</td>      <td> : <input type=radio name='aktif' value='Y' checked>Y 
                                         <input type=radio name='aktif' value='N'>N  </td></tr>		  
          <tr><td>Gambar</td><td> : <input type=file name='fupload' size=40></td></tr>
          <tr><td colspan=2><input type=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form><br><br><br>";
     break;
    
  case "editiklan":
    $edit = mysqli_query($koneksi,"SELECT * FROM iklan WHERE id_iklan='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Iklan</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=iklan&act=update>
          <input type=hidden name=id value=$r[id_iklan]>
          <table>
          <tr><td>Judul</td><td>     : <input type=text name='judul' size=30 value='$r[judul]'></td></tr>
          <tr><td>Url</td><td>      : <input type=text name='url' size=50 value='$r[url]'></td></tr>";
			if ($r[aktif]=='Y'){
			  echo "<tr><td>Aktif</td> <td> : <input type=radio name='aktif' value='Y' checked>Y  
											  <input type=radio name='aktif' value='N'> N</td></tr>";
			}
			else{
			  echo "<tr><td>Aktif</td> <td> : <input type=radio name='aktif' value='Y'>Y  
											  <input type=radio name='aktif' value='N' checked>N</td></tr>";
			}		  
          echo"<tr><td>Gambar</td><td>    : <img src='../foto_iklan/$r[gambar]'></td></tr>
          <tr><td>Ganti Gbr</td><td> : <input type=file name='fupload' size=30> *)</td></tr>
          <tr><td colspan=2>*) Apabila gambar tidak diubah, dikosongkan saja.</td></tr>
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    break;  
}
}
?>
