<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus iklan
if ($module=='iklan' AND $act=='hapus'){
  $data=mysqli_fetch_array(mysqli_query($koneksi,"SELECT gambar FROM iklan WHERE id_iklan='$_GET[id]'"));
  if ($data['gambar']!=''){
     mysqli_query($koneksi,"DELETE FROM iklan WHERE id_iklan='$_GET[id]'");
     unlink("../../../foto_iklan/$_GET[namafile]");   
  }
  else{
    mysqli_query($koneksi,"DELETE FROM iklan WHERE id_iklan='$_GET[id]'");
  }
  header('location:../../media.php?module='.$module);
}

// Input iklan
elseif ($module=='iklan' AND $act=='input'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];
  $tipe_file   = $_FILES['fupload']['type'];

  // Apabila ada gambar yang diupload
  if (!empty($lokasi_file)){
    if ($tipe_file != "image/jpeg" AND $tipe_file != "image/pjpeg"){
    echo "<script>window.alert('Upload Gagal, Pastikan File yang di Upload bertipe *.JPG');
        window.location=('../../media.php?module=iklan)</script>";
    }
    else{
    UploadIklan($nama_file);
    mysqli_query($koneksi,"INSERT INTO iklan(judul,
                                    url,
                                    tanggal,
									aktif,
                                    gambar) 
                            VALUES('$_POST[judul]',
                                   '$_POST[url]',
                                   '$tgl_sekarang',
								   '$_POST[aktif]',
                                   '$nama_file')");
  header('location:../../media.php?module='.$module);
  }
  }
  else{
    mysqli_query($koneksi,"INSERT INTO iklan(judul,
                                    tanggal,
									aktif,
                                    url) 
                            VALUES('$_POST[judul]',
                                   '$tgl_sekarang',
								   '$_POST[aktif]',
                                   '$_POST[url]')");
  header('location:../../media.php?module='.$module);
  }
}

// Update iklan
elseif ($module=='iklan' AND $act=='update'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];
  $tipe_file   = $_FILES['fupload']['type'];

  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($koneksi,"UPDATE iklan SET judul     = '$_POST[judul]',
									aktif	=  '$_POST[aktif]',
                                   url       = '$_POST[url]'
                             WHERE id_iklan = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
  }
  else{
    if ($tipe_file != "image/jpeg" AND $tipe_file != "image/pjpeg"){
    echo "<script>window.alert('Upload Gagal, Pastikan File yang di Upload bertipe *.JPG');
        window.location=('../../media.php?module=iklan)</script>";
    }
    else{
    UploadIklan($nama_file);
    mysqli_query($koneksi,"UPDATE iklan SET judul     = '$_POST[judul]',
								   aktif	= '$_POST[aktif]',
                                   url       = '$_POST[url]',
                                   gambar    = '$nama_file'   
                             WHERE id_iklan = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
  }
  }
}
}
?>
