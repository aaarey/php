-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 28 Jul 2017 pada 14.41
-- Versi Server: 5.6.14
-- Versi PHP: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `dbtoko`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `id_about` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `icon` varchar(100) NOT NULL,
  PRIMARY KEY (`id_about`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `about`
--

INSERT INTO `about` (`id_about`, `title`, `deskripsi`, `icon`) VALUES
(1, 'Tentang Kami', '<p>Kita tahu bahwa dunia teknologi informasi sangatlah kompleks dan berkembang secara pesat dari waktu ke waktu. Menurut data survey, saat ini tercatat lebih dari 40 juta pengguna internet secara aktif di seluruh dunia, ini merupakan peluang baik bagi Anda dalam meluaskan jaringan dan bisnis. oleh karena alasan tersebut, kami hadir sebagai perusahaan layanan web dan konsultan IT.</p>', '20170422053600_application-development.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id_users` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `no_telp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `level` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  `blokir` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id_users`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `admins`
--

INSERT INTO `admins` (`id_users`, `username`, `password`, `nama_lengkap`, `email`, `no_telp`, `level`, `blokir`) VALUES
(2, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', 'admin@gmail.com', '08728929', 'admin', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `as_provinces`
--

CREATE TABLE IF NOT EXISTS `as_provinces` (
  `province_id` int(11) NOT NULL AUTO_INCREMENT,
  `province_name` varchar(100) NOT NULL,
  `status` char(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `created_userid` int(11) NOT NULL,
  `modified_date` datetime NOT NULL,
  `modified_userid` int(11) NOT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data untuk tabel `as_provinces`
--

INSERT INTO `as_provinces` (`province_id`, `province_name`, `status`, `created_date`, `created_userid`, `modified_date`, `modified_userid`) VALUES
(1, 'Sumatra Selatan', 'Y', '2013-11-11 00:00:00', 1, '2014-05-07 04:44:15', 1),
(2, 'Sumatra Barat', 'Y', '2013-11-11 00:00:00', 1, '2014-05-07 04:44:03', 1),
(3, 'Sumatra Utara', 'Y', '2013-11-11 00:00:00', 1, '2014-05-07 04:43:52', 1),
(4, 'Kalimantan Selatan', 'Y', '2013-11-11 00:00:00', 1, '2014-05-07 04:43:35', 1),
(5, 'Kalimantan Tengah', '', '2013-11-11 00:00:00', 1, '2014-05-07 04:43:22', 1),
(6, 'Kalimantan Barat', 'Y', '2013-11-11 00:00:00', 1, '2014-05-07 04:43:10', 1),
(7, 'Gorontalo', 'Y', '2014-02-04 19:42:50', 1, '2014-05-07 04:50:16', 1),
(8, 'Sulawesi Utara', 'Y', '2014-02-04 19:43:14', 1, '2014-05-07 04:50:07', 1),
(9, 'DKI Jakarta', 'Y', '2014-02-04 19:43:31', 1, '2014-05-07 04:42:37', 1),
(10, 'DIY', 'Y', '2014-02-04 19:43:47', 1, '2014-05-07 04:42:29', 1),
(11, 'Banten', 'Y', '2014-02-04 19:44:02', 1, '2014-05-07 04:42:22', 1),
(12, 'Bengkulu', 'Y', '2014-02-04 19:44:18', 1, '2014-05-07 04:42:15', 1),
(13, 'Bali', 'Y', '2014-02-04 19:44:37', 1, '2014-05-07 04:40:52', 1),
(14, 'Jawa Timur', 'Y', '2014-02-04 19:44:55', 1, '2014-05-07 04:40:47', 1),
(15, 'Jawa Tengah', 'Y', '2014-02-04 19:45:37', 1, '2014-05-07 04:40:40', 1),
(16, 'Jawa Barat', 'Y', '2014-02-04 19:45:52', 1, '2014-05-07 04:40:28', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `cat_news`
--

CREATE TABLE IF NOT EXISTS `cat_news` (
  `id_cat_news` int(5) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(50) NOT NULL,
  `cat_seo` varchar(50) NOT NULL,
  `aktif` char(1) NOT NULL,
  PRIMARY KEY (`id_cat_news`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `cat_news`
--

INSERT INTO `cat_news` (`id_cat_news`, `cat_name`, `cat_seo`, `aktif`) VALUES
(1, 'Teknologi', 'teknologi', '1'),
(2, 'Teknologi', 'teknologi', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `id_faq` int(11) NOT NULL AUTO_INCREMENT,
  `ket` int(11) NOT NULL,
  PRIMARY KEY (`id_faq`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `favorit`
--

CREATE TABLE IF NOT EXISTS `favorit` (
  `id_favorit` int(5) NOT NULL AUTO_INCREMENT,
  `id_kustomer` int(5) NOT NULL,
  `id_produk` int(5) NOT NULL,
  PRIMARY KEY (`id_favorit`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `favorit`
--

INSERT INTO `favorit` (`id_favorit`, `id_kustomer`, `id_produk`) VALUES
(1, 44, 169),
(2, 51, 169);

-- --------------------------------------------------------

--
-- Struktur dari tabel `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id_group` int(5) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL,
  `group_seo` varchar(50) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `status` char(1) NOT NULL,
  `label` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `created_userid` int(5) NOT NULL,
  PRIMARY KEY (`id_group`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `groups`
--

INSERT INTO `groups` (`id_group`, `group_name`, `group_seo`, `icon`, `status`, `label`, `created_date`, `created_userid`) VALUES
(1, 'Fashion', 'fashion', 'fashion.png', 'Y', 'Laki-laki, Perempuan', '2017-03-09 00:00:00', 1),
(2, 'Handphone', 'handphone', 'smartphone.png', 'Y', 'Hp, Tablet', '2017-03-10 00:00:00', 1),
(3, 'Komputer', 'komputer', 'laptop.png', 'Y', 'PC, Laptop, Printer', '2017-03-09 00:00:00', 1),
(4, 'Kamera', 'kamera', 'camera.png', 'Y', 'Kamera', '2017-03-08 00:00:00', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `hubungi`
--

CREATE TABLE IF NOT EXISTS `hubungi` (
  `id_hubungi` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `subjek` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `bantuan` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `deskripsi` text COLLATE latin1_general_ci NOT NULL,
  `tanggal` datetime NOT NULL,
  PRIMARY KEY (`id_hubungi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=25 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `identitas`
--

CREATE TABLE IF NOT EXISTS `identitas` (
  `id_identitas` int(5) NOT NULL AUTO_INCREMENT,
  `nama_website` varchar(100) NOT NULL,
  `url` varchar(30) NOT NULL,
  `meta_deskripsi` varchar(250) NOT NULL,
  `meta_keyword` varchar(250) NOT NULL,
  `email` varchar(50) NOT NULL,
  `rekening` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  `google` varchar(100) NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id_identitas`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `identitas`
--

INSERT INTO `identitas` (`id_identitas`, `nama_website`, `url`, `meta_deskripsi`, `meta_keyword`, `email`, `rekening`, `phone`, `facebook`, `twitter`, `google`, `modified_date`) VALUES
(2, 'E-Lapak - Marketplace Online', 'http://e-lapak.com/home', 'e-lapak.com adalah situs jual beli online terbesar di Indonesia', 'e-lapak.com adalah situs jual beli online terbesar di Indonesia', 'admin@e-lapak.com', 'BNI - 191091001', '08562232441', 'elapak', 'elapak', 'elapak', '2017-05-31 06:23:02');

-- --------------------------------------------------------

--
-- Struktur dari tabel `informasi`
--

CREATE TABLE IF NOT EXISTS `informasi` (
  `id_informasi` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) NOT NULL,
  `pesan` text NOT NULL,
  `tanggal` date NOT NULL,
  `dibaca` char(1) NOT NULL DEFAULT 'N',
  `created_userid` int(1) NOT NULL,
  PRIMARY KEY (`id_informasi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `informasi`
--

INSERT INTO `informasi` (`id_informasi`, `judul`, `pesan`, `tanggal`, `dibaca`, `created_userid`) VALUES
(1, 'Test', 'Ok test', '2017-04-10', 'Y', 2),
(2, 'Berita', 'Berita', '2017-07-09', 'Y', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(5) NOT NULL AUTO_INCREMENT,
  `id_group` int(5) NOT NULL,
  `nama_kategori` varchar(30) NOT NULL,
  `kategori_seo` varchar(30) NOT NULL,
  `aktif` char(1) NOT NULL,
  `label` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `created_userid` int(1) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `id_group`, `nama_kategori`, `kategori_seo`, `aktif`, `label`, `icon`, `created_date`, `created_userid`) VALUES
(35, 1, 'Fashion', 'fashion', 'Y', 'Laki-laki, Perempuan', 'fashion.png', '0000-00-00 00:00:00', 0),
(31, 1, 'Handphone', 'handphone', 'Y', 'smartphone, tablet, dll', 'smartphone.png', '0000-00-00 00:00:00', 0),
(32, 2, 'Komputer', 'komputer', 'Y', 'PC, Laptop, Printer', 'laptop.png', '0000-00-00 00:00:00', 0),
(33, 2, 'Kamera', 'kamera', 'Y', 'Kamera, Aksesoris', 'camera.png', '0000-00-00 00:00:00', 0),
(34, 3, 'Elektronik', 'elektronik', 'Y', 'Elektronik', 'tv.png', '0000-00-00 00:00:00', 0),
(36, 3, 'Hobi & Koleksi', 'hobby', 'Y', 'buku & koleksi', 'koleksi.png', '0000-00-00 00:00:00', 0),
(37, 4, 'Olahraga', 'olarga', 'Y', 'semua olahraga', 'sport.png', '0000-00-00 00:00:00', 0),
(38, 4, 'Sepeda', 'Semua sepeda', 'Y', 'sepeda', 'sepeda.png', '0000-00-00 00:00:00', 0),
(39, 4, 'Motor', 'Motor', 'Y', 'Semua motor', 'motor.png', '0000-00-00 00:00:00', 0),
(40, 3, 'Mobil', 'mobil', 'Y', 'Semua mobil', 'mobil.png', '0000-00-00 00:00:00', 0),
(41, 3, 'Kantor & Industri', 'industri', 'Y', 'Industri', 'office.png', '0000-00-00 00:00:00', 0),
(42, 2, 'Kesehatan', 'kesehatan', 'Y', 'Obat & Kesehatan', 'obat.png', '0000-00-00 00:00:00', 0),
(43, 2, 'Peralatan Anak', 'peralatan-anak', 'Y', 'Perabot anak & bayi', 'bayi.png', '0000-00-00 00:00:00', 0),
(44, 2, 'Rumah Tangga', 'rumah-tangga', 'Y', 'Peralatan rumah tangga', 'rumah.png', '0000-00-00 00:00:00', 0),
(45, 1, 'Musik', 'musik', 'Y', 'Musik', 'musik.png', '0000-00-00 00:00:00', 0),
(46, 1, 'sdfs', 'sdfs', 'Y', 'rumah & property', 'gedung.png', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kota`
--

CREATE TABLE IF NOT EXISTS `kota` (
  `id_kota` int(3) NOT NULL AUTO_INCREMENT,
  `id_perusahaan` int(10) NOT NULL,
  `nama_kota` varchar(100) NOT NULL,
  `kota_tujuan` varchar(50) NOT NULL,
  `ongkos_kirim` int(10) NOT NULL,
  `lama` varchar(50) NOT NULL,
  PRIMARY KEY (`id_kota`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data untuk tabel `kota`
--

INSERT INTO `kota` (`id_kota`, `id_perusahaan`, `nama_kota`, `kota_tujuan`, `ongkos_kirim`, `lama`) VALUES
(47, 6, 'DKI Jakarta', 'Tangerang', 50000, '3-4'),
(48, 6, 'Bandung', 'Bandung Kota', 50000, '3-4'),
(49, 6, 'Semarang', 'Ungaran', 55000, '3-4'),
(50, 6, 'Yogyakarta', 'Sleman', 55000, '3-4'),
(51, 6, 'Surabaya', 'Kecamatan Surabaya', 60000, '3-4');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kustomer`
--

CREATE TABLE IF NOT EXISTS `kustomer` (
  `id_kustomer` int(5) NOT NULL AUTO_INCREMENT,
  `password` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `alamat` text COLLATE latin1_general_ci NOT NULL,
  `daerah` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `hp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `id_kota` int(5) NOT NULL,
  `kelamin` char(1) COLLATE latin1_general_ci NOT NULL,
  `verification_code` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `tanggal` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `ktp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `slogan` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `last_login` datetime NOT NULL,
  `photo` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `status` char(1) COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `rekening` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`id_kustomer`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=52 ;

--
-- Dumping data untuk tabel `kustomer`
--

INSERT INTO `kustomer` (`id_kustomer`, `password`, `username`, `nama_lengkap`, `alamat`, `daerah`, `email`, `hp`, `id_kota`, `kelamin`, `verification_code`, `tanggal`, `ktp`, `slogan`, `last_login`, `photo`, `status`, `rekening`, `created_date`) VALUES
(44, '827ccb0eea8a706c4c34a16891f84e7b', 'agus', 'Ahmad Fulan', '<p>Bandung Selatan</p>', 'Bandung Selatan', 'fulan@gmail.com', '08135674874', 48, 'L', '0', '04 Maret 2004', '10100100', 'Semangat', '2017-07-28 14:37:10', 'fulan@gmail.com_20170410052316_John Burns.jpg', 'Y', '', '2017-02-14 04:00:00'),
(46, 'e10adc3949ba59abbe56e057f20f883e', 'putri', 'Putri Latifah', '<p>Bandung Kota</p>', 'Bandung', 'putri@gmail.com', '08168728890', 48, 'P', 'NoJ3E7PNkK', '', '1019029243', 'Ok', '2017-07-28 14:32:15', 'putri@gmail.com_20170531060827_6.jpg', 'Y', '12134243434', '2017-03-20 09:04:37'),
(47, '827ccb0eea8a706c4c34a16891f84e7b', 'rudi', 'Rudiansyah', '<p>Semarang</p>', 'Semarang Kota', 'rudi@gmail.com', '0877829920', 49, 'L', 'T64LVy1OTv', '', '101001012123', 'OK', '2017-07-09 06:44:06', 'rudi@gmail.com_20170420071837_5.jpg', 'Y', '1212121212', '2017-04-10 05:46:54'),
(50, '827ccb0eea8a706c4c34a16891f84e7b', 'ana', 'Ana Fitriana', '<p>JL. Anggrek No. 12A Kav. 12 Tangerang</p>', 'Jakarta', 'ana@gmail.com', '08776572883', 47, 'P', '', '', '910180081', 'ok', '2017-06-02 09:21:18', 'ana@gmail.com_20170602043149_1.jpg', 'Y', '121212', '2017-06-02 04:19:24'),
(51, '827ccb0eea8a706c4c34a16891f84e7b', 'edi', 'Edi Samsuri', '<p>Jakarta</p>', 'Jakarta', 'edi@gmail.com', '089655656', 47, 'L', 'GQ7hgfArio', '', '1234223424', 'OK', '2017-07-11 15:25:05', 'edi@gmail.com_20170709053220_7.jpg', 'Y', '12212134', '2017-07-09 04:01:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `label`
--

CREATE TABLE IF NOT EXISTS `label` (
  `id_label` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `ket` varchar(20) NOT NULL,
  PRIMARY KEY (`id_label`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `label`
--

INSERT INTO `label` (`id_label`, `title`, `deskripsi`, `ket`) VALUES
(1, 'Aturan Penggunaan', '<p>Aturan Penggunaan 1</p>', 'Penggunaan'),
(2, 'Aturan dan Privasi', '<p>Kebijakan Privasi 1</p>', 'Privasi'),
(3, 'Privasi kedua', '<p>Ini adalah privasi 2</p>', 'Privasi'),
(4, 'Tips Berbelanja', '<p>Ini adalah tips berbelanja</p>', 'Berbelanja'),
(5, 'Langkah Menjadi Smart Buyer', '<ol><li>Tentukan Barang yang Ingin Dibeli</li><li>Bandingkan Harga.</li><li>Tanyakan Stok Barang ke Pelapak.</li></ol>', 'Berbelanja'),
(6, 'Cara Berjualan', '<p>Ini adalah cara berjualan</p>', 'Berjualan'),
(7, 'Apakah M-Direct menjual barang?', '<ol><li>M-Direct adalah aplikasi jual beli online yang menghubungkan jutaan pembeli dan pelapak di seluruh Indonesia.</li><li>M-Direct tidak menjual/menyediakan barang/produk, melainkan hanya sebagai perantara.</li></ol>', 'FAQ'),
(8, 'Apakah ada syarat untuk membuat akun di M-Directs?', '<ol><li><p>Pastikan kamu membuat akun di M-Direct dengan email dan nomor handphone yang aktif untuk mempermudah transaksi. &nbsp;&nbsp;&nbsp;</p></li></ol>', 'FAQ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id_news` int(5) NOT NULL AUTO_INCREMENT,
  `id_cat_news` int(5) NOT NULL,
  `title` varchar(100) NOT NULL,
  `title_seo` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL,
  `aktif` char(1) NOT NULL,
  `post_day` varchar(20) NOT NULL,
  `post_date` date NOT NULL,
  `post_hour` time NOT NULL,
  `image` varchar(100) NOT NULL,
  `created_userid` int(1) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`id_news`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `news`
--

INSERT INTO `news` (`id_news`, `id_cat_news`, `title`, `title_seo`, `deskripsi`, `aktif`, `post_day`, `post_date`, `post_hour`, `image`, `created_userid`, `created_date`) VALUES
(1, 1, 'Teknologi Smartphone', 'teknologi-smartphone', 'Ini adalah teknologi smartphone', 'Y', 'Senin', '2017-03-08', '00:51:08', '20140423115354_festival_wine.jpg', 1, '2017-03-08 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id_orders` int(5) NOT NULL AUTO_INCREMENT,
  `id_produk` int(5) NOT NULL,
  `akun` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `status_order` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'Pending',
  `tgl_order` date NOT NULL,
  `jam_order` datetime NOT NULL,
  `id_kustomer` int(5) NOT NULL,
  `penjual` int(5) NOT NULL,
  `akun_bank` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `biaya` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `tanggal` datetime NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `pending` char(1) COLLATE latin1_general_ci NOT NULL,
  `konfirmasi` char(1) COLLATE latin1_general_ci NOT NULL,
  `dibayar` char(1) COLLATE latin1_general_ci NOT NULL,
  `dikirim` char(1) COLLATE latin1_general_ci NOT NULL,
  `diterima` char(1) COLLATE latin1_general_ci NOT NULL,
  `catatan` text COLLATE latin1_general_ci NOT NULL,
  `ditolak` char(1) COLLATE latin1_general_ci NOT NULL,
  `rate` int(11) NOT NULL,
  PRIMARY KEY (`id_orders`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=239 ;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`id_orders`, `id_produk`, `akun`, `status_order`, `tgl_order`, `jam_order`, `id_kustomer`, `penjual`, `akun_bank`, `biaya`, `tanggal`, `gambar`, `pending`, `konfirmasi`, `dibayar`, `dikirim`, `diterima`, `catatan`, `ditolak`, `rate`) VALUES
(234, 169, '4420170531065258', 'Pending', '2017-05-31', '2017-05-31 18:52:58', 44, 0, '', '', '0000-00-00 00:00:00', '', '1', '', '', '', '', '', '', 0),
(235, 174, '5120170709055938', 'Dikirim', '2017-07-09', '2017-07-09 05:59:38', 51, 0, '', '', '0000-00-00 00:00:00', '', '1', '', '1', '1', '', '', '', 0),
(236, 174, '4620170709063128', 'Dikirim', '2017-07-09', '2017-07-09 06:31:28', 46, 0, '', '', '0000-00-00 00:00:00', '', '1', '', '1', '1', '', '', '', 0),
(237, 174, '4720170709064415', 'Pending', '2017-07-09', '2017-07-09 06:44:15', 47, 0, '', '', '0000-00-00 00:00:00', '', '1', '', '', '', '', '', '', 0),
(238, 169, '5120170711030517', 'Pending', '2017-07-11', '2017-07-11 15:05:17', 51, 0, '', '', '0000-00-00 00:00:00', '', '1', '', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders_detail`
--

CREATE TABLE IF NOT EXISTS `orders_detail` (
  `id_orders` int(5) NOT NULL,
  `id_produk` int(5) NOT NULL,
  `jumlah` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `orders_detail`
--

INSERT INTO `orders_detail` (`id_orders`, `id_produk`, `jumlah`) VALUES
(234, 169, 1),
(235, 174, 1),
(236, 174, 1),
(237, 174, 1),
(238, 169, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders_temp`
--

CREATE TABLE IF NOT EXISTS `orders_temp` (
  `id_orders_temp` int(5) NOT NULL AUTO_INCREMENT,
  `id_produk` int(5) NOT NULL,
  `id_session` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `jumlah` int(5) NOT NULL,
  `tgl_order_temp` date NOT NULL,
  `jam_order_temp` time NOT NULL,
  `stok_temp` int(5) NOT NULL,
  `status` char(1) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_orders_temp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=470 ;

--
-- Dumping data untuk tabel `orders_temp`
--

INSERT INTO `orders_temp` (`id_orders_temp`, `id_produk`, `id_session`, `jumlah`, `tgl_order_temp`, `jam_order_temp`, `stok_temp`, `status`) VALUES
(469, 169, 'edi@gmail.com', 1, '2017-07-11', '15:05:13', 5, '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE IF NOT EXISTS `produk` (
  `id_produk` int(5) NOT NULL AUTO_INCREMENT,
  `ref_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `id_kategori` int(5) NOT NULL,
  `id_kustomer` int(1) NOT NULL,
  `nama_produk` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `kondisi` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `produk_seo` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `deskripsi` text COLLATE latin1_general_ci NOT NULL,
  `infoproduk` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `harga` int(20) NOT NULL,
  `stok` int(5) NOT NULL,
  `berat` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `tgl_masuk` datetime NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `gambar2` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `gambar3` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `gambar4` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `gambar5` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `gambar6` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `dibeli` int(5) NOT NULL DEFAULT '1',
  `diskon` int(5) NOT NULL,
  `barcode` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `warna` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `favorit` int(5) NOT NULL,
  `hits` int(11) NOT NULL,
  PRIMARY KEY (`id_produk`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=175 ;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `ref_id`, `id_kategori`, `id_kustomer`, `nama_produk`, `kondisi`, `produk_seo`, `deskripsi`, `infoproduk`, `harga`, `stok`, `berat`, `tgl_masuk`, `gambar`, `gambar2`, `gambar3`, `gambar4`, `gambar5`, `gambar6`, `dibeli`, `diskon`, `barcode`, `warna`, `favorit`, `hits`) VALUES
(169, '4720170531063043', 38, 47, 'Sepeda MTB Giant', 'Baru', 'sepeda-mtb-giant', '<p>Sepeda MTB Giant Spesial Edisi</p>', '', 4000000, 5, '20.00', '2017-05-31 00:00:00', 'rudi@gmail.com_20170531063032_2.jpg', 'rudi@gmail.com_20170531063035_12.jpg', 'rudi@gmail.com_20170531063041_uy.jpg', '', '', '', 1, 0, '', '', 0, 9),
(170, '4420170708103759', 32, 44, 'Laptop MacBook Pro', 'Baru', 'laptop-macbook-pro', '<p>Laptop Acer Murah</p>', '', 2000000, 1, '2.00', '2017-07-08 00:00:00', 'fulan@gmail.com_20170708103729_17.jpg', 'fulan@gmail.com_20170708103733_18.jpg', 'fulan@gmail.com_20170708103748_19.jpg', '', '', '', 1, 0, '', '', 0, 3),
(171, '5120170709054028', 31, 51, 'Samsung Galaxy', 'Baru', 'samsung-galaxy', '<p>Samsung Galaxy S6</p>', '', 3000000, 3, '10.00', '2017-07-09 00:00:00', 'edi@gmail.com_20170709053836_a.jpg', 'edi@gmail.com_20170709053844_samsung-galaxy-s7-edge-hero.jpg', 'edi@gmail.com_20170709053849_b.jpeg', '', '', '', 1, 0, '', '', 0, 0),
(172, '5120170709054330', 31, 51, 'iPhone 5S', 'Baru', 'iphone-5s', '<p>iPhone 5s</p>', '', 2900000, 4, '1.00', '2017-07-09 00:00:00', 'edi@gmail.com_20170709054322_iphone_5s_boxes.jpg', 'edi@gmail.com_20170709054325_5-Ways-To-Fix-Flashlight-On-IPhone-5s.jpg', '', '', '', '', 1, 0, '', '', 0, 1),
(173, '4620170709054855', 31, 46, 'LG G5', 'Baru', 'lg-g5', '<p>LG G5 Series</p>', '', 2000000, 4, '12.00', '2017-07-09 00:00:00', 'putri@gmail.com_20170709054733_lg-g5-01.jpg', 'putri@gmail.com_20170709054854_lg-g5-modules-1.jpg', '', '', '', '', 1, 0, '', '', 0, 1),
(174, '4420170709055310', 31, 44, 'Xiaomi Mi5', 'Baru', 'xiaomi-mi5', '<p>Xiaomi Mi5</p>', '', 1500000, 0, '2.00', '2017-07-09 00:00:00', 'fulan@gmail.com_20170709055256_Harga-Xiaomi-Mi5.jpg', 'fulan@gmail.com_20170709055308_201602260105441g7f5am6.jpg', '', '', '', '', 5, 0, '', '', 0, 11);

-- --------------------------------------------------------

--
-- Struktur dari tabel `report`
--

CREATE TABLE IF NOT EXISTS `report` (
  `id_report` int(5) NOT NULL AUTO_INCREMENT,
  `id_produk` int(5) NOT NULL,
  `alasan` int(2) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` char(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `detail` text NOT NULL,
  PRIMARY KEY (`id_report`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `report`
--

INSERT INTO `report` (`id_report`, `id_produk`, `alasan`, `email`, `status`, `created_date`, `detail`) VALUES
(1, 124, 3, 'ada@gmail.com', '1', '2017-03-29 11:14:35', '<p>ok</p>');

-- --------------------------------------------------------

--
-- Struktur dari tabel `shop_pengiriman`
--

CREATE TABLE IF NOT EXISTS `shop_pengiriman` (
  `id_perusahaan` int(10) NOT NULL AUTO_INCREMENT,
  `nama_perusahaan` varchar(100) NOT NULL,
  PRIMARY KEY (`id_perusahaan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data untuk tabel `shop_pengiriman`
--

INSERT INTO `shop_pengiriman` (`id_perusahaan`, `nama_perusahaan`) VALUES
(6, 'JNE REG'),
(7, 'POS ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tujuan`
--

CREATE TABLE IF NOT EXISTS `tujuan` (
  `id_tujuan` int(5) NOT NULL AUTO_INCREMENT,
  `id_perusahaan` int(5) NOT NULL,
  `id_kota` int(5) NOT NULL,
  `nama_tujuan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_tujuan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
