
<?php
if ($_SESSION['email'] != '' && $_SESSION['useri'] == ''){
	include "update_username.php";
}
else{

	if ($_GET['module']=='home')
	{ 
		
		include "modul/home.php";
		
	}
	elseif  ($_GET['module']=='semuaproduk')
	{ include "modul/semua-produk.php";}
	elseif  ($_GET['module']=='hubungikami')
	{ include "modul/hubungi-kami.php";}
	elseif  ($_GET['module']=='hubungiaksi')
	{ include "modul/hubungi-aksi.php";}
	elseif  ($_GET['module']=='detailproduk')
	{ include "modul/produk.php";}
	elseif  ($_GET['module']=='detailkategori')
	{ include "modul/kategori.php";}
	elseif  ($_GET['module']=='keranjangbelanja'){
		if ($_SESSION['useri'] == ''){
		echo "<script>window.alert('Maaf Silahkan Login terlebih dahulu');
				window.location=('sign-in.html')</script>";
		}
		else{
			include "modul/keranjang.php";
		}
	}
	if ($_GET['module']=='cari')
	{ include "modul/cari.php";}	
	elseif  ($_GET['module']=='selesaibelanja')
	{ include "modul/selesaiorder.php";}
	elseif  ($_GET['module']=='simpantransaksimember'){ 
		if ($_SESSION['useri'] == ''){
		echo "<script>window.alert('Maaf Silahkan Login terlebih dahulu');
				window.location=('sign-in.html')</script>";
		}
		else{
			include "modul/simpanmember.php";
		}
	}
	elseif ($_GET['module']=='write-transaksi'){
			if ($_SESSION['email'] != ''){
				include "modul/write-transaksi.php";
			}
			else{
				header("Location: sign-in.html?err=log");
			}
	}
	elseif ($_GET['module']=='send-transaksi'){
			if ($_SESSION['email'] != ''){
				include "modul/send-transaksi.php";
			}
			else{
				header("Location: sign-in.html?err=log");
			}
	}		
	elseif  ($_GET['module']=='simpantransaksi')
	{ include "modul/simpantransaksi.php";}

	elseif  ($_GET['module']=='signup')
	{ include "modul/daftar.php";}
	elseif  ($_GET['module']=='hasilcari')
	{ include "modul/hasilcari.php";}
	elseif  ($_GET['module']=='faq')
	{ include "modul/faq.php";}
	elseif  ($_GET['module']=='syarat')
	{ include "modul/syarat.php";}
	elseif  ($_GET['module']=='login')
	{ include "modul/login.php";}
	elseif ($_GET['module']=='conditions'){
		include "modul/conditions.php";	
	}
	elseif ($_GET['module']=='privacy'){
		include "modul/privacy.php";	
	}
	elseif ($_GET['module']=='tips'){
		include "modul/tips.php";	
	}	
	elseif ($_GET['module']=='seller'){
		include "modul/seller.php";	
	}	
	elseif ($_GET['module']=='payment'){
		include "modul/payment.php";	
	}	
	elseif ($_GET['module']=='purchase'){
		include "modul/purchase.php";	
	}		
	elseif ($_GET['module']=='about'){
		include "modul/about.php";	
	}	
	elseif ($_GET['module']=='profile'){
		if ($_SESSION['useri'] == ''){
		echo "<script>window.alert('Maaf Silahkan Login terlebih dahulu');
				window.location=('sign-in.html')</script>";
		}
		else{
			include "modul/profile.php";
		}
	}
	elseif ($_GET['module']=='edit_profile'){
			if ($_SESSION['email'] != ''){
				include "modul/edit_profile.php";
			}
			else{
				header("Location: sign-in.html?err=log");
			}
	}	
	elseif ($_GET['module']=='edit-produk'){
		if ($_SESSION['email'] != ''){
				include "modul/edit_produk.php";
		}
		else{
			header("Location: sign-in.html?err=log");
		}
	}	
	elseif ($_GET['module']=='history_transaksi'){
			if ($_SESSION['email'] != ''){
				include "modul/transaksi.php";
			}
			else{
				header("Location: sign-in.html?err=log");
			}
	}
	elseif ($_GET['module']=='jualbarang'){
			if ($_SESSION['email'] != ''){
				include "modul/add-barang.php";
			}
			else{
				header("Location: sign-in.html?err=log");
			}
	}
	elseif ($_GET['module']=='add-transaksi'){
			if ($_SESSION['email'] != ''){
				include "modul/add-transaksi.php";
			}
			else{
				header("Location: sign-in.html?err=log");
			}
	}
	elseif ($_GET['module']=='myproduk'){
			if ($_SESSION['email'] != ''){
				include "modul/my-produk.php";
			}
			else{
				header("Location: sign-in.html?err=log");
			}
	}

	elseif ($_GET['module']=='mypesan'){
		if ($_SESSION['email'] != ''){
			include "modul/messages.php";
		}
		else{
			header("Location: sign-in.html?err=log");
		}
	}
	elseif ($_GET['module']=='notifikasi'){
		if ($_SESSION['email'] != ''){
			include "modul/notifikasi.php";
		}
		else{
			header("Location: sign-in.html?err=log");
		}
	}

	
	elseif ($_GET['module']=='myfavorit'){
		if ($_SESSION['email'] != ''){
			include "modul/favorit.php";
		}
		else{
			header("Location: sign-in.html?err=log");
		}
	}	
	elseif ($_GET['module']=='read-pesan'){
		if ($_SESSION['email'] != ''){
			include "modul/read_pesan.php";
		}
		else{
			header("Location: sign-in.html?err=log");
		}
	}
	elseif ($_GET['module']=='read-notif'){
		if ($_SESSION['email'] != ''){
			include "modul/read_notif.php";
		}
		else{
			header("Location: sign-in.html?err=log");
		}
	}	
	elseif($_GET['module'] == 'biaya'){
			include "modul/add-transaksi.php";
	}
	elseif($_GET['module'] == 'produk'){
			include "modul/my-produk.php";
	}
	elseif($_GET['module'] == 'favorit'){
			include "modul/favorit.php";
	}	
	elseif($_GET['module'] == 'barang'){
			include "modul/add-barang.php";
	}
	elseif($_GET['module'] == 'info'){
			include "modul/info.php";
	}
	elseif ($_GET['module']=='laporan'){
		include "modul/laporan.php";	
	}		
	elseif($_GET['module'] == 'read-info'){
			include "modul/read_info.php";
	}
	elseif ($_GET['module']=='success'){
			include "modul/sukses.php";
	}
	elseif ($_GET['module']=='contactus'){
			include "modul/kontak.php";
	}
	elseif ($_GET['module']=='other-pro'){
		include "modul/otherpro.php";
	}	
	
	elseif ($_GET['module']==0) { 
		header('location:index.php');
	}	
	elseif ($_GET['module']=='congratulation'){
		echo "
			<div class='main-column-wrapper'>
				<div class='main-column-left2'>
					<div class='blog-style-2'>
						<div class='post-title2'>
							<b>Congratulation!</b>
						</div>
						<p style='height: 300px;'>Account ativated!<br>
						Your account have been activated. For login please click <a href='sign-in.html'>here</a></p>
					</div>
				</div>
			</div>
		";
	}	
}
?>
