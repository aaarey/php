<?php
error_reporting(0);
include "config/koneksi.php";
	$created_date = date('Y-m-d H:i:s');
	mysql_query("INSERT INTO hubungi		 (	email,
												subjek,
												bantuan,
												deskripsi,
												tanggal)
												VALUES	('$_POST[email]',
														 '$_POST[subjek]',
														 '$_POST[bantuan]',
														 '$_POST[deskripsi]',
														 '$created_date')");
    echo "<script>window.alert('	Terimakasih telah menghubungi e-lapak, kami akan merespon pertanyaan anda');
        window.location=('index.php')</script>";													 
?>