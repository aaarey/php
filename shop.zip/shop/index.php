<?php
header("Location: home");
?>