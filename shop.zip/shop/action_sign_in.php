<?php
error_reporting(0);
include "config/koneksi.php";

$passwd = md5($_POST['password']);
$sql_sign_in = mysql_query("SELECT * FROM kustomer WHERE email = '$_POST[email]' AND password = '$passwd' AND status = 'Y'");
$nums = mysql_num_rows($sql_sign_in);
$data = mysql_fetch_array($sql_sign_in);
$last_login = date('Y-m-d H:i:s');
$email = explode("@", $_POST['email']);

if ($nums > 0){
	session_start();
	$last_login = date('Y-m-d H:i:s');	
	$_SESSION['email'] = $data['email'];
	$_SESSION['last_login'] = $last_login;
	$_SESSION['useri'] = $data['id_kustomer'];
	$_SESSION['nama'] = $data['nama_lengkap'];
	$_SESSION['username'] = $data['username'];	
	$_SESSION['password']= $data['password'];	

	mysql_query("UPDATE kustomer SET last_login ='$last_login' WHERE email = '$data[email]'");
	
	if ($_POST["iden"] == 1){
		header("Location: profile.html");
	}
	else{
		header("Location: profile.html");
	}
}
else{
	header("Location: sign-in.html?log=e_log");
}
?>