<table class='std'>
	<?php
		$ticker="USDIDR=X,AUDIDR=X,JPYIDR=X,EURIDR=X,SGDIDR=X,CADIDR=X,HKDIDR=X,CNYIDR=X";
		$fp=fopen("http://quote.yahoo.com/d/quotes.csv?s=$ticker&f=sl1d1t1c1ohgv&e=.csv","r");
		$USDIDR=fgetcsv($fp,1000,",");
		$AUDIDR=fgetcsv($fp,1000,",");
		$YENIDR=fgetcsv($fp,1000,",");
		$EURIDR=fgetcsv($fp,1000,",");
		$SGDIDR=fgetcsv($fp,1000,",");
		$CADIDR=fgetcsv($fp,1000,",");
		$HKDIDR=fgetcsv($fp,1000,",");
		$CNYIDR=fgetcsv($fp,1000,",");
		fclose($fp);
		$price=number_format($USDIDR[1],0,",",".");
		echo "<tr><td><img src='images/flags/us.png' class='icon' style='vertical-align:bottom'> 1 US &nbsp;</td><td>= <img src='images/flags/id.png' class='icon'> &nbsp;</td><td align='right'>Rp.$price </td></tr>";
		$price=number_format($AUDIDR[1],0,",",".");
		echo "<tr><td><img src='images/flags/au.png' class='icon' style='vertical-align:bottom'> 1 Australia &nbsp;</td><td>= <img src='images/flags/id.png' class='icon'> &nbsp;</td><td align='right'>Rp.$price </td></tr>";
		$price=number_format($YENIDR[1],0,",",".");
		echo "<tr><td><img src='images/flags/jp.png' class='icon' style='vertical-align:bottom'> 1 Japan &nbsp;</td><td>= <img src='images/flags/id.png' class='icon'> &nbsp;</td><td align='right'>Rp.$price </td></tr>";
		$price=number_format($EURIDR[1],0,",",".");
		echo "<tr><td><img src='images/flags/eu.png' class='icon' style='vertical-align:bottom'> 1 Euro &nbsp;</td><td>= <img src='images/flags/id.png' class='icon'> &nbsp;</td><td align='right'>Rp.$price </td></tr>";
		$price=number_format($SGDIDR[1],0,",",".");
		echo "<tr><td><img src='images/flags/sg.png' class='icon' style='vertical-align:bottom'> 1 Singapore &nbsp;</td><td>= <img src='images/flags/id.png' class='icon'> &nbsp;</td><td align='right'>Rp.$price </td></tr>";
		$price=number_format($CADIDR[1],0,",",".");
		echo "<tr><td><img src='images/flags/ca.png' class='icon' style='vertical-align:bottom'> 1 Canada &nbsp;</td><td>= <img src='images/flags/id.png' class='icon'> &nbsp;</td><td align='right'>Rp.$price </td></tr>";
		$price=number_format($HKDIDR[1],0,",",".");
		echo "<tr><td><img src='images/flags/hk.png' class='icon' style='vertical-align:bottom'> 1 HongKong &nbsp;</td><td>= <img src='images/flags/id.png' class='icon'> &nbsp;</td><td align='right'>Rp.$price </td></tr>";
		$price=number_format($CNYIDR[1],0,",",".");
		echo "<tr><td><img src='images/flags/cn.png' class='icon' style='vertical-align:bottom'> 1 Chinese &nbsp;</td><td>= <img src='images/flags/id.png' class='icon'> &nbsp;</td><td align='right'>Rp.$price </td></tr>";
	?>
</table>
