<?php
$server = "localhost";
$username = "root";
$password = "admin";
$database = "dbtoko";

// Koneksi dan memilih database di server
$koneksi=mysqli_connect($server,$username,$password, $database) or die("Koneksi gagal");

?>
