<?php
error_reporting(0);
include "config/koneksi.php";

function randomcode($len="10") {
	$code = NULL;
	for($i=0;$i<$len;$i++) {
		$char = chr(rand(48,122));
		while(!ereg("[a-zA-Z0-9]", $char)) {
			if($char == $lchar) { continue; }
			$char = chr(rand(48,90));
		}
		$pass .= $char;
		$lchar = $char;
	}
	return $pass;
} 
$sql_sign_up = mysql_query("SELECT * FROM kustomer WHERE email = '$_POST[email]'");
$nums = mysql_num_rows($sql_sign_up);

if ($_POST['password'] != $_POST['retype_password']){
	header("Location: sign-up.html?error=Error");
}
else{
	if ($nums > 0){
		header("Location: sign-up.html?error=Exist");
	}
	else{	
	$password = md5($_POST['password']);
	$created_date = date('Y-m-d H:i:s');
	$verification = randomcode();
	
	mysql_query("INSERT INTO kustomer		 (	email,
												username,
												password,
												photo,
												nama_lengkap,
												hp,
												alamat,
												daerah,
												status,
												created_date,
												verification_code)
												VALUES	('$_POST[email]',
														 '$_POST[username]',
														 '$password',
														 '',
														 '',
														 '',
														 '',
														 '',
														 'N',
														 '$created_date',
														'$verification')");
		$to = $_POST['email'];
		$pass = $_POST['password'];
		$username = $_POST['username'];
		$subject = "E-Lapak.com - Activation Code";
		$html = "<h5>Thank you for your registration at e-lapak.com</h5>
					<p>
					Your username : $username <br>
					Your email account : $to <br>
					Your password : $pass <br><br>
					
					Your activation code is $verification <br><br>
					For activation please click this url: <br>
					<a href='http://www.elapak.com/activate.php?code=$verification&email=$to'>http://www.elapak.com/activate.php?code=$verification&email=$to</a>
					<br><br><br>
					Thank You<br>
					This is an automated email. Do not reply. For trouble send to <a href='mailto: admin@elapak.com'>admin@elapak.com</a><br><br>
					E-lapak.com
					</p>
					";	
		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		
		// Additional headers
		$headers .= 'From: Membership-Elapak <membership@elapak.com>' . "\r\n";

		mail($to, $subject, $html, $headers);
		
		header("Location: success.html");				
	}
}
?>