<?php

if ($_GET['module'] == 'terms'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='terms_conditions.html' class='black'>Terms & Conditions</a>";
}

elseif($_GET['module'] == 'classified'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Kategori Iklan</span></a></span> ";		
}

elseif ($_GET['module'] == 'profile_member'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> Member Profile";
}

elseif ($_GET['module'] == 'discount_sale_info'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='discount-sale-info.html' class='black'>Info Discount & Sale</a>";
}

elseif ($_GET['module'] == 'events'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='event-$_GET[id].html' class='black'>Acara</a>";
}

elseif ($_GET['module'] == 'event-detail'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='event-0-1-all+provinces.html' class='black'>Acara</a>";
}

elseif ($_GET['module'] == 'classified_detail'){
	$nm = md5(date('Ymdhis'));
	$data_class = $db->database_fetch_array($db->database_prepare("SELECT * FROM as_groups WHERE group_id = ? AND status = 'Y'")->execute($_GET["id"]));
	echo "<p><a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='classified.html' class='black'>Kategori Iklan</a> <font color='#999999'> > </font> <a href='classified-$_GET[id]-$_GET[div]-$_GET[page]-$_GET[type]-$_GET[verified].html' class='black'>$data_class[group_name]</a></p>";
}

elseif ($_GET['module'] == 'discount_classified_detail'){
	$data_class = $db->database_fetch_array($db->database_prepare("SELECT * FROM as_groups WHERE group_id = ? AND status = 'Y'")->execute($_GET["id"]));
	if ($_GET['type'] == 1){
		$a = "SELECTED";
	}
	elseif ($_GET['type'] == 2){
		$b = "SELECTED";
	}
	elseif ($_GET['type'] == 3){
		$c = "SELECTED";
	}
	elseif ($_GET['type'] == 4){
		$d = "SELECTED";
	}
	elseif ($_GET['type'] == 5){
		$e = "SELECTED";
	}
	elseif ($_GET['type'] == 6){
		$f = "SELECTED";
	}
	else{
		$a = "";
		$b = "";
		$c = "";
		$d = "";
		$e = "";
		$f = "";
	}
	
	$title = strtolower(str_replace(" ", "+", $_GET["title"]));
	echo "<table>
			<tr>
				<td width='220'>
					<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='discount-sale-info.html' class='black'>Info Discount & Sale</a> <font color='#999999'> > </font> <a href='discount-classified-$_GET[id]-$_GET[pid]-$_GET[page]-$_GET[type]-$title.html' class='black'>$data_class[group_name]</a>
				</td>
				<td width='35'><a href='discount-sale-info.html'><img src='images/back.jpg' width='30' class='black'></a></td>
				<td width='395'><a href='discount-sale-info.html' class='black'><font color='#666666'>Back to Info Discount & Sale</font></a></td>
				
				<td width='50'><font color='#666666'>Urutkan:</font></td>
				<td><select class='sort' name='sort' id='sort' onChange='sortfunction(this.value)'>
						<option value='discount-classified-$_GET[id]-$_GET[pid]-$_GET[page]-1-$title.html' $a>Latest Ads</option>
						<option value='discount-classified-$_GET[id]-$_GET[pid]-$_GET[page]-2-$title.html' $b>Oldest Ads</option>
						<option value='discount-classified-$_GET[id]-$_GET[pid]-$_GET[page]-3-$title.html' $c>Title A-Z</option>
						<option value='discount-classified-$_GET[id]-$_GET[pid]-$_GET[page]-4-$title.html' $d>Title Z-A</option>
						<option value='discount-classified-$_GET[id]-$_GET[pid]-$_GET[page]-5-$title.html' $e>Lowest to Highest Price</option>
						<option value='discount-classified-$_GET[id]-$_GET[pid]-$_GET[page]-6-$title.html' $f>Highest to Lowest Price</option>
					</select> 
				</td>
			</tr>
			</table>";
}

elseif ($_GET['module'] == 'ads'){
	$data_ads = $db->database_fetch_array($db->database_prepare("SELECT * FROM as_advertising WHERE advertising_id = ? AND active = 'Y'")->execute($_GET["id"]));
	$data_class = $db->database_fetch_array($db->database_prepare("SELECT * FROM as_groups WHERE group_id = ? AND status = 'Y'")->execute($data_ads['group_id']));
	$data_cat = $db->database_fetch_array($db->database_prepare("SELECT * FROM as_categories WHERE category_id = ? AND group_id = ?")->execute($data_ads["category_id"],$data_ads["group_id"]));
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='classified.html' class='black'>Kategori Iklan</a> <font color='#999999'> > </font> <a href='classified-$data_ads[group_id]-1-1.html' class='black'>$data_class[group_name]</a> <font color='#999999'> > </font> $data_ads[title]<br>";
}

elseif ($_GET['module'] == 'pay-per-click'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='pay-per-click-$_GET[div]-$_GET[page].html' class='black'>Iklan PPC</a><br>";
}

elseif ($_GET['module'] == 'discount-info'){
	$data_dis = $db->database_fetch_array($db->database_prepare("SELECT * FROM as_discounts WHERE discount_id = ? AND active = 'Y'")->execute($_GET["id"]));
	$data_class = $db->database_fetch_array($db->database_prepare("SELECT * FROM as_groups WHERE group_id = ? AND status = 'Y'")->execute($data_dis['group_id']));
	$data_cat = $db->database_fetch_array($db->database_prepare("SELECT * FROM as_categories WHERE category_id = ? AND group_id = ?")->execute($data_dis["category_id"],$data_dis["group_id"]));
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='discount-sale-info.html' class='black'>Info Discount & Sale</a> <font color='#999999'> > </font> <a href='discount-info-$data_dis[group_id]-1-1.html' class='black'>$data_class[group_name]</a> <font color='#999999'> > </font> $data_dis[title]<br>";
}

elseif ($_GET['module'] == 'messages'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='messages-1-1.html' class='black'>Messages</a><br><br>";
}

elseif ($_GET['module'] == 'myads'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='myads-$_GET[div]-1.html' class='black'>Iklan Saya</a><br><br>";
}

elseif ($_GET['module'] == 'discount'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='discount-$_GET[div]-1.html' class='black'>My Discount & Sale</a><br>";
}

elseif ($_GET['module'] == 'add_free_ads'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='add_free_ads.html' class='black'>Tambah Iklan Anda</a><br><br>";
}

elseif ($_GET['module'] == 'add_ppc_ads'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='pay-per-click-1-1.html' class='black'>Iklan PPC</a> <font color='#999999'> > </font> <a href='add_ppc_ads.html' class='black'>Tambah Iklan PPC</a><br>";
}

elseif ($_GET['module'] == 'add_deposit'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='pay-per-click-1-1.html' class='black'>Iklan PPC</a> <font color='#999999'> > </font> <a href='add_deposit.html' class='black'>Tambah Deposit</a><br>";
}

elseif ($_GET['module'] == 'read-messages'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='messages-$_GET[div]-1.html' class='black'>Messages</a> <font color='#999999'> > </font> <a href='read-messages-$_GET[div]-$_GET[id].html' class='black'>Read Message</a><br><br>";
}

elseif ($_GET['module'] == 'add_discount_sale'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='add_discount_sale.html' class='black'>Add Discount & Sale Info</a><br>";
}

elseif ($_GET['module'] == 'edit-discount'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> <a href='discount-$_GET[div]-$_GET[page].html' class='black'>My Discount & Sale</a> <font color='#999999'> > </font> <a href='edit-discount-$_GET[div]-$_GET[page]-$_GET[id].html' class='black'>Edit Discount & Sale</a><br>";
}



elseif ($_GET['module'] == 'articles'){
	if ($_GET['id'] != 0){
	$article = $db->database_fetch_array($db->database_prepare("SELECT category_name FROM as_art_categories WHERE category_id = ? AND active = 'Y'")->execute($_GET["id"]));
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Tutorial</span></a></span> / <span>$article[category_name]</span>";
	}
	else{
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Tutorial</span></a></span> / <span>Semua Tutorial</span>";		
	}	
}
elseif($_GET['module'] == 'login'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Login</span></a></span> ";		
}

elseif($_GET['module'] == 'conditions'){
	echo "<span class='text-black'><a href='home' class='text-black'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Aturan Penggunaan</span></a></span> ";		
}
elseif($_GET['module'] == 'tips'){
	echo "<span class='text-black'><a href='home' class='text-black'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Tips Berbelanja</span></a></span> ";		
}
elseif($_GET['module'] == 'seller'){
	echo "<span class='text-black'><a href='home' class='text-black'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Cara Berjualan</span></a></span> ";		
}
elseif($_GET['module'] == 'payment'){
	echo "<span class='text-black'><a href='home' class='text-black'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Cara Pembayaran</span></a></span> ";		
}
elseif($_GET['module'] == 'purchase'){
	echo "<span class='text-black'><a href='home' class='text-black'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Cara Pembelian</span></a></span> ";		
}
elseif($_GET['module'] == 'privacy'){
	echo "<span class='text-black'><a href='home' class='text-black'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Aturan Privasi</span></a></span> ";		
}
elseif($_GET['module'] == 'signup'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Daftar</span></a></span> ";		
}
elseif($_GET['module'] == 'keranjangbelanja'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Keranjang Belanja</span></a></span> ";		
}
elseif($_GET['module'] == 'add-rating'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Rating</span></a></span> ";		
}
elseif($_GET['module'] == 'success'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Pendaftaran Berhasil</span></a></span> ";		
}
elseif($_GET['module'] == 'jualbarang'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Jual Barang</span></a></span> ";		
}
elseif($_GET['module'] == 'laporan'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Laporan Penjualan</span></a></span> ";		
}
elseif($_GET['module'] == 'write-transaksi'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Konfirmasi Pesanan</span></a></span> ";		
}
elseif($_GET['module'] == 'simpantransaksimember'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Proses Transaksi</span></a></span> ";		
}
elseif($_GET['module'] == 'myfavorit'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Produk Favorit</span></a></span> ";		
}
elseif($_GET['module'] == 'history_transaksi'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>History</span></a></span> ";		
}
elseif($_GET['module'] == 'add-transaksi'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Konfirmasi</span></a></span> ";		
}
elseif($_GET['module'] == 'contactus'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Kontak kami</span></a></span> ";		
}
elseif($_GET['module'] == 'read-pesan'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Pesan</span></a></span> ";		
}
elseif($_GET['module'] == 'myproduk'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Barang Dijual</span></a></span> ";		
}
elseif($_GET['module'] == 'messages'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Pesan</span></a></span> ";		
}
elseif($_GET['module'] == 'info'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Notifikasi</span></a></span> ";		
}
elseif($_GET['module'] == 'app_group_detail'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Source &amp; Code Detail</span></a></span> ";		
}
elseif($_GET['module'] == 'app_sale'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Source &amp; Code</span></a></span> ";		
}
elseif ($_GET['module'] == 'profile'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>My Profile</span></a></span> ";	
}
elseif ($_GET['module'] == 'edit-produk'){
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>Edit Produk</span></a></span> ";	
}

elseif($_GET['module'] == 'faq'){
	echo "<span><a href='home' class='text-sm'><span>Home</span></a></span>  / 
				<span><a href='#' class='text-grey'><span>FAQ</span></a></span> ";		
}
elseif($_GET['module'] == 'detailkategori'){
	$sql = mysql_query("SELECT nama_kategori from kategori where id_kategori='$_GET[id]'");
	$r = mysql_fetch_array($sql);	
	echo "<span><a href='home' class='text-grey'><span>Home</span></a></span>  / 
				<span>Kategori</span> / <span>$r[nama_kategori]</span> ";		
}
elseif ($_GET['module'] == 'edit_profile'){
	echo "<a href='home' class='black'>Home</a> <font color='#999999'> > </font> 
	<a href='profile.html' class='black'>Your Profile</a> <font color='#999999'> > </font> 
		<a href='edit_profile.html' class='black'>Edit Profile</a><br>";
}
?>