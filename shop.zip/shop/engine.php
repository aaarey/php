<?php
error_reporting(0);
session_start();
include "config/koneksi.php";
include "config/fungsi_indotgl.php";
include "config/class_paging.php";
include "config/fungsi_combobox.php";
include "config/library.php";
include "config/fungsi_autolink.php";
include "config/fungsi_rupiah.php";
include "config/fungsi_url.php";
include "config/fungsi_seo.php";
include "config/time_since.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Situs Belanja Online dan Jual Beli Mudah Terpercaya | Lapakku</title>
<meta name="description" content="Pusat Jualan Online Marketstore"/>
<meta name="keywords" content="Lapakku">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
<link rel="Shortcut icon" href="static/icons.png"/>

<link rel="stylesheet" href="static/css/bootstrap.css" type="text/css"/>
<link rel="stylesheet" href="static/css/animate.css" type="text/css"/>
<link rel="stylesheet" href="static/css/font-awesome.min.css" type="text/css"/>
<link rel="stylesheet" href="static/css/simple-line-icons.css" type="text/css"/>
<link rel="stylesheet" href="static/css/font.css" type="text/css"/>
<link rel="stylesheet" href="static/js/lightbox/themes/classic/jquery.lightbox.css"/>
<link rel="stylesheet" href="static/js/redactor/redactor.css"/>
<link rel="stylesheet" href="static/css/pandalocker.2.0.7.css">
<link rel="stylesheet" href="static/css/app2.css" type="text/css"/>
<link href="static/css/ionicons.min.css" media="all" rel="stylesheet" type="text/css">
<script type="text/javascript" src="static/js/ckeditor/ckeditor.js"></script>
<link rel="stylesheet" href="static/css/style112.css" type="text/css" />
<link rel="stylesheet" href="static/css/style111.css" type="text/css"/>

<link type="text/css" rel="stylesheet" media="all" href="css/chat.css" />
<script type="text/javascript" src="js/chat.js"></script>
<script type="text/javascript" src="js/jquery-1.6.3.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.7.2.custom.min.js"></script>
<script src="static/js/countdown.js"></script>
<script type="text/javascript" src="static/liveSearch/livesearch.js"></script>		

</head>
<body>
<div id="wrap">
	<!-- header -->
<header id="header" class="navbar navbar-fixed-top box-shadow" data-spy="affix" data-offset-top="1">
<div class="bg-success">
	<div class="container">
		<div class="navbar-header ">
			<button class="btn btn-link visible-xs pull-right m-r" type="button" data-toggle="collapse" data-target=".navbar-collapse">
			<i class="ion-navicon fa-lg icon-true"></i>
			</button>
				<a href="index.php" class="navbar-brand m-r-n m-l-n-md"><img src="static/img/logo.png"></a>
		</div>
		<div class="collapse navbar-collapse">
		<!--Mobile-->
		<ul class="nav navbar-nav m-l-n visible-xs">
		<?php 
		if ($_SESSION['email'] == ''){
		?>
			<li style="padding:1px 10px 10px 20px;">
				<div class="m-t-sm">
					<a rel="nofollow" href="sign-in.html" class="btn btn-black btn-sm ">Login</a>
					<a rel="nofollow" href="sign-up.html" class="btn btn-sm btn-go m-r-xs">Daftar</a>
				</div>
			</li>
		<?php } ?>
					<li class="dropdown">
						<a rel="nofollow" href="#" data-toggle="dropdown" class="dropdown-toggle"><span>Kategori</span> <span class="caret"></span></a>
						<ul class="dropdown-menu animated fadeInDown" role="menu">
							<li>
								<a href="#">
								<i class="ion-ios-pricetags" aria-hidden="true"></i>
								<span>Produk Promo</span>
								</a>
							</li>
							<li class="divider"></li>
							<?php
							$kategori=mysql_query("select nama_kategori, kategori.id_kategori, kategori.icon, kategori.label,kategori_seo,
                                  count(produk.id_produk) as jml 
                                  from kategori left join produk 
                                  on produk.id_kategori=kategori.id_kategori 
                                  group by nama_kategori");
						while($r=mysql_fetch_array($kategori)){
							echo"<li>
								<a href='kategori-$r[id_kategori]-$r[kategori_seo].html'>
								<i class='ion-android-done' aria-hidden='true'></i>
								<span>$r[nama_kategori]</span>
								</a>
							</li>";
						}
							?>

						</ul>
					</li>		
		</ul>
		<?php
		if ($_SESSION['email'] != ''){
		?>		
			<div class="cnt-account">
				<ul class="nav navbar-nav navbar-left m-r-xs">			
					<a href="my-favorit.html" class="btn btn-sm "><i class="ion-android-favorite"></i> Favorit</a>					
					<a href="history_transaksi.html" class="btn btn-sm "><i class="ion-arrow-swap"></i> History Belanja</a>					
				</ul>
			</div>

		<div class="cnt-accounts">
		<ul class="nav navbar-nav navbar-right m-r-xs ">
				<a class="btn btn-sm ">Welcome, <font color="#faa142"><?php echo $_SESSION['username']; ?> </font> </a>
				<a href="contact-us.html" class="btn btn-sm ">Kontak Kami</a>			
				<a href="faq.html" class="btn btn-sm ">Buka Bantuan</a>					
		</ul>
		</div>
		
		<ul class="nav navbar-nav navbar-right m-r-xs">
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" class="dropdown-toggle clear" data-toggle="dropdown">
						<span class="thumb-sm avatar pull-right m-t-n-sm m-b-n-sm ">
						<?php
						$sql=mysql_query("SELECT * FROM kustomer WHERE id_kustomer = '$_SESSION[useri]'");
						$r=mysql_fetch_array($sql);						
						
						?>
						<?php if ($r['photo'] !=''){ ?>
							<img src='static/products/foto_member/<?php echo $r['photo']; ?>'/> <b class="caret"></b>
						<?php } 
						else {
						?>
							<img src='static/img/fb.jpg'/> <b class="caret"></b>
						<?php } ?>
						
						</span>
						</a>
						<ul class="dropdown-menu">
							<!--<li>
								<a href="my-favorit.html" class="btn btn-sm "><i class="ion-android-favorite"></i> Favorit</a>					
							</li>
							<li>
								<a href="history_transaksi.html" class="btn btn-sm "><i class="ion-arrow-swap"></i> History Belanja</a>	
							</li>-->
							<li>
								<a href="my-produk.html"><span><i class="ion-bag m-r-xs"></i> My Lapak</span></a>
							</li>
							<li class="divider"></li>	
							<li>
								<a href="laporan.html"><span><i class="ion-shuffle m-r-xs "></i> Transaksi</span></a>
							</li>					
							<li class="divider"></li>							
							<li>
								<a href="profile.html"><span><i class="ion-person m-r-xs "></i> Profile</span></a>
							</li>					
							<li class="divider"></li>
							<li>
								<a href="logout.php"><span><i class="ion-power m-r-xs"></i> Logout</span></a>
							</li>
						</ul>
					</li>
					
		</ul>			

		<?php
		}
		else{
		?>
		<div class="cnt-accounts">
		<ul class="nav navbar-nav navbar-right">
					<a rel="nofollow" href="#" class="btn btn-sm ">Blog</a>			
					<a href="contact-us.html" class="btn btn-sm ">Kontak Kami</a>		
					<a href="faq.html" class="btn btn-sm ">Buka Bantuan</a>							
		</ul>		
		</div>
		<?php
		}
		?>

		</div>
	</div>
</div>
<div class="navbar bg-white-only visible-sm visible-md visible-lg">
	    <div class="container">
						
		<ul class="nav navbar-nav m-l-n ">
				<li><a href="index.php">Home</a></li>
				
					<li class="dropdown">
						<a rel="nofollow" href="#" data-toggle="dropdown" class="dropdown-toggle"><span>Kategori</span> <span class="caret"></span></a>
						<ul class="dropdown-menu animated fadeInDown" role="menu">
							<li>
								<a href="#">
								<i class="ion-ios-pricetags" aria-hidden="true"></i>
								<span>Produk Promo</span>
								</a>
							</li>
							<li class="divider"></li>
							<?php
							$kategori=mysql_query("select nama_kategori, kategori.id_kategori, kategori.icon, kategori.label,kategori_seo,
                                  count(produk.id_produk) as jml 
                                  from kategori left join produk 
                                  on produk.id_kategori=kategori.id_kategori 
                                  group by nama_kategori");
							while($r=mysql_fetch_array($kategori)){
								echo"<li>
									<a href='kategori-$r[id_kategori]-$r[kategori_seo].html'>
									<i class='ion-android-done' aria-hidden='true'></i>
									<span>$r[nama_kategori]</span>
									</a>
								</li>";
							}
							?>

						</ul>
					</li>			
			
						  
			<li>    
			<form id="search" action="#" method="GET" class="navbar-form navbar-form-sm visible-xs visible-md visible-lg" ui-shift="prependTo" 
					data-target=".navbar-collapse" role="search" ng-controller="TypeaheadDemoCtrl">
					<div class="form-group">
					<div class="input-group ">
						<input  type="text" id="livesearch" autofocus onkeydown="if(event.keyCode==13)doCommand();" style='width: 630px;' class="form-control input-sm bg-light no-border padder" placeholder="Aku mau belanja ...">
							<span class="input-group-btn">
								<button type="submit" class="btn btn-sm bg-light "><i class="fa fa-search"></i></button>
							</span>
					</div>
			</form>
			</li>
			</ul>
			<ul class="nav navbar-nav nav-indicators ">
			<?php
			if ($_SESSION['email'] != ''){
			$name_login = mysql_fetch_array(mysql_query("SELECT nama,photo FROM kustomer WHERE email = '$_SESSION[email_login]'"));
			$num_messages_new = mysql_num_rows(mysql_query("SELECT * FROM as_messages WHERE sendto = '$_SESSION[useri]' AND status = 0"));
			?>
			<?php
			$sid = $_SESSION[email];
			$sql = mysql_query("SELECT SUM(jumlah*(harga-(diskon/100)*harga)) as total,SUM(jumlah) as totaljumlah 
							FROM orders_temp, produk 
			                WHERE id_session='$sid' AND orders_temp.id_produk=produk.id_produk AND status='0'");			
			while($r=mysql_fetch_array($sql)){
				    $total_rp    = format_rupiah($r['total']);
				if ($r['totaljumlah'] != ""){
					echo"<li class='dropdown nav-notifications'>
						<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='badge'>$r[totaljumlah]</span>
						<i class='ion-android-cart fa-lg icon-true'></i></a>
						<ul class='dropdown-menu'>
						<li class='nav-notifications-header'>
							<a tabindex='-1' href='#'><strong></strong>  Transaksi baru</a>
						</li>
						<li class='nav-notification-body text-info'>
							<a href='keranjang-belanja.html'><i class='ion-android-cart'></i> ($r[totaljumlah]) item produk <small class='pull-right'>Rp. $total_rp</small></a>
						</li>
						</ul>
						</li>";
				}
				else{
					echo"<li class='dropdown nav-messages'>
					<a href='keranjang-belanja.html' title='barang'>
						<span class='badge'></span><i class='ion-android-cart fa-lg icon-true'></i></a></li>";				
				}
			}
			?>

			<?php
			$num_messages_new = mysql_num_rows(mysql_query("SELECT * FROM as_chat WHERE chat_to = '$_SESSION[useri]' AND recd = 0"));
			if($num_messages_new != ''){
			?>
			<li class='dropdown nav-messages'>
				<a href="my-pesan.html">
					<span class="badge"><?php echo $num_messages_new; ?></span>
					<i class="ion-android-chat fa-lg icon-true"></i>
				</a>
			</li>
			<?php }	else{		
			?>
			<li class='dropdown nav-messages'>
				<a href="my-pesan.html">
					<span class="badge"></span>
					<i class="ion-android-chat fa-lg icon-true"></i>
				</a>
			</li>
			<?php } ?>
			<li class="dropdown nav-notifications">
				<?php
				$jum=mysql_num_rows(mysql_query("SELECT * FROM informasi WHERE dibaca='N'"));
				$r=mysql_fetch_array(mysql_query("SELECT * FROM informasi WHERE dibaca='N'"));
				if($jum != ''){
				?>		
					<a href="notifikasi.html" class="dropdown-toggle" data-toggle="dropdown">
					<span class="badge"><?php echo $jum; ?></span>
					<i class="ion-android-notifications fa-lg icon-true"></i></a>
					<ul class="dropdown-menu">
						<li class="nav-notifications-header">
							<a tabindex="-1" href="#">Kamu memiliki <strong><?php echo $jum; ?></strong> notifikasi baru</a>
						</li>
						<li class="nav-notification-body text-info">
							<a href="notifikasi.html"><i class="ion-volume-high"></i> Lihat sekarang <small class="pull-right"><i class='ion-more'></i></small></a>
						</li>
					</ul>
				<?php } 
				else{
				?>
					<a href="notifikasi.html" class="dropdown-toggle" data-toggle="dropdown">
					<span class="badge"></span>
					<i class="ion-android-notifications fa-lg icon-true"></i></a>
					<ul class="dropdown-menu">
						<li class="nav-notifications-header">
							<a tabindex="-1" href="#"><i class="ion-ios-close-outline"></i> Belum ada notifikasi! </a>
						</li>

					</ul>
				<?php } ?>
				
			</li>
					

			<li class='dropdown nav-products'>
				<div class=" m-r-xs m-t-sm">
					<a rel="nofollow" href="jual-barang.html" class="btn btn-sm btn-go"><i class='ion-plus'></i>
					 Jual Barang</a>	
				</div>			
			</li>
			
			<?php
			}
			else{
			?>	
			<li>
				<a href="sign-in.html"><i class="ion-camera fa-lg icon-true"></i></a>			
			</li>			
			<li>
				<a href="sign-in.html"><i class="ion-android-cart fa-lg icon-true  m-r-xs"></i></a>			
			</li>	
			<li style="padding:1px 10px 10px 20px;">
				<div class="m-t-sm" >
					<a rel="nofollow" href="sign-in.html" class="btn btn-black btn-sm ">Login</a>
					<a rel="nofollow" href="sign-up.html" class="btn btn-sm btn-go m-r-xs">Daftar</a>
				</div>
			</li>			
			<?php } ?>
        </ul>
	    </div>
    </div>

  </header>	


	<!--<div id="content" class="main-content bg-light">-->
	<div class="main-content bg-light">
		<?php
			include "content.php";
		?>
		
	</div>
	

	

</div>
<!-- footer -->
<footer id="footer">
<div class="bg-black ">
	<div class="container ">
		<div class="row m-t-xl m-b-xl">
			<div class="col-sm-3">
				<h4 class=" m-b-xl text-white font-thin"><span class="font-bold">Follow</span> kami</h4>
				<div class="m-b-xl">
					<a rel="nofollow" href="#" target="_blank" class="btn btn-icon btn-facebook"><i class="fa fa-lg fa-facebook m-t-xxs"></i></a>
					<a rel="nofollow" href="#" target="_blank" class="btn btn-icon btn-twitter"><i class="fa fa-lg fa-twitter m-t-xxs"></i></a>
					<a rel="nofollow" href="#" target="_blank" class="btn btn-icon btn-googleplus"><i class="fa fa-lg fa-google-plus m-t-xxs"></i></a>
				</div>
			</div>
			<div class="col-sm-3">
				<h4 class=" m-b text-white font-thin"><span class="font-bold">Lapakku</span></h4>
				<ul class="list-unstyled ">
					<li>
						<a href="about-us.html">Tentang Lapakku</a>
					</li>
					<li>
						<a href="conditions.html">Aturan Penggunaan</a>
					</li>
					<li>
						<a href="privacy.html">Kebijakan Privasi</a>
					</li>
				</ul>
			</div>
			<div class="col-sm-3">
				<h4 class="m-b text-white font-thin"><span class="font-bold">Info</span></h4>
				<ul class="list-unstyled ">
					<li>
						<a href="tips.html">Tips Berbelanja</a>
					</li>
					<li>
						<a href="payment.html">Pembayaran</a>
					</li>
					<li>
						<a href="purchase.html">Pembelian</a>
					</li>					

				</ul>
			</div>
			<div class="col-sm-3">
				<h4 class=" m-b text-white font-thin"><span class="font-bold">Bantuan</span></h4>
				<ul class="list-unstyled ">
					<li>
						<a href="seller.html">Cara Berjualan</a>
					</li>
					<li>
						<a href="faq.html">FAQ</a>
					</li>
					<li>
						<a href="contact-us.html">Kontak kami</a>
					</li>					
				</ul>
			</div>
		</div>
	</div>
</div>
<div class="bg-black lt">
	<div class="container">
		<div class="row padder-v m-t">
			<div class="col-xs-8">
			</div>
			<div class="col-xs-4 text-right ">Copyright &copy; 2015 - <?php echo date('Y');?> By Lapakku</div>
		</div>
	</div>
</div>
</footer>
<!-- / footer -->
<script src="static/js/jquery.min.js"></script>
<script src="static/js/lightbox/jquery.lightbox.min.js"></script>
<script src="static/js/redactor/redactor.js"></script>
<script src="static/js/redactor/source.js"></script>
<script src="static/js/redactor/video.js"></script>
<!-- Bootstrap -->
<script src="static/js/bootstrap.js"></script>
<script src="static/js/ui-load.js"></script>
<script src="static/js/ui-jp.config.js"></script>
<script src="static/js/ui-jp.js"></script>
<script src="static/js/ui-nav.js"></script>
<script src="static/js/ui-toggle.js"></script>
<script src="static/js/jquery.appear.js"></script>
<script src="static/js/landing.js"></script>
<script src="static/js/extra204.js"></script>
<script src="static/js/jquery.ui.highlight.min.js"></script>
<script src="static/js/pandalocker.2.0.7.js"></script>
	

</body>
</html>