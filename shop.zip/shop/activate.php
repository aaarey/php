<?php
error_reporting(0);
include "config/koneksi.php";

$sql_find = mysql_query("SELECT * FROM kustomer WHERE email = '$_GET[email]' AND status = 'N' AND verification_code = '$_GET[code]'");
$nums = mysql_num_rows($sql_find);
if ($nums > 0){
	mysql_query("UPDATE kustomer SET status = 'Y', verification_code = '' WHERE email = '$_GET[email]'");
	header("Location: congratulation.html");	
}
else{
	header("Location: index.php");
}
?>