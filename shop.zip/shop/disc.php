
<?php
    // diskon  
    $harga     = format_rupiah($r['harga']);
    $disc      = ($r['diskon']/100)*$r['harga'];
    $hargadisc = number_format(($r['harga']-$disc),0,",",".");

    $d=$r['diskon'];
    $hargatetap  = "<span> </span>
                    <span><b> Rp. $hargadisc,-</b></span>";
    $hargadiskon = "<span> $d% -</span>
                    <span><b> Rp. $hargadisc,-</b></span>";
    if ($d!=0){
      $divharga=$hargadiskon;
    }else{
      $divharga=$hargatetap;
    } 

    // tombol stok habis kalau stoknya 0
    $stok        = $r['stok'];
    $tombolbeli  = "<a rel='nofollow' href='aksi.php?module=keranjang&act=tambah&id=$r[id_produk]' data-toggle='tooltip' data-placement='top' title='Beli' class='btn btn-sm btn-icon btn-default' target='_blank'>
					<i class='fa fa-cart-plus'></i> </a>";	
					
    $tombolhabis = "<a rel='nofollow' href='#' data-toggle='tooltip' data-placement='top' title='Stok Habis' class='btn btn-sm btn-icon btn-default'>
					<i class='ion-alert-circled'></i></a>";
					
    $buttonbeli  = "<a class='btn btn-success btn-md btn-block  font-bold' href=\"aksi.php?module=keranjang&act=tambah&id=$r[id_produk]\"><i class='ion-android-cart'></i> 
					Beli </a>
					";
    $buttonhabis = "<a class='btn btn-danger btn-md btn-block  font-bold' href='#'> Stok Habis <i class='ion-alert'></i></a>";
	
    if ($stok!=0){
      $tombol=$tombolbeli;
    }else{
      $tombol=$tombolhabis;
    } 
	
    if ($stok!=0){
      $button=$buttonbeli;
    }else{
      $button=$buttonhabis;
    } 	
?>
