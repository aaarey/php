<link rel="stylesheet" type="text/css" media="all" href="js/fancybox/jquery.fancybox.css">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/fancybox/jquery.fancybox.js?v=2.0.6"></script>
<link rel="stylesheet" href="css/jquery-tab.css" type="text/css" />
<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script src="js/jquery.validate.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery.selectric.min.js"></script>
<script>
jQuery(document).ready(function(){
	
	$("#email").change(function()
	{ //if theres a change in the username textbox
		var email = $("#email").val();//Get the value in the username textbox
		$("#email_status").html('<img src="images/loader.gif" align="absmiddle">&nbsp;Checking...');
		//Add a loading image in the span id="availability_status"
		$.ajax({  //Make the Ajax Request
			type: "POST",
			url: "modul/mod_myads/check_email.php",  //file name
			data: "friend_email="+ email,  //data
			success: function(server_response){
				$("#email_status").ajaxComplete(function(event, request){
					if(server_response == '2')//if it returns "1"
					{
						$("#email_status").html('<div class="error">Invalid email address.</div>');
						document.getElementById("send").disabled = true; 
					}
					else if(server_response == '1')//if it returns "1"
					{
						$("#email_status").html('');
						document.getElementById("send").disabled = false; 
					}
				});
			}
		});
	});
	
	$("#send").on("click", function(){
		var msgval	= $("#msg").val();
		var memberid= $("#member_id").val();
		var div		= $("#div").val();
		var page	= $("#page").val();
		var type	= $("#type").val();
		var nm		= $("#nm").val();
		var subject	= $("#subject").val();
		var email	= $("#email").val();
		var msglen	= msgval.length;
		var sublen = subject.length;
		var mallen = email.length;
		
		if (sublen != 0 && msglen > 4 && mallen != 0){
			
			$("#send").replaceWith("<em>Sending...</em>");
			
			$.ajax({
				type: 'POST',
				url: 'send_email.php',
				data: $("#contact2").serialize(),
				success: function(data) {
					if(data == "true") {
						$("#contact2").fadeOut("fast", function(){
							$(this).before("<p><strong>Success! Your email has been sent.</strong></p>");
							setTimeout("$.fancybox.close()", 1000);
							top.location.href = 'http://www.oaseast.com/other-ads-'+memberid+'-'+div+'-'+type+'-'+page+'-'+nm+'.html';
						});
					}
				}
			});
		}
	});
	
	$(".modalbox2").fancybox();
	
	$('select.sort').selectric();
});
</script>


	<?php
	if ($_GET['module'] == 'classified_detail'){
	?>
	
		<script type="text/javascript" src="js/vsmenu.js"></script>
		<link rel="stylesheet" type="text/css" href="css/vsmenu.css">
		
		<label class="badge">Kategori Iklan</label>
		<ul class="vsmenu vs_creamy">
			<?php
			$nm = strtolower(str_replace(" ", "+", $_GET['nm']));
			$sql_gr = mysql_query("SELECT * FROM groups WHERE status = 'Y' ORDER BY group_name ASC")->execute();
			while ($data_gr = mysql_fetch_array($sql_gr)){
				$nums = mysql_num_rows(mysql_query("SELECT * FROM kategori WHERE id_group = '$data_gr[id_group]' AND status = 'Y'"));
					
				if ($nums > 0){
					echo "<li><a href='classified-$data_gr[id_group]-1-1-1-$_GET[verified]-$_GET[pid]-0-$nm.html'>$data_gr[group_name]</a><ul>";
						$sql_ct = mysql_query("SELECT * FROM kategori WHERE id_group = '$data_gr[id_group]' AND status = 'Y' ORDER BY nama_kategori ASC");
						while ($data_ct = mysql_fetch_array($sql_ct)){
							echo "<li><a href='classified-$data_gr[id_group]-$_GET[div]-$_GET[page]-1-$_GET[verified]-$_GET[pid]-$data_ct[id_kategori]-$nm.html'>
							$data_ct[nama_kategori]</a></li>";
						}
						echo "</ul></li>";
					}
					else{
						echo "<li><a href='classified-$data_gr[id_group]-1-1-1-$_GET[verified]-$_GET[pid]-0-$nm.html'>$data_gr[group_name]</a></li>";
					}
				}
				?>
		</ul>
		<br>
	<?php
	}

	if ($_GET['module'] == 'events' || $_GET['module'] == 'event-detail'){
	?>
	
		<script type="text/javascript" src="js/vsmenu.js"></script>
		<link rel="stylesheet" type="text/css" href="css/vsmenu.css">
		
		<br>
		<label class="badge">Cari Berdasarkan Propinsi</label>
		<ul class="vsmenu vs_creamy">
			<?php
			$sql_province = $db->database_prepare("SELECT * FROM as_provinces WHERE status = 'Y' ORDER BY province_name ASC")->execute();
			while ($data_province = $db->database_fetch_array($sql_province)){
				$nums = $db->database_num_rows($db->database_prepare("SELECT event_id FROM as_events WHERE province_id = ? AND status = 'Y'")->execute($data_province['province_id']));
				
				$province = strtolower(str_replace(" ", "+", $data_province['province_name']));
				echo "<li><a href='event-$data_province[province_id]-1-$province.html'>$data_province[province_name] <span style='float: right;'>$nums</span></a></li>";
			}
			?>
		</ul>
		
		<br>
	<?php
	}
	
	if ($_GET['module'] == 'discount_classified_detail'){
	?>
	
		<script type="text/javascript" src="js/vsmenu.js"></script>
		<link rel="stylesheet" type="text/css" href="css/vsmenu.css">
		
		<br>
		<label class="badge">Filter by Provinces:</label>
		<ul class="vsmenu vs_creamy">
			<?php
			$title = strtolower(str_replace(" ", "+", $_GET["title"]));
			$sql_province = $db->database_prepare("SELECT * FROM as_provinces WHERE status = 'Y' ORDER BY province_name ASC")->execute();
			while ($data_province = $db->database_fetch_array($sql_province)){
				$nums = $db->database_num_rows($db->database_prepare("SELECT discount_id FROM as_discounts WHERE province_id = ? AND active = 'Y'")->execute($data_province['province_id']));
				
				$province = strtolower(str_replace(" ", "+", $data_province['province_name']));
				echo "<li><a href='discount-classified-$_GET[id]-$data_province[province_id]-$_GET[page]-$_GET[type]-$title.html'>$data_province[province_name] <span style='float: right;'>$nums</span></a></li>";
			}
			?>
		</ul>
		
		<br>
	<?php
	}
	
	if ($_GET['module'] == 'articles'){
	?>

		<div class="col-sm-3  hidden-sm">
			<div class="panel bg-black ">

			<div class="panel-body text-center">
				<p class="h4 m-b-sm text-white">Join over <strong>5,000</strong> developers, designers and entrepreneurs!</p>
				<p class="text-md text-white">Dapatkan <strong>tutorial dan artikel menarik</strong>, <strong>yang akan dikirim ke inbox email anda</p>
				<form action="https://codester.us7.list-manage.com/subscribe/post" method="POST">
					<input type="hidden" name="u">
					<input type="hidden" name="id">
					<input type="email" placeholder="Masukan email anda ..." class="form-control m-b-sm" autocapitalize="off" autocorrect="off" size="25" value="">
					<input type="submit" class="btn btn-info font-bold btn-block" name="submit" value="Bergabung">
				</form>
				
			</div>
			</div>    
			<div class="panel b-a">
			<div class="panel-heading b-b b-light">
				<span class="font-bold">Kategori</span>
            </div>
			<ul class="list-group list-group-lg no-bg auto">
				<?php
				$sql_art = $db->database_prepare("SELECT * FROM as_art_categories WHERE active = 'Y' ORDER BY category_name ASC")->execute();
				while ($data_art = $db->database_fetch_array($sql_art)){
					$nums = $db->database_num_rows($db->database_prepare("SELECT category_id FROM as_articles WHERE category_id = ? AND active = 'Y'")->execute($data_art['category_id']));
					
					echo "<li class='list-group-item clearfix'>
							<span class='clear'>
							<a href='articles-$data_art[category_id]-1-$data_art[category_seo].html' class='text-grey'><i class='fa fa-angle-double-right m-t-sm m-r-sm'></i> $data_art[category_name] 
							<span style='float: right;'>$nums</span></a></span>
						 </li>";
				}
				?>		

			</ul>
			</div> 
              

            <a class="btn btn-md btn-rss" href="https://www.codester.com/blog/feed/"><i class="fa fa-rss fa-lg m-r-xs"></i> RSS</a>
		</div> 

	<?php
	}

	if ($_GET['module'] == 'news'){
	?>
	
		<script type="text/javascript" src="js/vsmenu.js"></script>
		<link rel="stylesheet" type="text/css" href="css/vsmenu.css">
		
		<br>
		<label class="badge">Kategori Berita</label>
		<ul class="vsmenu vs_creamy">
			<?php
			$sql_news_cat = $db->database_prepare("SELECT * FROM as_news_categories WHERE active = 'Y' ORDER BY category_name ASC")->execute();
			while ($data_news_cat = $db->database_fetch_array($sql_news_cat)){
				$nums = $db->database_num_rows($db->database_prepare("SELECT category_id FROM as_news WHERE category_id = ? AND active = 'Y'")->execute($data_news_cat['category_id']));
				
				echo "<li><a href='news-$data_news_cat[category_id]-1-$data_news_cat[category_seo].html'>$data_news_cat[category_name] <span style='float: right;'>$nums</span></a></li>";
			}
			?>
		</ul>
		
		<br>
	<?php
	}

	if ($_GET['module'] == 'other-ads'){
		$data_member = $db->database_fetch_array($db->database_prepare("SELECT facebook_id, cellphone, hidden_cellphone, twitter_id FROM as_member WHERE member_id = ?")->execute($_GET['id']));
		if ($data_member['facebook_id'] != ''){
			$app_id = "255449991303140";
			$secret_id = "fde2b94d49a1559c54ba706300b4a78f";
			
			$facebook = new Facebook(array(
				'appId'  => $app_id,
				'secret' => $secret_id,
			));
			$user		= $facebook->getUser();
			$get_data	= $facebook->api('/'.$data_member['facebook_id'], 'GET');
			$facebook_name = "<a href='http://www.facebook.com/$get_data[username]' target='_blank' class='black'>$get_data[username]</a>";
			$img_fb		= "<img src='images/facebook.png' width='16'>";
		}
		else{
			$facebook_name = "Not Available";
			$img_fb		= "<img src='images/facebook.png' width='16'>";
		}
		
		if ($data_member['hidden_cellphone'] != '1'){
			$img_call = "<img src='images/call.png' width='16'>";
		}
		else{
			$img_call = "";
		}
		
		if ($data_member['cellphone'] != ''){
			$cellphone = $data_member['cellphone'];
		}
		else{
			$cellphone = "Not available";
		}
		
		echo "<div style='background: none repeat scroll 0 0 #FFFFFF; border: 1px solid #DADADA; border-radius: 5px; box-shadow: 0 1px 6px rgba(0, 0, 0, 0.2); padding: 10px; width: 180px;'>
				<br>
				<table>
					<tr>
						<td width='20'>$img_call</td>
						<td><font color='#1C60A7' size='3'><b>$cellphone</b></font></td>
					</tr>
				</table>
				<hr style='border: 1px solid #E8E8E8; margin-top: 15px; margin-bottom: 15px;'>
				<a class='modalbox2' href='#inline'>
				<div class='chat2'>
					<img src='images/mail.png' width='22'> 
					<span style='font-weight: bold; font-size: 14px; color: #FFFFFF;'>Send Email</span>
					<div id='inline'>
					    <form id='contact2' name='contact2' action='?validate=error' method='post'>
					    	<input type='hidden' id='member_id' name='member_id' value='$_GET[id]'>
					    	<input type='hidden' id='nm' name='nm' value='$_GET[nm]'>
					    	<input type='hidden' id='div' name='div' value='$_GET[div]'>
					    	<input type='hidden' id='page' name='page' value='$_GET[page]'>
					    	<input type='hidden' id='type' name='type' value='$_GET[type]'>
					    	<table width='100%' cellpadding='5' cellspacing='5'>
					    		<tr>
					    			<td style='background-color: #CCCCCC;'><p style='font-size: 18px; font-weight: bold; margin-top: 2px; margin-bottom: 2px;'>Send Email</p></td>
					    		</tr>
					    		<tr>
					    			<td>
					    				<table>
					    					<tr valign='top'>
					    						<td>Subject <br>
					    							<input type='text' id='subject' class='required' placeholder='Subject' name='subject' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 20px; width: 260px; margin-right: 10px; padding: 5px; margin-bottom: 10px;'>
					    							<span id='subject_status'></span>
					    						</td>
					    						<td>
					    							Email <br>
					    							<input type='text' id='email' class='required' placeholder='Email' name='email' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; height: 20px; width: 260px; margin-right: 10px; padding: 5px; margin-bottom: 10px;'>
					    							<span id='email_status'></span>
					    						</td>
					    					</tr>
					    					<tr valign='top'>
					    						<td colspan='2'>
					    							Message <br>
								    				<textarea id='msg' name='msg' class='txtarea' placeholder='Enter your message here' style='background: #FFF; border: 1px solid #DDD; border-radius: 5px; box-shadow: 0 0 5px #DDD inset; color:#666; outline: none; width: 540px; margin-right: 10px; padding: 5px; height: 180px;'></textarea>
								    				<span id='msg_status'></span>
					    						</td>
					    					</tr>
					    				</table>
					    			</td>
					    		</tr>
					    		<tr>
						    		<td><button id='send'>Send Message</button></td>
						    	</tr>
					    	</table>
						</form>
					</div>
				</div>
				</a>
				<hr style='border: 1px solid #E8E8E8; margin-top: 15px; margin-bottom: 15px;'>
				<table>
					<tr>
						<td width='20'>$img_fb</td>
						<td><b>$facebook_name</b></td>
					</tr>
				</table>
				<hr style='border: 1px solid #E8E8E8; margin-top: 15px; margin-bottom: 15px;'>
		</div>";
	}
	?>
	
	<?php
	if ($_GET['module'] == 'classified'){
		$nm = md5(date('Ymdhis'));
		?>
		<script type="text/javascript" src="js/vsmenu.js"></script>
		<link rel="stylesheet" type="text/css" href="css/vsmenu.css">
		<br>
		<label class="badge">Search Ads</label>
		<ul class="vsmenu vs_creamy">
			<?php
			$nm = md5(date('Ymdhis'));
			$sql_province = $db->database_prepare("SELECT * FROM as_provinces WHERE status = 'Y' ORDER BY province_name ASC")->execute();
			while ($data_province = $db->database_fetch_array($sql_province)){
				$title = strtolower(str_replace(" ", "+", $data_province['province_name']));
				
				$nums = $db->database_num_rows($db->database_prepare("SELECT advertising_id FROM as_advertising WHERE province_id = ? AND active = 'Y'")->execute($data_province['province_id']));
				echo "<li><a href='classified-0-1-1-1-0-$data_province[province_id]-0-$title.html'>$data_province[province_name] <span style='float: right;'>$nums</span></a><li>";
			}
			?>
		</ul><br>
		<!--<p style="font-weight: bold; font-size: 16px;">SEARCH ADS:</p>
		<form method='GET' action='modul/mod_classified/search.php'>
			<input type='hidden' name='module' value='classified_detail'>
			<input type='hidden' name='id' value='0'>
			<input type='hidden' name='div' value='1'>
			<input type='hidden' name='page' value='1'>
			<input type='hidden' name='type' value='1'>
			<input type='hidden' name='cat' value='0'>
			<input type='hidden' name='nm' value='<?php echo $nm; ?>'>
			<table>
				<tr>
					<td><p style="font-weight: bold;">Ad Type:</p>
						<select name='verified' id='verified' class='white-pink2'>
							<option value='0'>All</option>
							<option value='1'>For Sale</option>
							<option value='2'>Looking For</option>
						</select>
					</td>
				</tr>
				<tr>
					<td><p style="font-weight: bold;">Country:</p>
						<select name='cid' id='cid' class='white-pink'>
							<option value='0'>All Countries</option>
								<?php
								$sql_cou = $db->database_prepare("SELECT * FROM as_country WHERE status = 'Y' ORDER BY country_name ASC")->execute();
								while ($data_cou = $db->database_fetch_array($sql_cou)){
									echo "<option value='$data_cou[country_id]'>$data_cou[country_name]</option>";
								}
								?>
						</select>
					</td>
				</tr>
				<tr>
					<td><p style="font-weight: bold;">State</p>
						<select name='pid' id='pid' class='white-pink'>";
							<option value='0'>All States</option>
						</select>
					</td>
				</tr>
			</table>
			<p><input type="submit" class="button_facebook" name="submit" value="SEARCH ADS" style="width: 190px;"></p>
		</form>
		<p>&nbsp;</p>-->
		<?php
	}

	if ($_GET['module'] == 'discount_sale_info'){
		$nm = md5(date('Ymdhis'));
		?>
		<script type="text/javascript" src="js/vsmenu.js"></script>
		<link rel="stylesheet" type="text/css" href="css/vsmenu.css">
		<br>
		<label class="badge">Filter by Provinces</label>
		<ul class="vsmenu vs_creamy">
			<?php
			$sql_province = $db->database_prepare("SELECT * FROM as_provinces WHERE status = 'Y' ORDER BY province_name ASC")->execute();
			while ($data_province = $db->database_fetch_array($sql_province)){
				$nums = $db->database_num_rows($db->database_prepare("SELECT discount_id FROM as_discounts WHERE province_id = ? AND active = 'Y'")->execute($data_province["province_id"]));
				
				echo "<li><a href='discount-classified-0-$data_province[province_id]-1-1-all+groups.html'>$data_province[province_name] <span style='float: right;'>$nums</span></a></li>";
			}
			?>
		</ul><br>
	<?php
	}
	
	if ($_GET['module'] == 'open_tourism' || $_GET['module'] == 'read_tourism'){
		?>
		<script type="text/javascript" src="js/vsmenu.js"></script>
		<link rel="stylesheet" type="text/css" href="css/vsmenu.css">
		<br>
		<label class="badge">Cari Berdasarkan Negara</label>
		<ul class="vsmenu vs_creamy">
			<?php
			$sql_country = $db->database_prepare("SELECT * FROM as_tourism_country WHERE status = 'Y' ORDER BY country ASC")->execute();
			while ($data_country = $db->database_fetch_array($sql_country)){
				if ($data_country['flag'] != ''){
					$img = "<img src='images/photo_flag/$data_country[flag]' width='20' height='15'>";
				}
				else{
					$img = "";
				}
				
				$nums = $db->database_num_rows($db->database_prepare("SELECT tourism_id FROM as_tourism WHERE tourism_country_id = ? AND status = 'Y'")->execute($data_country["tourism_country_id"]));
				
				echo "<li><a href='open-tourism-$data_country[tourism_country_id]-1-$data_country[country_seo].html'>$img $data_country[country] <span style='float: right;'>$nums</span></a></li>";
			}
			?>
		</ul><br>
	<?php
	}
	
	/*
	if ($_GET['module'] != 'other-ads' && $_GET['module'] != 'open_tourism' && $_GET['module'] != 'read_tourism'){
		echo "<link rel='stylesheet' type='text/css' href='css/vsmenu.css'>";
		echo "<label class='badge'>Promosikan Iklan Anda</label><br>";
		$sql_ppc_right = $db->database_prepare("SELECT * FROM as_ppc WHERE status = 'Y' ORDER BY rand() LIMIT 5")->execute();
		while ($data_ppc_right = $db->database_fetch_array($sql_ppc_right)){
			
			if ($data_ppc_right['image'] != ''){
				$image = "<span class='image'><img src='images/photo_ppc/thumb/small_$data_ppc_right[image]' width='50' height='50'></span>";
			}
			else{
				$image = "<img src='images/no_image.jpg' width='50' height='50'>";
			}
			$created = md5(date('Ymdhis'));
			
			echo "<p style='border-bottom: 1px solid #999999; text-align: justify; font: 13px/19px Arial,serif; width: 205px; min-height: 125px;'>
						<a href='modul/mod_ppc/a.php?u=$data_ppc_right[url]&pid=$data_ppc_right[ppc_id]&mid=$data_ppc_right[member_id]&CD_$created' target='_blank' class='black'>
							<b>$data_ppc_right[title]</b><br>
							<font size='1'>$data_ppc_right[url]</font><br>
							$image
						</a>
						<font size='1'>$data_ppc_right[description]</font>
						</p>";
		}
	}
	*/
	?>
